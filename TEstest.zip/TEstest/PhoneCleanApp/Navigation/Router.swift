import SwiftUI

@Observable
final class Router {
    var path: [Screen] = []
    var isTabBarVisible: Bool = true

    func push(_ screen: Screen) {
        path.append(screen)
        isTabBarVisible = false
    }

    func pop() {
        guard !path.isEmpty else { return }
        path.removeLast()
        isTabBarVisible = path.isEmpty
    }

    func popToRoot() {
        path.removeAll()
        isTabBarVisible = true
    }
}
