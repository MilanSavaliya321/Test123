import Foundation


enum Screen: Hashable, Sendable {
    
}
