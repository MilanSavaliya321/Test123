import SwiftUI
import FirebaseAnalytics
import Photos

private struct OnboardingPage: Identifiable {
    let id = UUID()
    let symbol: String
    let title: String
    let subtitle: String
    let tint: Color
    let kind: OnboardingPageKind
}

private enum OnboardingPageKind {
    case standard
    case photoPermission
}

struct OnboardingView: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var pageIndex = 0
    @State private var animate = false
    @State private var photoAuthorizationStatus = PHPhotoLibrary.authorizationStatus(for: .readWrite)
    @State private var isRequestingPhotoAccess = false

    let onFinished: () -> Void

    private let pages = [
        OnboardingPage(
            symbol: "sparkles",
            title: "Clean hidden clutter",
            subtitle: "Find duplicate photos, screenshots, and large media that quietly use storage.",
            tint: AppConstants.accentDeepBlue,
            kind: .standard
        ),
        OnboardingPage(
            symbol: "photo.stack.fill",
            title: "Allow Photo Access",
            subtitle: "Phone Cleaner needs access to scan photos, videos, screenshots, and media you choose to compress.",
            tint: Color(hex: "#06B6D4"),
            kind: .photoPermission
        ),
        OnboardingPage(
            symbol: "arrow.down.forward.and.arrow.up.backward",
            title: "Compress in a tap",
            subtitle: "Shrink photos and videos while keeping copies organized and easy to review.",
            tint: Color(hex: "#22C55E"),
            kind: .standard
        ),
        OnboardingPage(
            symbol: "shield.checkered",
            title: "Stay in control",
            subtitle: "Review every suggestion before deleting or compressing anything.",
            tint: Color(hex: "#6366F1"),
            kind: .standard
        )
    ]

    var body: some View {
        GeometryReader { proxy in
            let activePage = pages[pageIndex]

            ZStack {
                LinearGradient(
                    colors: [.white, AppConstants.elevatedSurface, AppConstants.canvas],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()

                Circle()
                    .fill(activePage.tint.opacity(0.14))
                    .frame(width: proxy.size.width * 0.9)
                    .blur(radius: 30)
                    .offset(x: animate && !reduceMotion ? 80 : -70, y: -proxy.size.height * 0.28)
                    .animation(.easeInOut(duration: 4).repeatForever(autoreverses: true), value: animate)

                VStack(spacing: 0) {
                    TabView(selection: $pageIndex) {
                        ForEach(Array(pages.enumerated()), id: \.element.id) { index, page in
                            pageContent(page)
                                .tag(index)
                        }
                    }
                    .tabViewStyle(.page(indexDisplayMode: .never))

                    VStack(spacing: 18) {
                        pageDots
                        continueButton
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, max(proxy.safeAreaInsets.bottom + 18, 28))
                }
            }
        }
        .preferredColorScheme(.light)
        .onAppear {
            Analytics.logEvent("view_onboarding", parameters: nil)
            photoAuthorizationStatus = PHPhotoLibrary.authorizationStatus(for: .readWrite)
            animate = true
        }
    }

    private func pageContent(_ page: OnboardingPage) -> some View {
        VStack(spacing: 28) {
            Spacer(minLength: 36)

            ZStack {
                Circle()
                    .fill(page.tint.opacity(0.12))
                    .frame(width: 240, height: 240)

                RoundedRectangle(cornerRadius: 38, style: .continuous)
                    .fill(.white)
                    .frame(width: 178, height: 178)
                    .overlay {
                        RoundedRectangle(cornerRadius: 38, style: .continuous)
                            .stroke(AppConstants.border, lineWidth: 1)
                    }
                    .shadow(color: page.tint.opacity(0.16), radius: 24, y: 14)

                Image(systemName: page.symbol)
                    .font(.system(size: 72, weight: .bold))
                    .foregroundStyle(page.tint)
                    .scaleEffect(animate && !reduceMotion ? 1.04 : 0.98)
                    .animation(.easeInOut(duration: 1.8).repeatForever(autoreverses: true), value: animate)
            }
            .accessibilityHidden(true)

            VStack(spacing: 12) {
                Text(page.title)
                    .font(.system(size: 32, weight: .black, design: .rounded))
                    .foregroundStyle(AppConstants.primaryText)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)

                Text(page.subtitle)
                    .font(.body.weight(.medium))
                    .foregroundStyle(AppConstants.secondaryText)
                    .multilineTextAlignment(.center)
                    .lineSpacing(4)
                    .padding(.horizontal, 10)
            }
            .padding(.horizontal, 24)

            if page.kind == .photoPermission {
                permissionDetails
                    .padding(.horizontal, 24)
                    .padding(.top, -2)
            }

            Spacer(minLength: 24)
        }
    }

    private var permissionDetails: some View {
        VStack(spacing: 10) {
            permissionRow(icon: "lock.shield.fill", title: "Private by design", subtitle: "Scanning happens on your device.")
            permissionRow(icon: "checkmark.circle.fill", title: "You approve cleanup", subtitle: "Nothing is removed automatically.")

            Text(photoPermissionStatusText)
                .font(.caption.weight(.bold))
                .foregroundStyle(photoPermissionStatusColor)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 10)
                .background(photoPermissionStatusColor.opacity(0.1), in: Capsule(style: .continuous))
        }
    }

    private func permissionRow(icon: String, title: String, subtitle: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 15, weight: .bold))
                .foregroundStyle(AppConstants.accentDeepBlue)
                .frame(width: 34, height: 34)
                .background(AppConstants.elevatedSurface, in: Circle())

            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(AppConstants.primaryText)
                Text(subtitle)
                    .font(.caption.weight(.medium))
                    .foregroundStyle(AppConstants.secondaryText)
            }

            Spacer(minLength: 0)
        }
        .padding(12)
        .glassCard(cornerRadius: 16)
    }

    private var pageDots: some View {
        HStack(spacing: 8) {
            ForEach(pages.indices, id: \.self) { index in
                Capsule()
                    .fill(index == pageIndex ? AppConstants.accentDeepBlue : AppConstants.border)
                    .frame(width: index == pageIndex ? 24 : 8, height: 8)
            }
        }
        .animation(.spring(response: 0.3, dampingFraction: 0.8), value: pageIndex)
    }

    private var continueButton: some View {
        Button {
            Task {
                await handleContinue()
            }
        } label: {
            HStack(spacing: 8) {
                if isRequestingPhotoAccess {
                    ProgressView()
                        .tint(.white)
                } else {
                    Text(continueButtonTitle)
                    Image(systemName: "arrow.right")
                }
            }
            .font(.headline.weight(.bold))
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 54)
            .background(
                LinearGradient(
                    colors: [AppConstants.accentBlue, AppConstants.accentDeepBlue],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                in: RoundedRectangle(cornerRadius: 18, style: .continuous)
            )
            .shadow(color: AppConstants.accentDeepBlue.opacity(0.22), radius: 18, y: 10)
        }
        .disabled(isRequestingPhotoAccess)
        .buttonStyle(.pressScale)
    }

    private var continueButtonTitle: String {
        let page = pages[pageIndex]
        if page.kind == .photoPermission && photoAuthorizationStatus == .notDetermined {
            return "Allow Photos Access"
        }
        return pageIndex == pages.count - 1 ? "Get Started" : "Continue"
    }

    private var photoPermissionStatusText: String {
        switch photoAuthorizationStatus {
        case .authorized:
            return "Full photo access is enabled"
        case .limited:
            return "Limited photo access is enabled"
        case .denied, .restricted:
            return "Photo access is not enabled"
        case .notDetermined:
            return "Permission will be requested on this step"
        @unknown default:
            return "Photo permission status is unknown"
        }
    }

    private var photoPermissionStatusColor: Color {
        switch photoAuthorizationStatus {
        case .authorized, .limited:
            return Color(hex: "#16A34A")
        case .denied, .restricted:
            return Color(hex: "#F59E0B")
        case .notDetermined:
            return AppConstants.accentDeepBlue
        @unknown default:
            return AppConstants.secondaryText
        }
    }

    @MainActor
    private func handleContinue() async {
        let page = pages[pageIndex]

        if page.kind == .photoPermission && photoAuthorizationStatus == .notDetermined {
            isRequestingPhotoAccess = true
            let status = await requestPhotoAccess()
            photoAuthorizationStatus = status
            isRequestingPhotoAccess = false
        }

        if pageIndex < pages.count - 1 {
            withAnimation(.spring(response: 0.32, dampingFraction: 0.82)) {
                pageIndex += 1
            }
        } else {
            onFinished()
        }
    }

    private func requestPhotoAccess() async -> PHAuthorizationStatus {
        await withCheckedContinuation { continuation in
            PHPhotoLibrary.requestAuthorization(for: .readWrite) { status in
                continuation.resume(returning: status)
            }
        }
    }
}
