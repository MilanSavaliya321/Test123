import Photos
import SwiftUI
import SDWebImageSwiftUI
import UIKit
import AVKit

struct HomeView: View {
    @Environment(Router.self) private var router
    @ObservedObject var viewModel: HomeScanViewModel
    @State private var selectedCategory: HomeMediaCategory?

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                header
                    .padding(.horizontal, 18)
                    .padding(.top, 16)
                    .padding(.bottom, 12)

                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        storageCard
                        
                        if viewModel.isUpdatingSilently {
                            HStack(spacing: 8) {
                                ProgressView()
                                    .tint(.white.opacity(0.8))
                                    .scaleEffect(0.8)
                                Text("Updating cache...")
                                    .font(.custom("Outfit-Medium", size: 14))
                                    .foregroundColor(.white.opacity(0.8))
                                Spacer()
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 10)
                            .background(Color.white.opacity(0.1))
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                        }
                        
                        mediaGrid
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 4)
                    .padding(.bottom, router.isTabBarVisible ? 104 : 22)
                }
                .scrollIndicators(.hidden)
            }
            .premiumBackground()
            .toolbar(.hidden, for: .navigationBar)
            .task {
                viewModel.beginScanFlowIfNeeded()
            }
            .navigationDestination(item: $selectedCategory) { category in
                MediaCategoryDetailView(summary: summary(category), onBack: {
                    selectedCategory = nil
                }) { deletedIDs in
                    viewModel.removeAssets(with: deletedIDs)
                }
                .onAppear {
                    router.isTabBarVisible = false
                }
                .onDisappear {
                    router.isTabBarVisible = true
                }
            }
            .onAppear {
                if selectedCategory == nil {
                    router.isTabBarVisible = true
                }
            }
            .onChange(of: selectedCategory) { _, category in
                router.isTabBarVisible = category == nil
            }
            .alert("Photo Access Required", isPresented: permissionAlertBinding) {
                Button("Cancel", role: .cancel) {
                    viewModel.dismissPermissionAlert()
                }
                Button("Settings") {
                    viewModel.openSettings()
                    viewModel.dismissPermissionAlert()
                }
            } message: {
                Text(viewModel.permissionAlertMessage ?? "")
            }
        }
    }

    private var permissionAlertBinding: Binding<Bool> {
        Binding(
            get: { viewModel.permissionAlertMessage != nil },
            set: { isPresented in
                if !isPresented {
                    viewModel.dismissPermissionAlert()
                }
            }
        )
    }

    private var header: some View {
        HStack(spacing: 10) {
            Image(systemName: "sparkles")
                .font(.system(size: 18, weight: .black))
                .foregroundStyle(AppConstants.accentDeepBlue)

            Text("Phone Cleaner")
                .font(.system(size: 29, weight: .black, design: .rounded))
                .foregroundStyle(AppConstants.primaryText)
                .lineLimit(1)
                .minimumScaleFactor(0.75)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var storageCard: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(hex: "#3B82FF"),
                    Color(hex: "#1967FF"),
                    Color(hex: "#2EA9FF")
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )

            StorageHeroGrid()
                .opacity(0.24)

            HStack(alignment: .center, spacing: 12) {
                VStack(alignment: .leading, spacing: 12) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Speed Up Phone")
                            .font(.system(size: 26, weight: .black, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                            .minimumScaleFactor(0.72)

                        Text("\(viewModel.storageInfo.used) of \(viewModel.storageInfo.total) used")
                            .font(.subheadline.weight(.bold))
                            .foregroundStyle(.white.opacity(0.86))
                            .lineLimit(1)
                            .minimumScaleFactor(0.72)
                    }

                    HStack(spacing: 8) {
                        Label("Smart Cleaner", systemImage: "sparkles")
                            .font(.system(size: 18, weight: .black, design: .rounded))
                            .foregroundStyle(AppConstants.accentDeepBlue)
                            .lineLimit(1)
                            .minimumScaleFactor(0.75)
                    }
                    .padding(.horizontal, 18)
                    .frame(height: 50)
                    .background(.white, in: Capsule())
                    .shadow(color: .black.opacity(0.08), radius: 12, y: 6)

                    VStack(alignment: .leading, spacing: 6) {
                        GeometryReader { proxy in
                            ZStack(alignment: .leading) {
                                Capsule()
                                    .fill(.white.opacity(0.24))

                                Capsule()
                                    .fill(.white)
                                    .frame(width: max(12, proxy.size.width * CGFloat(viewModel.progress)))
                            }
                        }
                        .frame(height: 6)

                        Text(viewModel.progressText)
                            .font(.caption.weight(.black))
                            .foregroundStyle(.white.opacity(0.9))
                            .lineLimit(1)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                StorageHeroArtwork(progressText: viewModel.storageInfo.percentText)
                    .frame(width: 104, height: 116)
            }
            .padding(18)
        }
        .frame(minHeight: 196)
        .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 26, style: .continuous)
                .stroke(.white.opacity(0.38), lineWidth: 1)
        }
        .shadow(color: AppConstants.accentDeepBlue.opacity(0.22), radius: 24, x: 0, y: 14)
    }

    private var mediaGrid: some View {
        LazyVGrid(
            columns: [
                GridItem(.flexible(), spacing: 12),
                GridItem(.flexible(), spacing: 12)
            ],
            spacing: 12
        ) {
            ForEach(HomeMediaCategory.allCases) { category in
                MediaCategoryCard(summary: summary(category)) {
                    router.isTabBarVisible = false
                    selectedCategory = category
                }
            }
        }
    }

    private func summary(_ type: HomeMediaCategory) -> HomeMediaCategorySummary {
        viewModel.categories.first(where: { $0.type == type }) ?? HomeMediaCategorySummary(type: type)
    }
}

private struct StorageHeroGrid: View {
    var body: some View {
        GeometryReader { proxy in
            Path { path in
                let width = proxy.size.width
                let height = proxy.size.height
                let spacing: CGFloat = 34

                for x in stride(from: CGFloat(0), through: width, by: spacing) {
                    path.move(to: CGPoint(x: x, y: 0))
                    path.addLine(to: CGPoint(x: x + 42, y: height))
                }

                for y in stride(from: CGFloat(0), through: height, by: spacing) {
                    path.move(to: CGPoint(x: 0, y: y))
                    path.addLine(to: CGPoint(x: width, y: y))
                }
            }
            .stroke(.white.opacity(0.44), lineWidth: 0.8)
        }
        .allowsHitTesting(false)
    }
}

private struct StorageHeroArtwork: View {
    let progressText: String

    var body: some View {
        ZStack {
            Circle()
                .fill(.white.opacity(0.18))
                .frame(width: 100, height: 100)
                .offset(x: 8, y: 2)

            Circle()
                .fill(.white)
                .frame(width: 82, height: 82)
                .overlay {
                    VStack(spacing: 2) {
                        Image(systemName: "bolt.fill")
                            .font(.system(size: 24, weight: .black))
                            .foregroundStyle(AppConstants.accentDeepBlue)

                        Text(progressText)
                            .font(.system(size: 17, weight: .black, design: .rounded))
                            .foregroundStyle(AppConstants.primaryText)
                    }
                }
                .shadow(color: .black.opacity(0.16), radius: 16, y: 8)

            Image(systemName: "sparkle")
                .font(.system(size: 15, weight: .black))
                .foregroundStyle(.white.opacity(0.95))
                .offset(x: -38, y: -42)

            Image(systemName: "sparkle")
                .font(.system(size: 12, weight: .black))
                .foregroundStyle(.white.opacity(0.75))
                .offset(x: 42, y: -28)
        }
    }
}

private struct StoragePill: View {
    let title: String
    let value: String
    let color: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title)
                .font(.caption2.weight(.bold))
                .foregroundStyle(AppConstants.secondaryText)
            Text(value)
                .font(.caption.weight(.black))
                .foregroundStyle(color)
                .lineLimit(1)
                .minimumScaleFactor(0.65)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(AppConstants.elevatedSurface, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
    }
}

private struct MediaCategoryCard: View {
    let summary: HomeMediaCategorySummary
    let action: () -> Void

    private var screenWidth: CGFloat { UIScreen.main.bounds.width }

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: screenWidth * 0.03) {
                ZStack {
                    if let asset = summary.thumbnailAsset {
                        PhotoAssetThumbnail(asset: asset)
                    } else {
                        PremiumPlaceholder(symbolName: summary.type.symbolName, isCompact: true)
                    }
                }
                .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .layoutPriority(0)

                VStack(alignment: .leading, spacing: screenWidth * 0.01) {
                    Text(summary.sizeText)
                        .font(.system(size: screenWidth * 0.05, weight: .black, design: .rounded))
                        .foregroundStyle(AppConstants.primaryText)
                        .lineLimit(1)
                        .minimumScaleFactor(0.5)

                    Text(summary.type.title)
                        .font(.system(size: screenWidth * 0.038, weight: .black))
                        .foregroundStyle(AppConstants.primaryText)
                        .lineLimit(2)
                        .minimumScaleFactor(0.5)
                        .fixedSize(horizontal: false, vertical: true)

                    Text(summary.itemText)
                        .font(.system(size: screenWidth * 0.03, weight: .heavy))
                        .foregroundStyle(AppConstants.secondaryText)
                        .lineLimit(1)
                        .minimumScaleFactor(0.5)
                }
                .layoutPriority(1)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .frame(height: screenWidth * 0.52, alignment: .top)
            .padding(screenWidth * 0.03)
            .glassCard(cornerRadius: 16)
        }
        .buttonStyle(.pressScale)
        .accessibilityLabel("\(summary.type.title), \(summary.sizeText), \(summary.itemText)")
    }
}

private struct StorageRing: View {
    let progress: Double

    var body: some View {
        ZStack {
            Circle()
                .stroke(AppConstants.border, lineWidth: 10)

            Circle()
                .trim(from: 0, to: progress)
                .stroke(
                    AngularGradient(
                        colors: [AppConstants.accentDeepBlue, HomeTheme.rose, AppConstants.accentDeepBlue],
                        center: .center,
                        startAngle: .degrees(-90),
                        endAngle: .degrees(270)
                    ),
                    style: StrokeStyle(lineWidth: 10, lineCap: .round)
                )
                .rotationEffect(.degrees(-90))
        }
    }
}

private struct MediaCategoryDetailView: View {
    let summary: HomeMediaCategorySummary
    let onBack: () -> Void
    let onDeleted: (Set<String>) -> Void

    @State private var selectedIDs = Set<String>()
    @State private var deletedIDs = Set<String>()
    @State private var isDeleting = false
    @State private var deleteError: String?
    @State private var previewAsset: MediaAsset?
    @State private var loadedAssetLimit: Int

    private static let pageSize = 24

    init(summary: HomeMediaCategorySummary, onBack: @escaping () -> Void, onDeleted: @escaping (Set<String>) -> Void) {
        self.summary = summary
        self.onBack = onBack
        self.onDeleted = onDeleted
        _selectedIDs = State(initialValue: Self.defaultSelection(for: summary))
        _loadedAssetLimit = State(initialValue: Self.pageSize)
    }

    private var groups: [[MediaAsset]] {
        Self.makeGroups(from: summary.scanResult).map { group in
            group.filter { !deletedIDs.contains($0.assetLocalIdentifier) }
        }
        .filter { !$0.isEmpty }
    }

    private var visibleAssets: [MediaAsset] {
        groups.flatMap { $0 }
    }

    private var pagedGroups: [PagedMediaGroup] {
        guard loadedAssetLimit > 0 else { return [] }

        if summary.type == .screenshots, let screenshots = groups.first {
            let displayedScreenshots = Array(screenshots.prefix(loadedAssetLimit))
            return displayedScreenshots.isEmpty ? [] : [
                PagedMediaGroup(index: 0, group: displayedScreenshots, selectionGroup: screenshots)
            ]
        }

        var remaining = loadedAssetLimit
        var result: [PagedMediaGroup] = []

        for (index, group) in groups.enumerated() {
            guard remaining > 0 else { break }
            if group.count <= remaining {
                result.append(PagedMediaGroup(index: index, group: group, selectionGroup: group))
                remaining -= group.count
            } else if result.isEmpty {
                result.append(PagedMediaGroup(index: index, group: Array(group.prefix(remaining)), selectionGroup: group))
                remaining = 0
            } else {
                break
            }
        }

        return result
    }

    private var pagedAssets: [MediaAsset] {
        pagedGroups.flatMap { $0.group }
    }

    private var canLoadMoreAssets: Bool {
        pagedAssets.count < visibleAssets.count
    }

    var body: some View {
        VStack(spacing: 0) {
            detailHeader

            if visibleAssets.isEmpty {
                GeometryReader { proxy in
                    VStack {
                        Spacer(minLength: 0)

                        emptyState
                            .frame(minHeight: min(430, proxy.size.height * 0.62))
                            .padding(.horizontal, 18)

                        Spacer(minLength: 0)
                    }
                    .frame(width: proxy.size.width, height: proxy.size.height)
                }
            } else {
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        summaryStrip

                        ForEach(pagedGroups) { item in
                            groupSection(index: item.index, group: item.group, selectionGroup: item.selectionGroup)
                        }

                        if canLoadMoreAssets {
                            loadMoreFooter
                        }
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 12)
                    .padding(.bottom, selectedIDs.isEmpty ? 22 : 86)
                }
            }
        }
        .premiumBackground()
        .toolbar(.hidden, for: .navigationBar)
        .navigationBarBackButtonHidden(true)
        .safeAreaInset(edge: .bottom, spacing: 0) {
            if !selectedIDs.isEmpty {
                deleteBar
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .animation(.easeInOut(duration: 0.18), value: selectedIDs.isEmpty)
        .alert("Delete Failed", isPresented: deleteErrorBinding) {
            Button("OK") {
                deleteError = nil
            }
        } message: {
            Text(deleteError ?? "")
        }
        .fullScreenCover(isPresented: previewBinding) {
            if let previewAsset {
                MediaPreviewView(asset: previewAsset) {
                    self.previewAsset = nil
                }
            }
        }
    }

    private var detailHeader: some View {
        HStack(spacing: 14) {
            Button(action: onBack) {
                Image(systemName: "chevron.left")
                    .font(.system(size: 22, weight: .black))
                    .foregroundStyle(AppConstants.primaryText)
                    .frame(width: 54, height: 54)
                    .background(AppConstants.surface, in: Circle())
                    .overlay {
                        Circle().stroke(AppConstants.border, lineWidth: 1)
                    }
                    .shadow(color: AppConstants.accentDeepBlue.opacity(0.12), radius: 16, y: 8)
            }
            .buttonStyle(.pressScale)
            .accessibilityLabel("Back")

            VStack(alignment: .leading, spacing: 3) {
                Text(summary.type.title)
                    .font(.system(size: 22, weight: .black, design: .rounded))
                    .foregroundStyle(AppConstants.primaryText)
                    .lineLimit(1)
                    .minimumScaleFactor(0.82)

                if !visibleAssets.isEmpty {
                    Text("\(visibleAssets.count) items found")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(AppConstants.secondaryText)
                }
            }

            Spacer(minLength: 8)

            if !visibleAssets.isEmpty {
                Button(selectedIDs.count == visibleAssets.count ? "Clear" : "Select All") {
                    toggleSelectAll()
                }
                .primaryBlueButton(width: 96, height: 34, font: .subheadline.weight(.black))
                .buttonStyle(.pressScale)
            }
        }
        .padding(.horizontal, 18)
        .padding(.bottom, 8)
        .transaction { transaction in
            transaction.animation = nil
        }
    }

    private var deleteErrorBinding: Binding<Bool> {
        Binding(
            get: { deleteError != nil },
            set: { isPresented in
                if !isPresented { deleteError = nil }
            }
        )
    }

    private var previewBinding: Binding<Bool> {
        Binding(
            get: { previewAsset != nil },
            set: { isPresented in
                if !isPresented { previewAsset = nil }
            }
        )
    }

    private var summaryStrip: some View {
        DetailStatsPanel(
            found: visibleAssets.count,
            size: totalSizeText(for: visibleAssets),
            selected: selectedIDs.count
        )
    }

    private var emptyState: some View {
        PremiumEmptyState(
            symbolName: summary.type.symbolName,
            title: "No \(summary.type.title.lowercased()) found",
            message: "The scan finished, but this category has no items to review."
        )
    }

    private var deleteBar: some View {
        VStack(spacing: 7) {
            Text("\(selectedIDs.count) Items Selected")
                .font(.subheadline.weight(.black))
                .foregroundStyle(AppConstants.primaryText)

            Button {
                deleteSelectedAssets()
            } label: {
                Label(isDeleting ? "Deleting..." : "Delete Selected Items", systemImage: "trash.fill")
                    .font(.headline.weight(.black))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .background(Color(hex: "#EF4444"), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
            .disabled(isDeleting)
            .buttonStyle(.pressScale)
        }
        .padding(.horizontal, 18)
        .padding(.top, 9)
        .padding(.bottom, 7)
        .background(AppConstants.canvas.opacity(0.92))
        .overlay(alignment: .top) {
            Rectangle()
                .fill(AppConstants.border)
                .frame(height: 1)
        }
    }

    private var loadMoreFooter: some View {
        HStack(spacing: 8) {
            ProgressView()
                .tint(AppConstants.accentDeepBlue)

            Text("Loading more")
                .font(.caption.weight(.bold))
                .foregroundStyle(AppConstants.secondaryText)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .onAppear {
            loadMoreAssetsIfNeeded()
        }
    }

    private func groupSection(index: Int, group: [MediaAsset], selectionGroup: [MediaAsset]) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(summary.type == .screenshots ? "Screenshots" : "Group \(index + 1)")
                    .font(.headline.weight(.black))
                    .foregroundStyle(AppConstants.primaryText)

                Spacer()

                Button(selectionGroup.allSatisfy { selectedIDs.contains($0.assetLocalIdentifier) } ? "Clear" : "Select") {
                    toggleGroup(selectionGroup)
                }
                .primaryBlueButton(width: 72, height: 32, font: .subheadline.weight(.black))
                .buttonStyle(.pressScale)
            }

            LazyVGrid(
                columns: [
                    GridItem(.flexible(), spacing: 10),
                    GridItem(.flexible(), spacing: 10)
                ],
                spacing: 10
            ) {
                ForEach(group, id: \.assetLocalIdentifier) { asset in
                    DetailAssetTile(
                        asset: asset,
                        isSelected: selectedIDs.contains(asset.assetLocalIdentifier),
                        isVideo: asset.assetType == .video,
                        previewAction: {
                            previewAsset = asset
                        },
                        selectionAction: {
                            toggleAsset(asset)
                        }
                    )
                    .onAppear {
                        loadMoreAssetsIfNeeded(after: asset)
                    }
                }
            }
        }
        .padding(14)
        .glassCard(cornerRadius: 16)
    }

    private func toggleAsset(_ asset: MediaAsset) {
        if selectedIDs.contains(asset.assetLocalIdentifier) {
            selectedIDs.remove(asset.assetLocalIdentifier)
        } else {
            selectedIDs.insert(asset.assetLocalIdentifier)
        }
    }

    private func loadMoreAssetsIfNeeded(after asset: MediaAsset? = nil) {
        guard canLoadMoreAssets else { return }
        if let asset, asset.assetLocalIdentifier != pagedAssets.last?.assetLocalIdentifier {
            return
        }

        loadedAssetLimit = min(loadedAssetLimit + Self.pageSize, visibleAssets.count)
    }

    private func toggleGroup(_ group: [MediaAsset]) {
        let groupIDs = Set(group.map(\.assetLocalIdentifier))
        if groupIDs.isSubset(of: selectedIDs) {
            selectedIDs.subtract(groupIDs)
        } else {
            selectedIDs.formUnion(groupIDs)
        }
    }

    private func toggleSelectAll() {
        let allIDs = Set(visibleAssets.map(\.assetLocalIdentifier))
        if selectedIDs.count == allIDs.count {
            selectedIDs.removeAll()
        } else {
            selectedIDs = allIDs
        }
    }

    private static func defaultSelection(for summary: HomeMediaCategorySummary) -> Set<String> {
        let groups = makeGroups(from: summary.scanResult)

        if summary.type == .screenshots {
            return Set(groups.flatMap { $0.map(\.assetLocalIdentifier) })
        }

        return Set(groups.flatMap { group in
            group.dropFirst().map(\.assetLocalIdentifier)
        })
    }

    private func deleteSelectedAssets() {
        let idsToDelete = selectedIDs
        guard !idsToDelete.isEmpty else { return }

        let fetchResult = PHAsset.fetchAssets(withLocalIdentifiers: Array(idsToDelete), options: nil)
        guard fetchResult.count > 0 else {
            deleteError = "The selected assets are no longer available."
            return
        }

        isDeleting = true
        let assetsToDelete = fetchResult.objects(at: IndexSet(integersIn: 0..<fetchResult.count))

        DispatchQueue.global(qos: .userInitiated).async {
            do {
                try PHPhotoLibrary.shared().performChangesAndWait {
                    PHAssetChangeRequest.deleteAssets(assetsToDelete as NSArray)
                }
                DispatchQueue.main.async {
                    isDeleting = false
                    deletedIDs.formUnion(idsToDelete)
                    selectedIDs.subtract(idsToDelete)
                    onDeleted(idsToDelete)
                }
            } catch {
                DispatchQueue.main.async {
                    isDeleting = false
                    deleteError = error.localizedDescription
                }
            }
        }
    }

    private static func makeGroups(from result: ScanResult?) -> [[MediaAsset]] {
        guard let result else { return [] }

        switch result {
        case .similarPhotos(let groups),
             .duplicatePhotos(let groups),
             .similarVideos(let groups),
             .duplicateVideos(let groups):
            return groups
        case .allScreenshots(let screenshots):
            return screenshots.isEmpty ? [] : [screenshots]
        }
    }

    private func totalSizeText(for assets: [MediaAsset]) -> String {
        formatSize(assets.reduce(0) { $0 + $1.fileSize })
    }

    private func formatSize(_ sizeInBytes: Float) -> String {
        let sizeInMB = sizeInBytes / (1024 * 1024)
        if sizeInMB < 1 {
            return sizeInBytes == 0 ? "0 MB" : MediaSizeFormatter.string(value: sizeInBytes / 1024, unit: "KB")
        } else if sizeInMB < 1024 {
            return MediaSizeFormatter.string(value: sizeInMB, unit: "MB")
        } else {
            return MediaSizeFormatter.string(value: sizeInMB / 1024, unit: "GB")
        }
    }
}

private struct PagedMediaGroup: Identifiable {
    let index: Int
    let group: [MediaAsset]
    let selectionGroup: [MediaAsset]

    var id: Int { index }
}

private struct PrimaryBlueButtonModifier: ViewModifier {
    let width: CGFloat
    let height: CGFloat
    let font: Font

    func body(content: Content) -> some View {
        content
            .font(font)
            .foregroundStyle(.white)
            .lineLimit(1)
            .minimumScaleFactor(0.8)
            .frame(width: width, height: height)
            .background(AppConstants.accentDeepBlue, in: RoundedRectangle(cornerRadius: 7, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 7, style: .continuous)
                    .stroke(Color.black.opacity(0.18), lineWidth: 1)
            }
            .shadow(color: AppConstants.accentDeepBlue.opacity(0.24), radius: 8, y: 4)
    }
}

private extension View {
    func primaryBlueButton(width: CGFloat, height: CGFloat, font: Font) -> some View {
        modifier(PrimaryBlueButtonModifier(width: width, height: height, font: font))
    }
}

private struct DetailStatsPanel: View {
    let found: Int
    let size: String
    let selected: Int

    var body: some View {
        HStack(spacing: 0) {
            DetailStat(title: "Found", value: "\(found)", symbolName: "photo.on.rectangle", accent: AppConstants.accentDeepBlue)

            DetailDivider()

            DetailStat(title: "Size", value: size, symbolName: "externaldrive.fill", accent: HomeTheme.mint)

            DetailDivider()

            DetailStat(title: "Selected", value: "\(selected)", symbolName: "checkmark.circle.fill", accent: HomeTheme.rose)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 10)
        .frame(height: 90)
        .background(.white.opacity(0.94), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(AppConstants.border, lineWidth: 1)
        }
        .shadow(color: AppConstants.accentDeepBlue.opacity(0.08), radius: 18, y: 8)
    }
}

private struct DetailDivider: View {
    var body: some View {
        Rectangle()
            .fill(AppConstants.border.opacity(0.8))
            .frame(width: 1, height: 34)
    }
}

private struct DetailStat: View {
    let title: String
    let value: String
    let symbolName: String
    let accent: Color

    var body: some View {
        VStack(spacing: 5) {
            Image(systemName: symbolName)
                .font(.system(size: 14, weight: .black))
                .foregroundStyle(accent)
                .frame(width: 28, height: 24)
                .background(accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 8, style: .continuous))

            VStack(spacing: 1) {
                Text(title)
                    .font(.caption2.weight(.bold))
                    .foregroundStyle(AppConstants.secondaryText)
                    .lineLimit(1)
                    .minimumScaleFactor(0.82)

                Text(value)
                    .font(.subheadline.weight(.black))
                    .foregroundStyle(AppConstants.primaryText)
                    .lineLimit(1)
                    .minimumScaleFactor(0.62)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 4)
    }
}

private enum MediaSizeFormatter {
    static func string(from bytes: Float) -> String {
        let sizeInMB = bytes / (1024 * 1024)
        if sizeInMB < 1 {
            return bytes == 0 ? "0 MB" : string(value: bytes / 1024, unit: "KB")
        } else if sizeInMB < 1024 {
            return string(value: sizeInMB, unit: "MB")
        } else {
            return string(value: sizeInMB / 1024, unit: "GB")
        }
    }

    static func string(value: Float, unit: String) -> String {
        String(format: "%.1f %@", locale: Locale(identifier: "en_US_POSIX"), value, unit)
    }
}

private struct PremiumPlaceholder: View {
    let symbolName: String
    var isCompact = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    AppConstants.elevatedSurface,
                    Color(hex: "#DDF2FF"),
                    Color(hex: "#F7FCFF")
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )

            StorageHeroGrid()
                .opacity(0.16)

            RoundedRectangle(cornerRadius: isCompact ? 15 : 22, style: .continuous)
                .fill(.white.opacity(0.92))
                .frame(width: isCompact ? 58 : 86, height: isCompact ? 52 : 78)
                .shadow(color: AppConstants.accentDeepBlue.opacity(0.14), radius: 14, y: 7)

            Image(systemName: symbolName)
                .font(.system(size: isCompact ? 25 : 38, weight: .black))
                .foregroundStyle(
                    LinearGradient(
                        colors: [AppConstants.accentDeepBlue, AppConstants.accentBlue],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
        }
    }
}

private struct PremiumEmptyState: View {
    let symbolName: String
    let title: String
    let message: String

    var body: some View {
        VStack(spacing: 22) {
            PremiumPlaceholder(symbolName: symbolName)
                .frame(width: 210, height: 140)
                .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
                .shadow(color: AppConstants.accentDeepBlue.opacity(0.14), radius: 20, y: 12)

            VStack(spacing: 10) {
                Text(title)
                    .font(.title3.weight(.black))
                    .foregroundStyle(AppConstants.primaryText)
                    .multilineTextAlignment(.center)

                Text(message)
                    .font(.body.weight(.medium))
                    .foregroundStyle(AppConstants.secondaryText)
                    .multilineTextAlignment(.center)
                    .lineSpacing(3)
            }
        }
        .frame(maxWidth: .infinity)
        .frame(maxHeight: .infinity)
        .padding(.horizontal, 28)
        .padding(.vertical, 34)
        .glassCard(cornerRadius: 28)
    }
}

private struct SelectionCircle: View {
    let isSelected: Bool

    var body: some View {
        ZStack {
            Circle()
                .fill(isSelected ? AppConstants.accentDeepBlue : .white)

            Circle()
                .stroke(isSelected ? .white.opacity(0.95) : AppConstants.accentDeepBlue, lineWidth: 2.4)

            if isSelected {
                Image(systemName: "checkmark")
                    .font(.system(size: 14, weight: .black))
                    .foregroundStyle(.white)
            }
        }
        .frame(width: 30, height: 30)
        .shadow(color: .black.opacity(0.16), radius: 5, y: 3)
        .contentShape(Circle())
    }
}

private struct DetailAssetTile: View {
    let asset: MediaAsset
    let isSelected: Bool
    let isVideo: Bool
    let previewAction: () -> Void
    let selectionAction: () -> Void

    var body: some View {
        ZStack(alignment: .topTrailing) {
            ZStack {
                if let phAsset = asset.phAsset {
                    PhotoAssetThumbnail(asset: phAsset)
                } else {
                    AppConstants.elevatedSurface
                }

                if isVideo {
                    Image(systemName: "play.fill")
                        .font(.system(size: 19, weight: .black))
                        .foregroundStyle(.white)
                        .frame(width: 42, height: 42)
                        .background(.black.opacity(0.56), in: Circle())
                }

                VStack {
                    Spacer()
                    HStack {
                        Text(MediaSizeFormatter.string(from: asset.fileSize))
                            .font(.caption.weight(.black))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                            .minimumScaleFactor(0.72)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(.black.opacity(0.62), in: Capsule())
                        Spacer()
                    }
                    .padding(8)
                }
            }
            .contentShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .onTapGesture(perform: previewAction)

            Button(action: selectionAction) {
                Color.clear
                    .frame(width: 60, height: 60)
                    .overlay(alignment: .topTrailing) {
                        SelectionCircle(isSelected: isSelected)
                            .padding(.top, 10)
                            .padding(.trailing, 10)
                    }
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel(isSelected ? "Deselect item" : "Select item")
        }
        .frame(height: 156)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(isSelected ? AppConstants.accentDeepBlue : AppConstants.border, lineWidth: isSelected ? 2 : 1)
        }
    }
}

private struct MediaPreviewView: View {
    let asset: MediaAsset
    let onClose: () -> Void

    @State private var player: AVPlayer?

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color.black.ignoresSafeArea()

            if asset.assetType == .video {
                if let player {
                    VideoPlayer(player: player)
                        .ignoresSafeArea()
                        .onAppear {
                            player.play()
                        }
                } else {
                    ProgressView()
                        .tint(.white)
                }
            } else if let phAsset = asset.phAsset {
                PhotoAssetThumbnail(
                    asset: phAsset,
                    targetSize: CGSize(width: 1600, height: 1600),
                    contentMode: .fit
                )
                .ignoresSafeArea()
            } else {
                Image(systemName: asset.assetType == .video ? "film" : "photo")
                    .font(.system(size: 52, weight: .bold))
                    .foregroundStyle(.white.opacity(0.7))
            }

            Button(action: onClose) {
                Image(systemName: "xmark")
                    .font(.system(size: 17, weight: .black))
                    .foregroundStyle(.white)
                    .frame(width: 44, height: 44)
                    .background(.black.opacity(0.58), in: Circle())
                    .overlay {
                        Circle().stroke(.white.opacity(0.18), lineWidth: 1)
                    }
            }
            .buttonStyle(.plain)
            .padding(.top, 18)
            .padding(.trailing, 18)
            .accessibilityLabel("Close preview")
        }
        .onAppear(perform: loadPlayerIfNeeded)
        .onDisappear {
            player?.pause()
            player = nil
        }
    }

    private func loadPlayerIfNeeded() {
        guard asset.assetType == .video, player == nil, let phAsset = asset.phAsset else { return }

        let options = PHVideoRequestOptions()
        options.deliveryMode = .automatic
        options.isNetworkAccessAllowed = true

        PHImageManager.default().requestPlayerItem(forVideo: phAsset, options: options) { playerItem, _ in
            guard let playerItem else { return }
            DispatchQueue.main.async {
                player = AVPlayer(playerItem: playerItem)
                player?.play()
            }
        }
    }
}

private struct PhotoAssetThumbnail: View {
    @Environment(\.displayScale) private var displayScale

    let asset: PHAsset
    var targetSize = CGSize(width: 150, height: 150)
    var contentMode: ContentMode = .fill

    var body: some View {
        let pixelTargetSize = CGSize(
            width: targetSize.width * displayScale,
            height: targetSize.height * displayScale
        )
        
        Color.clear
            .overlay(
                WebImage(url: URL(string: "phasset://\(asset.localIdentifier)"), context: [.imageThumbnailPixelSize: pixelTargetSize])
                    .resizable()
                    .indicator(.activity)
                    .transition(.fade(duration: 0.15))
                    .aspectRatio(contentMode: contentMode)
            )
            .clipped()
    }
}

private enum HomeTheme {
    static let mint = Color(hex: "#10B981")
    static let rose = Color(hex: "#EF5D7A")
}
