import Photos
import SwiftUI
import UIKit
import Combine

enum HomeMediaCategory: String, CaseIterable, Identifiable {
    case similarPhotos
    case duplicatePhotos
    case screenshots
    case similarVideos
    case duplicateVideos

    var id: String { rawValue }

    var title: String {
        switch self {
        case .similarPhotos: "Similar Photos"
        case .duplicatePhotos: "Duplicate Photos"
        case .screenshots: "Screenshots"
        case .similarVideos: "Similar Videos"
        case .duplicateVideos: "Duplicate Videos"
        }
    }

    var placeholderAssetName: String {
        switch self {
        case .similarPhotos, .duplicatePhotos: "placeholder_photo"
        case .screenshots: "placeholder_screenshot"
        case .similarVideos, .duplicateVideos: "placeholder_video"
        }
    }

    var symbolName: String {
        switch self {
        case .similarPhotos, .duplicatePhotos: "photo.on.rectangle.angled"
        case .screenshots: "crop"
        case .similarVideos, .duplicateVideos: "film"
        }
    }
}

struct HomeMediaCategorySummary: Identifiable {
    let type: HomeMediaCategory
    var sizeText: String = "0 MB"
    var itemCount: Int = 0
    var thumbnailAsset: PHAsset?
    var scanResult: ScanResult?

    var id: HomeMediaCategory { type }
    var itemText: String { "\(itemCount) Items" }
}

final class HomeScanViewModel: NSObject, ObservableObject {
    @Published private(set) var progress: Float = 0
    @Published private(set) var progressText = "Starting scan..."
    @Published private(set) var isScanning = false
    @Published private(set) var isUpdatingSilently = false
    @Published private(set) var didCompleteScan = false
    @Published private(set) var permissionAlertMessage: String?
    @Published private(set) var storageInfo = DeviceStorageInfo.current()
    @Published private(set) var categories: [HomeMediaCategorySummary] = HomeMediaCategory.allCases.map {
        HomeMediaCategorySummary(type: $0)
    }

    private let scanService = CleanUPService()
    private var hasStartedScanFlow = false
    private var scanResults: [ScanResult] = []

    func beginScanFlowIfNeeded() {
        guard !hasStartedScanFlow else { return }
        hasStartedScanFlow = true
        storageInfo = DeviceStorageInfo.current()
        checkPhotoLibraryPermission()
    }

    func openSettings() {
        guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
        UIApplication.shared.open(url)
    }

    func dismissPermissionAlert() {
        permissionAlertMessage = nil
    }

    func removeAssets(with identifiers: Set<String>) {
        guard !identifiers.isEmpty else { return }
        scanResults = scanResults.map { removeAssets(from: $0, identifiers: identifiers) }
        categories = HomeMediaCategory.allCases.map { summary(for: $0, in: scanResults) }
    }

    private func checkPhotoLibraryPermission() {
        let status = PHPhotoLibrary.authorizationStatus(for: .readWrite)

        switch status {
        case .authorized, .limited:
            setupScanService()
        case .denied, .restricted:
            permissionAlertMessage = "Please enable photo library access in Settings to scan and review your media."
        case .notDetermined:
            PHPhotoLibrary.requestAuthorization(for: .readWrite) { [weak self] status in
                DispatchQueue.main.async {
                    if status == .authorized || status == .limited {
                        self?.setupScanService()
                    } else {
                        self?.permissionAlertMessage = "Photo library access is required to scan duplicate and similar media."
                    }
                }
            }
        @unknown default:
            permissionAlertMessage = "Photo permission status is unavailable. Please check Settings."
        }
    }

    private func setupScanService() {
        scanService.delegate = self
        isScanning = true
        didCompleteScan = false
        progress = 0
        progressText = "Starting scan..."
        scanResults = []
        categories = HomeMediaCategory.allCases.map { HomeMediaCategorySummary(type: $0) }
        scanService.startScan()
    }

    private func displayResults(_ results: [ScanResult]) {
        scanResults = results
        categories = HomeMediaCategory.allCases.map { summary(for: $0, in: results) }
    }

    private func updateResult(_ result: ScanResult) {
        if let index = scanResults.firstIndex(where: { category(for: $0) == category(for: result) }) {
            scanResults[index] = result
        } else {
            scanResults.append(result)
        }

        guard let type = category(for: result),
              let categoryIndex = categories.firstIndex(where: { $0.type == type }) else { return }
        categories[categoryIndex] = summary(for: type, in: scanResults)
    }

    private func summary(for type: HomeMediaCategory, in results: [ScanResult]) -> HomeMediaCategorySummary {
        guard let result = results.first(where: { category(for: $0) == type }) else {
            return HomeMediaCategorySummary(type: type)
        }

        switch result {
        case .similarPhotos(let groups),
             .duplicatePhotos(let groups),
             .similarVideos(let groups),
             .duplicateVideos(let groups):
            let assets = groups.flatMap { $0 }
            return HomeMediaCategorySummary(
                type: type,
                sizeText: formatSize(assets.reduce(0) { $0 + $1.fileSize }),
                itemCount: assets.count,
                thumbnailAsset: assets.first?.phAsset,
                scanResult: result
            )
        case .allScreenshots(let screenshots):
            return HomeMediaCategorySummary(
                type: type,
                sizeText: formatSize(screenshots.reduce(0) { $0 + $1.fileSize }),
                itemCount: screenshots.count,
                thumbnailAsset: screenshots.first?.phAsset,
                scanResult: result
            )
        }
    }

    private func category(for result: ScanResult) -> HomeMediaCategory? {
        switch result {
        case .similarPhotos: .similarPhotos
        case .duplicatePhotos: .duplicatePhotos
        case .similarVideos: .similarVideos
        case .duplicateVideos: .duplicateVideos
        case .allScreenshots: .screenshots
        }
    }

    private func formatSize(_ sizeInBytes: Float) -> String {
        let sizeInMB = sizeInBytes / (1024 * 1024)
        if sizeInMB < 1 {
            return sizeInBytes == 0 ? "0 MB" : String(format: "%.1f KB", sizeInBytes / 1024)
        } else if sizeInMB < 1024 {
            return String(format: "%.1f MB", sizeInMB)
        } else {
            return String(format: "%.1f GB", sizeInMB / 1024)
        }
    }

    private func removeAssets(from result: ScanResult, identifiers: Set<String>) -> ScanResult {
        switch result {
        case .similarPhotos(let groups):
            return .similarPhotos(removeAssets(from: groups, identifiers: identifiers))
        case .duplicatePhotos(let groups):
            return .duplicatePhotos(removeAssets(from: groups, identifiers: identifiers))
        case .similarVideos(let groups):
            return .similarVideos(removeAssets(from: groups, identifiers: identifiers))
        case .duplicateVideos(let groups):
            return .duplicateVideos(removeAssets(from: groups, identifiers: identifiers))
        case .allScreenshots(let screenshots):
            return .allScreenshots(screenshots.filter { !identifiers.contains($0.assetLocalIdentifier) })
        }
    }

    private func removeAssets(from groups: [[MediaAsset]], identifiers: Set<String>) -> [[MediaAsset]] {
        groups.compactMap { group in
            let filteredGroup = group.filter { !identifiers.contains($0.assetLocalIdentifier) }
            return filteredGroup.count >= 2 ? filteredGroup : nil
        }
    }
}

extension HomeScanViewModel: MediaScanServiceDelegate {
    func scanProgressUpdated(_ progress: Float) {
        DispatchQueue.main.async { [weak self] in
            self?.progress = progress
            self?.progressText = "Scanning... \(Int(progress * 100))%"
        }
    }

    func scanStepUpdated(_ currentStep: Int, totalSteps: Int, stepDescription: String) {
    }

    func scanCompleted(_ results: [ScanResult]) {
        DispatchQueue.main.async { [weak self] in
            self?.isScanning = false
            self?.isUpdatingSilently = false
            self?.didCompleteScan = true
            self?.progress = 1
            self?.progressText = "Scan completed!"
            self?.displayResults(results)
        }
    }

    func scanFailed(_ error: Error) {
        DispatchQueue.main.async { [weak self] in
            self?.isScanning = false
            self?.isUpdatingSilently = false
            self?.didCompleteScan = false
            self?.progressText = "Scan failed"
            self?.permissionAlertMessage = error.localizedDescription
            self?.displayResults([])
        }
    }
    
    func scanSilentStarted() {
        DispatchQueue.main.async { [weak self] in
            self?.isUpdatingSilently = true
        }
    }

    func scanResultUpdated(_ result: ScanResult, totalGroups: Int, totalSize: String) {
        DispatchQueue.main.async { [weak self] in
            self?.updateResult(result)
        }
    }
}

struct DeviceStorageInfo {
    let total: String
    let used: String
    let free: String
    let progress: Double

    var percentText: String { "\(Int(progress * 100))%" }
    var usedOfTotalText: String { "\(used) of \(total)" }

    static func current() -> DeviceStorageInfo {
        do {
            let fileURL = URL(fileURLWithPath: NSHomeDirectory())
            let values = try fileURL.resourceValues(forKeys: [
                .volumeTotalCapacityKey,
                .volumeAvailableCapacityKey
            ])

            if let totalCapacity = values.volumeTotalCapacity,
               let availableCapacity = values.volumeAvailableCapacity {
                let usedCapacity = totalCapacity - availableCapacity
                let progress = Double(usedCapacity) / Double(totalCapacity)

                return DeviceStorageInfo(
                    total: String(format: "%.0f GB", Double(totalCapacity) / 1_000_000_000),
                    used: String(format: "%.2f GB", Double(usedCapacity) / 1_000_000_000),
                    free: String(format: "%.2f GB", Double(availableCapacity) / 1_000_000_000),
                    progress: min(max(progress, 0), 1)
                )
            }
        } catch {
            print("Error fetching storage info: \(error)")
        }

        return DeviceStorageInfo(total: "N/A", used: "N/A", free: "N/A", progress: 0)
    }
}
