import SwiftUI

struct CompressView: View {
    @Environment(Router.self) private var router
    @State private var quality = 72.0
    @State private var keepOriginals = true

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    header
                    compressionCard
                    optionsCard
                    recentCard
                }
                .padding(.horizontal, 18)
                .padding(.top, 18)
                .padding(.bottom, router.isTabBarVisible ? 104 : 24)
            }
            .scrollIndicators(.hidden)
            .premiumBackground()
            .navigationTitle("Compress")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Make media lighter")
                .font(.largeTitle.weight(.bold))
                .foregroundStyle(AppConstants.primaryText)
            Text("Reduce photo and video size before sharing or archiving.")
                .font(.subheadline.weight(.medium))
                .foregroundStyle(AppConstants.secondaryText)
        }
    }

    private var compressionCard: some View {
        VStack(spacing: 18) {
            ZStack {
                Circle()
                    .stroke(AppConstants.border, lineWidth: 16)
                    .frame(width: 166, height: 166)
                Circle()
                    .trim(from: 0, to: quality / 100)
                    .stroke(
                        LinearGradient(
                            colors: [AppConstants.accentMint, AppConstants.accentDeepBlue],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        style: StrokeStyle(lineWidth: 16, lineCap: .round)
                    )
                    .rotationEffect(.degrees(-90))
                    .frame(width: 166, height: 166)

                VStack(spacing: 2) {
                    Text("\(Int(quality))%")
                        .font(.system(size: 38, weight: .black, design: .rounded))
                        .foregroundStyle(AppConstants.primaryText)
                    Text("Quality")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(AppConstants.secondaryText)
                }
            }

            Slider(value: $quality, in: 35...95, step: 1)
                .tint(AppConstants.accentDeepBlue)

            Button {
            } label: {
                Label("Choose Media", systemImage: "plus")
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                    .background(AppConstants.accentDeepBlue, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
            .buttonStyle(.pressScale)
        }
        .padding(20)
        .glassCard(cornerRadius: 22)
    }

    private var optionsCard: some View {
        VStack(spacing: 0) {
            Toggle(isOn: $keepOriginals) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Keep Originals")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(AppConstants.primaryText)
                    Text("Save compressed copies separately")
                        .font(.caption.weight(.medium))
                        .foregroundStyle(AppConstants.secondaryText)
                }
            }
            .tint(AppConstants.accentDeepBlue)
            .padding(16)
        }
        .glassCard(cornerRadius: 18)
    }

    private var recentCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Estimated Savings")
                .font(.headline.weight(.bold))
                .foregroundStyle(AppConstants.primaryText)

            HStack(spacing: 12) {
                SavingTile(title: "Photos", value: "38%", icon: "photo")
                SavingTile(title: "Videos", value: "52%", icon: "video")
            }
        }
    }
}

private struct SavingTile: View {
    let title: String
    let value: String
    let icon: String

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: icon)
                .foregroundStyle(AppConstants.accentDeepBlue)
            Text(value)
                .font(.title2.weight(.black))
                .foregroundStyle(AppConstants.primaryText)
            Text(title)
                .font(.caption.weight(.semibold))
                .foregroundStyle(AppConstants.secondaryText)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .glassCard(cornerRadius: 18)
    }
}
