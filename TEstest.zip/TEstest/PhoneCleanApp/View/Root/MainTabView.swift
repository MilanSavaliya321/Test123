import SwiftUI

struct MainTabView: View {
    @Environment(Router.self) private var router
    @State private var selectedTab: PhoneCleanerTab = .home
    @StateObject private var homeScanViewModel = HomeScanViewModel()
    @Namespace private var tabNamespace

    var body: some View {
        ZStack(alignment: .bottom) {
            Group {
                switch selectedTab {
                case .home:
                    HomeView(viewModel: homeScanViewModel)
                case .compress:
                    CompressView()
                case .settings:
                    SettingsView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            if router.isTabBarVisible {
                customTabBar
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .premiumBackground()
        .animation(.spring(response: 0.3, dampingFraction: 0.82), value: router.isTabBarVisible)
    }

    private var customTabBar: some View {
        HStack(spacing: 6) {
            ForEach(PhoneCleanerTab.allCases) { tab in
                Button {
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.76)) {
                        if selectedTab == tab {
                            router.popToRoot()
                        }
                        selectedTab = tab
                    }
                } label: {
                    VStack(spacing: 5) {
                        Image(systemName: tab.icon)
                            .font(.system(size: 19, weight: .bold))

                        Text(tab.title)
                            .font(.caption2.weight(.bold))
                    }
                    .foregroundStyle(selectedTab == tab ? AppConstants.accentDeepBlue : AppConstants.secondaryText)
                    .frame(maxWidth: .infinity)
                    .frame(height: 58)
                    .background {
                        if selectedTab == tab {
                            RoundedRectangle(cornerRadius: 18, style: .continuous)
                                .fill(AppConstants.elevatedSurface)
                                .overlay {
                                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                                        .stroke(AppConstants.border, lineWidth: 1)
                                }
                                .matchedGeometryEffect(id: "activeTab", in: tabNamespace)
                        }
                    }
                }
                .buttonStyle(.pressScale)
            }
        }
        .padding(8)
        .background(.white.opacity(0.96), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(AppConstants.border, lineWidth: 1)
        }
        .shadow(color: AppConstants.accentDeepBlue.opacity(0.14), radius: 22, x: 0, y: 12)
        .padding(.horizontal, 18)
        .padding(.bottom, 0)
    }
}

private enum PhoneCleanerTab: String, CaseIterable, Identifiable {
    case home
    case compress
    case settings

    var id: String { rawValue }

    var title: String {
        switch self {
        case .home:
            return "Home"
        case .compress:
            return "Compress"
        case .settings:
            return "Settings"
        }
    }

    var icon: String {
        switch self {
        case .home:
            return "house.fill"
        case .compress:
            return "arrow.down.forward.and.arrow.up.backward"
        case .settings:
            return "gearshape.fill"
        }
    }
}
