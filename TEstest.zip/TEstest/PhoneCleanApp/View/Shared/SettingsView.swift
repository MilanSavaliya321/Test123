import SwiftUI
import StoreKit

struct SettingsView: View {
    @Environment(Router.self) private var router
    @Environment(\.openURL) private var openURL

    private let supportEmail = Bundle.main.object(forInfoDictionaryKey: "SupportEmail") as? String ?? "bjsavaliya43@gmail.com"
    private let privacyURLString = Bundle.main.object(forInfoDictionaryKey: "PrivacyURL") as? String
    private let termsURLString = Bundle.main.object(forInfoDictionaryKey: "TermsURL") as? String

    private var appName: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as? String
            ?? "Phone Cleaner"
    }

    private var appVersionText: String {
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0"
        let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "1"
        return "Version \(version) (\(build))"
    }

    private var shareMessage: String {
        "Try \(appName) to clean storage, compress media, and keep your phone organized."
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    header
                    supportSection
                    appSection
                }
                .padding(.horizontal, 18)
                .padding(.top, 18)
                .padding(.bottom, router.isTabBarVisible ? 104 : 24)
            }
            .scrollIndicators(.hidden)
            .premiumBackground()
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private var header: some View {
        VStack(spacing: 14) {
            Image(systemName: "gearshape.fill")
                .font(.system(size: 40, weight: .bold))
                .foregroundStyle(AppConstants.accentDeepBlue)
                .frame(width: 88, height: 88)
                .background(AppConstants.elevatedSurface, in: Circle())
                .overlay {
                    Circle().stroke(AppConstants.border, lineWidth: 1)
                }

            VStack(spacing: 6) {
                Text(appName)
                    .font(.title2.weight(.bold))
                    .foregroundStyle(AppConstants.primaryText)
                Text("Support, legal links, and app details.")
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(AppConstants.secondaryText)
                    .multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 22)
        .glassCard(cornerRadius: 22)
    }

    private var supportSection: some View {
        SettingsSectionCard(title: "Support") {
            SettingsActionButton(title: "Privacy Policy", subtitle: "Read how data is handled", icon: "hand.raised.fill") {
                openInfoURL(privacyURLString)
            }

            SettingsDivider()

            SettingsActionButton(title: "Terms and Conditions", subtitle: "Review app usage terms", icon: "doc.text.fill") {
                openInfoURL(termsURLString)
            }

            SettingsDivider()

            SettingsActionButton(title: "Send Feedback", subtitle: "Share bugs, ideas, or improvements", icon: "paperplane.fill") {
                openFeedbackEmail()
            }

            SettingsDivider()

            ShareLink(item: shareMessage) {
                SettingsActionRow(
                    title: "Invite Friends",
                    subtitle: "Share Phone Cleaner with someone",
                    icon: "square.and.arrow.up.fill",
                    trailingIcon: "chevron.right"
                )
            }
            .buttonStyle(.pressScale)
        }
    }

    @State private var showingClearCacheAlert = false

    private var appSection: some View {
        SettingsSectionCard(title: "App") {
            SettingsActionButton(title: "Force Rescan", subtitle: "Clear cache and rescan all photos", icon: "arrow.triangle.2.circlepath") {
                showingClearCacheAlert = true
            }
            .alert("Clear Scan Cache?", isPresented: $showingClearCacheAlert) {
                Button("Cancel", role: .cancel) { }
                Button("Clear", role: .destructive) {
                    ScanCacheManager().clearCache()
                }
            } message: {
                Text("This will delete the saved scan results and force a full library scan next time you open the Home tab. This may take a few minutes.")
            }

            SettingsDivider()

            SettingsActionButton(title: "Check for Updates", subtitle: "Open the App Store page if available", icon: "arrow.down.circle.fill") {
                Task {
                    if let url = await VersionCheck.shared.appStoreURL() {
                        openURL(url)
                    }
                }
            }

            SettingsDivider()

            SettingsStaticRow(title: appVersionText, subtitle: "Thanks for cleaning with us", icon: "sparkles")
        }
    }

    private func openInfoURL(_ value: String?) {
        guard let value, let url = URL(string: value) else { return }
        openURL(url)
    }

    private func openFeedbackEmail() {
        let subject = "\(appName) Feedback"
        let body = "\n\nApp: \(appName)\n\(appVersionText)"
        var components = URLComponents()
        components.scheme = "mailto"
        components.path = supportEmail
        components.queryItems = [
            URLQueryItem(name: "subject", value: subject),
            URLQueryItem(name: "body", value: body)
        ]

        if let url = components.url {
            openURL(url)
        }
    }
}

private struct SettingsSectionCard<Content: View>: View {
    let title: String
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.headline.weight(.bold))
                .foregroundStyle(AppConstants.primaryText)
                .padding(.horizontal, 4)

            VStack(spacing: 0) {
                content
            }
            .padding(.vertical, 6)
            .glassCard(cornerRadius: 18)
        }
    }
}

private struct SettingsActionButton: View {
    let title: String
    let subtitle: String
    let icon: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            SettingsActionRow(title: title, subtitle: subtitle, icon: icon, trailingIcon: "chevron.right")
        }
        .buttonStyle(.pressScale)
    }
}

private struct SettingsActionRow: View {
    let title: String
    let subtitle: String
    let icon: String
    let trailingIcon: String

    var body: some View {
        HStack(spacing: 14) {
            SettingsIcon(symbol: icon)

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(AppConstants.primaryText)

                Text(subtitle)
                    .font(.caption.weight(.medium))
                    .foregroundStyle(AppConstants.secondaryText)
                    .lineLimit(2)
            }

            Spacer(minLength: 8)

            Image(systemName: trailingIcon)
                .font(.caption.weight(.bold))
                .foregroundStyle(AppConstants.accentDeepBlue)
        }
        .contentShape(Rectangle())
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
    }
}

private struct SettingsStaticRow: View {
    let title: String
    let subtitle: String
    let icon: String

    var body: some View {
        HStack(spacing: 14) {
            SettingsIcon(symbol: icon)

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(AppConstants.primaryText)

                Text(subtitle)
                    .font(.caption.weight(.medium))
                    .foregroundStyle(AppConstants.secondaryText)
            }

            Spacer(minLength: 8)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
    }
}

private struct SettingsIcon: View {
    let symbol: String

    var body: some View {
        Image(systemName: symbol)
            .font(.system(size: 16, weight: .bold))
            .foregroundStyle(AppConstants.accentDeepBlue)
            .frame(width: 38, height: 38)
            .background(AppConstants.elevatedSurface, in: Circle())
    }
}

private struct SettingsDivider: View {
    var body: some View {
        Rectangle()
            .fill(AppConstants.border)
            .frame(height: 1)
            .padding(.leading, 66)
    }
}
