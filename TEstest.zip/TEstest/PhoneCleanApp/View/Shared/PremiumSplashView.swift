import SwiftUI

enum PremiumSplashStage: Equatable {
    case booting
    case preparingServices
    case checkingUpdates
    case preparingAds
    case showingAppOpen(current: Int, total: Int)
    case openingOnboarding
    case ready

    var targetProgress: CGFloat {
        switch self {
        case .booting:
            return 0.12
        case .preparingServices:
            return 0.58
        case .checkingUpdates:
            return 0.72
        case .preparingAds:
            return 0.82
        case let .showingAppOpen(current, total):
            guard total > 0 else { return 0.88 }
            return min(0.94, 0.84 + (CGFloat(current) / CGFloat(total)) * 0.08)
        case .openingOnboarding:
            return 0.96
        case .ready:
            return 1
        }
    }

    var accessibilityDescription: String {
        switch self {
        case .booting:
            return "Preparing app"
        case .preparingServices:
            return "Preparing cleaner services"
        case .checkingUpdates:
            return "Checking app version"
        case .preparingAds:
            return "Preparing ads"
        case let .showingAppOpen(current, total):
            return "Showing app open ad \(current) of \(total)"
        case .openingOnboarding:
            return "Opening onboarding"
        case .ready:
            return "Ready"
        }
    }
}

struct PremiumSplashView: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    let stage: PremiumSplashStage

    @State private var appeared = false
    @State private var pulse = false
    @State private var displayedProgress: CGFloat = 0.06

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                LinearGradient(
                    colors: [.white, AppConstants.elevatedSurface, AppConstants.canvas],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()

                Circle()
                    .fill(AppConstants.accentBlue.opacity(pulse ? 0.18 : 0.08))
                    .frame(width: proxy.size.width * 0.95)
                    .blur(radius: 34)
                    .offset(x: pulse && !reduceMotion ? 84 : -78, y: -proxy.size.height * 0.22)

                VStack(spacing: 0) {
                    Spacer(minLength: proxy.size.height * 0.18)

                    logo
                        .scaleEffect(appeared ? 1 : 0.82)
                        .opacity(appeared ? 1 : 0)

                    VStack(spacing: 10) {
                        Text("Phone Cleaner")
                            .font(.system(size: 36, weight: .black, design: .rounded))
                            .foregroundStyle(AppConstants.primaryText)
                            .lineLimit(1)
                            .minimumScaleFactor(0.72)

                        Text("Clean storage, compress media, stay organized.")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(AppConstants.secondaryText)
                            .multilineTextAlignment(.center)
                    }
                    .padding(.top, 26)
                    .padding(.horizontal, 28)
                    .opacity(appeared ? 1 : 0)

                    HStack(spacing: 10) {
                        splashPill("Scan", icon: "wand.and.stars")
                        splashPill("Compress", icon: "arrow.down.forward.and.arrow.up.backward")
                        splashPill("Review", icon: "checkmark.shield.fill")
                    }
                    .padding(.top, 24)
                    .opacity(appeared ? 1 : 0)

                    Spacer(minLength: 42)

                    stagePanel
                        .padding(.horizontal, 24)
                        .padding(.bottom, max(proxy.safeAreaInsets.bottom + 30, 48))
                        .opacity(appeared ? 1 : 0)
                }
            }
        }
        .preferredColorScheme(.light)
        .accessibilityElement(children: .contain)
        .accessibilityLabel(stage.accessibilityDescription)
        .onAppear(perform: start)
        .task(id: stage) {
            await animateProgress(to: stage.targetProgress)
        }
    }

    private var logo: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 34, style: .continuous)
                .fill(.white)
                .frame(width: 150, height: 150)
                .overlay {
                    RoundedRectangle(cornerRadius: 34, style: .continuous)
                        .stroke(AppConstants.border, lineWidth: 1.4)
                }
                .shadow(color: AppConstants.accentDeepBlue.opacity(0.16), radius: 28, y: 16)

            Image(systemName: "sparkles.rectangle.stack.fill")
                .font(.system(size: 68, weight: .bold))
                .foregroundStyle(
                    LinearGradient(
                        colors: [AppConstants.accentBlue, AppConstants.accentDeepBlue],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .scaleEffect(pulse && !reduceMotion ? 1.04 : 0.98)
        }
        .accessibilityHidden(true)
    }

    private func splashPill(_ title: String, icon: String) -> some View {
        Label(title, systemImage: icon)
            .font(.caption.weight(.bold))
            .foregroundStyle(AppConstants.accentDeepBlue)
            .lineLimit(1)
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
            .background(.white.opacity(0.9), in: Capsule(style: .continuous))
            .overlay {
                Capsule(style: .continuous)
                    .stroke(AppConstants.border, lineWidth: 1)
            }
    }

    private var stagePanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text(stageTitle)
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(AppConstants.primaryText)
                Spacer()
                Text("\(Int(displayedProgress * 100))%")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(AppConstants.accentDeepBlue)
            }

            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    Capsule()
                        .fill(AppConstants.border)
                    Capsule()
                        .fill(
                            LinearGradient(
                                colors: [AppConstants.accentBlue, AppConstants.accentDeepBlue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .frame(width: geometry.size.width * displayedProgress)
                }
            }
            .frame(height: 9)

            Text(stageSubtitle)
                .font(.caption.weight(.medium))
                .foregroundStyle(AppConstants.secondaryText)
        }
        .padding(18)
        .glassCard(cornerRadius: 20)
    }

    private var stageTitle: String {
        switch stage {
        case .booting:
            return "Starting Phone Cleaner"
        case .preparingServices:
            return "Preparing services"
        case .checkingUpdates:
            return "Checking updates"
        case .preparingAds:
            return "Preparing experience"
        case let .showingAppOpen(current, total):
            return "Loading sponsor \(current) of \(total)"
        case .openingOnboarding:
            return "Opening guide"
        case .ready:
            return "Ready"
        }
    }

    private var stageSubtitle: String {
        switch stage {
        case .booting:
            return "Getting the app ready."
        case .preparingServices:
            return "Loading remote config and ad services."
        case .checkingUpdates:
            return "Making sure this version can continue."
        case .preparingAds:
            return "Preparing launch ads when available."
        case .showingAppOpen:
            return "This will continue automatically."
        case .openingOnboarding:
            return "A quick setup guide is next."
        case .ready:
            return "Opening your cleaner dashboard."
        }
    }

    private func start() {
        withAnimation(.spring(response: 0.7, dampingFraction: 0.82)) {
            appeared = true
        }
        withAnimation(.easeInOut(duration: 2.2).repeatForever(autoreverses: true)) {
            pulse = true
        }
    }

    private func animateProgress(to target: CGFloat) async {
        await MainActor.run {
            withAnimation(.easeInOut(duration: 0.42)) {
                displayedProgress = target
            }
        }
    }
}
