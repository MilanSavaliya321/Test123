import SwiftUI

struct NoInternetView: View {
    let onRetry: () -> Void

    @State private var isChecking = false
    @State private var appeared = false
    @State private var showFailed = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.white, AppConstants.elevatedSurface, AppConstants.canvas],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 26) {
                Spacer()

                Image(systemName: "wifi.slash")
                    .font(.system(size: 46, weight: .bold))
                    .foregroundStyle(AppConstants.accentDeepBlue)
                    .frame(width: 104, height: 104)
                    .background(.white, in: Circle())
                    .overlay {
                        Circle().stroke(AppConstants.border, lineWidth: 1)
                    }
                    .shadow(color: AppConstants.accentDeepBlue.opacity(0.16), radius: 22, y: 12)
                    .scaleEffect(appeared ? 1 : 0.82)

                VStack(spacing: 10) {
                    Text("No Internet Connection")
                        .font(.title2.weight(.bold))
                        .foregroundStyle(AppConstants.primaryText)
                        .multilineTextAlignment(.center)

                    Text("Phone Cleaner needs a connection to finish startup. Check Wi-Fi or mobile data and try again.")
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(AppConstants.secondaryText)
                        .multilineTextAlignment(.center)
                        .lineSpacing(4)
                }
                .padding(.horizontal, 34)

                if showFailed {
                    Label("Still offline. Try again.", systemImage: "exclamationmark.triangle.fill")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(Color(hex: "#F59E0B"))
                        .transition(.opacity.combined(with: .offset(y: 6)))
                }

                Button(action: retry) {
                    ZStack {
                        if isChecking {
                            ProgressView()
                                .tint(.white)
                        } else {
                            Label("Retry", systemImage: "arrow.clockwise")
                        }
                    }
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 54)
                    .background(AppConstants.accentDeepBlue, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .shadow(color: AppConstants.accentDeepBlue.opacity(0.22), radius: 18, y: 10)
                }
                .disabled(isChecking)
                .buttonStyle(.pressScale)
                .padding(.horizontal, 36)

                Spacer()
                Spacer()
            }
            .opacity(appeared ? 1 : 0)
            .offset(y: appeared ? 0 : 14)
        }
        .preferredColorScheme(.light)
        .onAppear {
            withAnimation(.spring(response: 0.65, dampingFraction: 0.82)) {
                appeared = true
            }
        }
    }

    private func retry() {
        withAnimation { showFailed = false }
        isChecking = true

        Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(1500))
            isChecking = false
            if NetworkMonitor.shared.isConnected {
                onRetry()
            } else {
                withAnimation(.spring(response: 0.4, dampingFraction: 0.78)) {
                    showFailed = true
                }
            }
        }
    }
}
