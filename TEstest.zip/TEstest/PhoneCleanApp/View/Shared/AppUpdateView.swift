import SwiftUI

struct AppUpdateView: View {
    let appStoreURL: URL

    @State private var appeared = false

    private let features = [
        ("sparkles", "Cleaner recommendations"),
        ("arrow.down.forward.and.arrow.up.backward", "Better compression flow"),
        ("shield.checkered", "Security and stability fixes")
    ]

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.white, AppConstants.elevatedSurface, AppConstants.canvas],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                Spacer()

                Image(systemName: "arrow.up.circle.fill")
                    .font(.system(size: 54, weight: .bold))
                    .foregroundStyle(AppConstants.accentDeepBlue)
                    .frame(width: 112, height: 112)
                    .background(.white, in: Circle())
                    .overlay {
                        Circle().stroke(AppConstants.border, lineWidth: 1)
                    }
                    .shadow(color: AppConstants.accentDeepBlue.opacity(0.16), radius: 22, y: 12)

                VStack(spacing: 10) {
                    Text("Update Available")
                        .font(.title.weight(.black))
                        .foregroundStyle(AppConstants.primaryText)
                        .multilineTextAlignment(.center)

                    Text("A new version of Phone Cleaner is ready. Please update to continue.")
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(AppConstants.secondaryText)
                        .multilineTextAlignment(.center)
                        .lineSpacing(4)
                }
                .padding(.top, 28)
                .padding(.horizontal, 36)

                VStack(alignment: .leading, spacing: 14) {
                    Text("What's New")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(AppConstants.accentDeepBlue)
                        .textCase(.uppercase)

                    ForEach(features, id: \.0) { icon, text in
                        HStack(spacing: 12) {
                            Image(systemName: icon)
                                .font(.system(size: 14, weight: .bold))
                                .foregroundStyle(AppConstants.accentDeepBlue)
                                .frame(width: 32, height: 32)
                                .background(AppConstants.elevatedSurface, in: RoundedRectangle(cornerRadius: 10, style: .continuous))

                            Text(text)
                                .font(.subheadline.weight(.medium))
                                .foregroundStyle(AppConstants.primaryText)
                        }
                    }
                }
                .padding(20)
                .glassCard(cornerRadius: 20)
                .padding(.horizontal, 28)
                .padding(.top, 30)

                Button {
                    UIApplication.shared.open(appStoreURL)
                } label: {
                    Label("Update Now", systemImage: "arrow.up.circle.fill")
                        .font(.headline.weight(.bold))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 54)
                        .background(AppConstants.accentDeepBlue, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .shadow(color: AppConstants.accentDeepBlue.opacity(0.22), radius: 18, y: 10)
                }
                .buttonStyle(.pressScale)
                .padding(.horizontal, 36)
                .padding(.top, 30)

                Text("This update is required to use Phone Cleaner")
                    .font(.caption.weight(.medium))
                    .foregroundStyle(AppConstants.secondaryText)
                    .padding(.top, 14)

                Spacer()
            }
            .opacity(appeared ? 1 : 0)
            .offset(y: appeared ? 0 : 16)
        }
        .preferredColorScheme(.light)
        .onAppear {
            withAnimation(.spring(response: 0.72, dampingFraction: 0.82)) {
                appeared = true
            }
        }
    }
}
