import UIKit
import SwiftUI
import Network

// MARK: - AppOverlayWindowManager
// Single manager for all "blocking" full-screen overlays that must appear
// above EVERY UIKit and SwiftUI layer (camera VC, onboarding cover, paywall, etc.)
// Uses UIWindow.Level.alert + 10 so nothing can sit on top.

@MainActor
final class AppOverlayWindowManager {

    static let shared = AppOverlayWindowManager()

    private var overlayWindow: UIWindow?

    // Callbacks wired by the root app view.
    var onNetworkRetry: (() -> Void)?

    private(set) var currentKind: OverlayKind? = nil

    enum OverlayKind { case noInternet, forceUpdate }

    private init() {}

    // MARK: - No Internet

    func showNoInternet() {
        guard currentKind != .noInternet else { return }
        let view = NoInternetView(onRetry: { [weak self] in
            self?.hideOverlay()
            self?.onNetworkRetry?()
        })
        present(AnyView(view), kind: .noInternet)
    }

    func hideNoInternet() {
        guard currentKind == .noInternet else { return }
        hideOverlay()
    }

    // MARK: - Force Update

    func showForceUpdate(appStoreURL: URL) {
        guard currentKind != .forceUpdate else { return }
        let view = AppUpdateView(appStoreURL: appStoreURL)
        // Force-update can sit on top of the no-internet overlay too
        present(AnyView(view), kind: .forceUpdate)
    }

    // MARK: - Private

    private func present(_ view: AnyView, kind: OverlayKind) {
        // Tear down any existing overlay first
        hideOverlay()

        guard let windowScene = UIApplication.shared
            .connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .first
        else { return }

        let hc = UIHostingController(rootView: view)
        hc.view.backgroundColor = .clear

        let win = UIWindow(windowScene: windowScene)
        win.windowLevel = UIWindow.Level.alert + 10   // Above everything
        win.rootViewController = hc
        win.backgroundColor = .clear
        win.isHidden = false
        win.makeKeyAndVisible()

        overlayWindow = win
        currentKind = kind
    }

    private func hideOverlay() {
        overlayWindow?.isHidden = true
        overlayWindow?.rootViewController = nil
        overlayWindow = nil
        currentKind = nil
    }
}

// MARK: - NetworkOverlayCoordinator
// Observes NWPathMonitor and drives the no-internet overlay automatically.
// Must be started AFTER the initial startup sequence finishes so it doesn't
// interfere with the splash/GDPR/ad flows.

@MainActor
final class NetworkOverlayCoordinator {

    static let shared = NetworkOverlayCoordinator()
    private var monitor: NWPathMonitor?
    private let queue = DispatchQueue(label: "deep.clean.my.phone.net-overlay")

    /// Activate only after startup. The coordinator is a no-op until then.
    var isActive = false

    private init() {}

    func start() {
        guard monitor == nil else { return }
        let m = NWPathMonitor()
        m.pathUpdateHandler = { [weak self] path in
            Task { @MainActor [weak self] in
                guard let self, self.isActive else { return }
                // Don't interrupt a force-update overlay
                guard AppOverlayWindowManager.shared.currentKind != .forceUpdate else { return }

                if path.status != .satisfied {
                    AppOverlayWindowManager.shared.showNoInternet()
                } else {
                    AppOverlayWindowManager.shared.hideNoInternet()
                }
            }
        }
        m.start(queue: queue)
        monitor = m
    }
}

// Keep this alias so old call-sites compile without changes
typealias NetworkOverlayWindow = AppOverlayWindowManager
extension AppOverlayWindowManager {
    /// Convenience — matches old NetworkOverlayWindow.shared.show() calls
    func show() { showNoInternet() }
    /// Convenience — matches old NetworkOverlayWindow.shared.hide() calls
    func hide() { hideNoInternet() }
    /// Convenience — old onRetry property name
    var onRetry: (() -> Void)? {
        get { onNetworkRetry }
        set { onNetworkRetry = newValue }
    }
}
