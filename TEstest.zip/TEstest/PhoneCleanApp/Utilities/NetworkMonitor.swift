import Foundation
import Network
import Observation
import os

@MainActor
@Observable
final class NetworkMonitor {
    static let shared = NetworkMonitor()

    private(set) var isConnected = true

    @ObservationIgnored private let monitor: NWPathMonitor
    @ObservationIgnored private let queue = DispatchQueue(label: "deep.clean.my.phone.network-monitor")
    @ObservationIgnored private let logger = Logger(subsystem: "deep.clean.my.phone", category: "network")

    private init() {
        monitor = NWPathMonitor()
        monitor.pathUpdateHandler = { [weak self] path in
            Task { @MainActor [weak self] in
                guard let self else { return }
                let nextValue = path.status == .satisfied
                if self.isConnected != nextValue {
                    self.logger.info("Network connectivity changed: \(nextValue, privacy: .public)")
                }
                self.isConnected = nextValue
            }
        }
        monitor.start(queue: queue)
    }

    deinit {
        monitor.cancel()
    }
}
