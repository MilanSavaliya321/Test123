import Foundation

struct ScanCacheManager: Sendable {
    nonisolated init() {}
    
    nonisolated private var fileManager: FileManager { FileManager.default }
    
    nonisolated private var cacheDirectory: URL {
        let paths = fileManager.urls(for: .documentDirectory, in: .userDomainMask)
        let docDir = paths[0]
        let cacheDir = docDir.appendingPathComponent("ScanCache")
        
        if !fileManager.fileExists(atPath: cacheDir.path) {
            try? fileManager.createDirectory(at: cacheDir, withIntermediateDirectories: true, attributes: nil)
        }
        
        return cacheDir
    }
    
    nonisolated private var resultsFileURL: URL { cacheDirectory.appendingPathComponent("scanResults.json") }
    nonisolated private var assetsFileURL: URL { cacheDirectory.appendingPathComponent("mediaAssets.json") }
    nonisolated private var fingerprintsFileURL: URL { cacheDirectory.appendingPathComponent("fingerprints.json") }
    
    // MARK: - Save
    
    nonisolated func saveCache(results: [ScanResult], assets: [String: MediaAsset], fingerprints: [String: ImageFingerprint]) {
        let encoder = JSONEncoder()
        
        let localResultsURL = self.resultsFileURL
        let localAssetsURL = self.assetsFileURL
        let localFingerprintsURL = self.fingerprintsFileURL
        
        DispatchQueue.global(qos: .background).async {
            do {
                let resultsData = try encoder.encode(results)
                try resultsData.write(to: localResultsURL)
                
                let assetsData = try encoder.encode(assets)
                try assetsData.write(to: localAssetsURL)
                
                let fingerprintsData = try encoder.encode(fingerprints)
                try fingerprintsData.write(to: localFingerprintsURL)
                
                print("@@@ ScanCacheManager: Cache saved successfully")
            } catch {
                print("@@@ ScanCacheManager: Error saving cache - \(error)")
            }
        }
    }
    
    // MARK: - Load
    
    nonisolated func loadCache() -> (results: [ScanResult]?, assets: [String: MediaAsset]?, fingerprints: [String: ImageFingerprint]?) {
        let decoder = JSONDecoder()
        let fm = self.fileManager
        
        var loadedResults: [ScanResult]?
        var loadedAssets: [String: MediaAsset]?
        var loadedFingerprints: [String: ImageFingerprint]?
        
        do {
            if fm.fileExists(atPath: resultsFileURL.path) {
                let data = try Data(contentsOf: resultsFileURL)
                loadedResults = try decoder.decode([ScanResult].self, from: data)
            }
            
            if fm.fileExists(atPath: assetsFileURL.path) {
                let data = try Data(contentsOf: assetsFileURL)
                loadedAssets = try decoder.decode([String: MediaAsset].self, from: data)
            }
            
            if fm.fileExists(atPath: fingerprintsFileURL.path) {
                let data = try Data(contentsOf: fingerprintsFileURL)
                loadedFingerprints = try decoder.decode([String: ImageFingerprint].self, from: data)
            }
        } catch {
            print("@@@ ScanCacheManager: Error loading cache - \(error)")
        }
        
        return (loadedResults, loadedAssets, loadedFingerprints)
    }
    
    // MARK: - Clear
    
    nonisolated func clearCache() {
        let fm = self.fileManager
        try? fm.removeItem(at: resultsFileURL)
        try? fm.removeItem(at: assetsFileURL)
        try? fm.removeItem(at: fingerprintsFileURL)
        print("@@@ ScanCacheManager: Cache cleared")
    }
    
    // MARK: - Cache Filtering
    
    nonisolated func filterDeletedAssets(
        currentIdentifiers: Set<String>,
        cachedResults: [ScanResult],
        cachedAssets: [String: MediaAsset],
        cachedFingerprints: [String: ImageFingerprint]
    ) -> (results: [ScanResult], assets: [String: MediaAsset], fingerprints: [String: ImageFingerprint]) {
        
        // Filter assets
        var newAssets = cachedAssets
        var newFingerprints = cachedFingerprints
        
        let deletedIdentifiers = Set(cachedAssets.keys).subtracting(currentIdentifiers)
        
        guard !deletedIdentifiers.isEmpty else {
            return (cachedResults, cachedAssets, cachedFingerprints)
        }
        
        print("@@@ ScanCacheManager: Found \(deletedIdentifiers.count) deleted assets in cache, removing...")
        
        for id in deletedIdentifiers {
            newAssets.removeValue(forKey: id)
            newFingerprints.removeValue(forKey: id)
        }
        
        // Filter results
        var newResults: [ScanResult] = []
        
        for result in cachedResults {
            switch result {
            case .similarPhotos(let groups):
                let filteredGroups = groups.map { $0.filter { !deletedIdentifiers.contains($0.assetLocalIdentifier) } }.filter { $0.count > 1 }
                if !filteredGroups.isEmpty { newResults.append(.similarPhotos(filteredGroups)) }
            case .duplicatePhotos(let groups):
                let filteredGroups = groups.map { $0.filter { !deletedIdentifiers.contains($0.assetLocalIdentifier) } }.filter { $0.count > 1 }
                if !filteredGroups.isEmpty { newResults.append(.duplicatePhotos(filteredGroups)) }
            case .similarVideos(let groups):
                let filteredGroups = groups.map { $0.filter { !deletedIdentifiers.contains($0.assetLocalIdentifier) } }.filter { $0.count > 1 }
                if !filteredGroups.isEmpty { newResults.append(.similarVideos(filteredGroups)) }
            case .duplicateVideos(let groups):
                let filteredGroups = groups.map { $0.filter { !deletedIdentifiers.contains($0.assetLocalIdentifier) } }.filter { $0.count > 1 }
                if !filteredGroups.isEmpty { newResults.append(.duplicateVideos(filteredGroups)) }
            case .allScreenshots(let items):
                let filteredItems = items.filter { !deletedIdentifiers.contains($0.assetLocalIdentifier) }
                if !filteredItems.isEmpty { newResults.append(.allScreenshots(filteredItems)) }
            }
        }
        
        return (newResults, newAssets, newFingerprints)
    }
}
