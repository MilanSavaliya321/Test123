import Foundation

/// Stub for IAPurchaseHelper — no in-app purchases in this app.
/// Always returns `false` for `isSubscribed` so ads flow works normally.
@MainActor
final class IAPurchaseHelper {
    static let shared = IAPurchaseHelper()
    
    var isSubscribed: Bool { false }
    
    private init() {}
}
