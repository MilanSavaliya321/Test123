//
//  LocalNotificationManager.swift
//  PhoneCleanApp
//
//  Created by MAC on 18/05/26.
//


import Foundation
import UserNotifications

import UIKit

final class LocalNotificationManager: NSObject, UNUserNotificationCenterDelegate, @unchecked Sendable {
    static let shared = LocalNotificationManager()
    
    private let lastScheduleDateKey = "lastLocalNotificationScheduleDate"
    
    private override init() { super.init() }
    
    // MARK: - Permission
    
    func requestNotificationPermission() {
        let notificationCenter = UNUserNotificationCenter.current()
        notificationCenter.delegate = self
        
        let authorizationOptions: UNAuthorizationOptions = [.alert, .sound, .badge]
        
        notificationCenter.requestAuthorization(options: authorizationOptions) { isGranted, error in
            
            if let error = error {
                print("❌ Notification permission error: \(error)")
                return
            }
            
            guard isGranted else {
                print("🚫 Notification permission denied")
                return
            }
            
            DispatchQueue.main.async {
                UIApplication.shared.registerForRemoteNotifications()
                
                // Updated class name
                LocalNotificationManager.shared.scheduleDailyNotifications()
            }
        }
    }
    
    // MARK: - Validation
    
    /// Call this from AppDelegate / SceneDelegate
    func validateAndRescheduleIfNeeded() {
        guard let lastScheduledDate = UserDefaults.standard.object(forKey: lastScheduleDateKey) as? Date else {
            scheduleDailyNotifications()
            return
        }
        
        let daysPassed = Calendar.current.dateComponents(
            [.day],
            from: lastScheduledDate,
            to: Date()
        ).day ?? 0
        
        // Reschedule after 8 days (10-day cycle with buffer)
        if daysPassed >= 8 {
            print("🔄 Rescheduling local notifications...")
            scheduleDailyNotifications()
        } else {
            print("✅ Notifications valid (\(10 - daysPassed) days remaining)")
        }
    }
    
    func scheduleDailyNotifications() {
        DispatchQueue.global(qos: .background).async {
            let notificationCenter = UNUserNotificationCenter.current()
            
            // Remove old notifications
            notificationCenter.removeAllPendingNotificationRequests()
            
            // Save schedule date
            UserDefaults.standard.set(Date(), forKey: self.lastScheduleDateKey)
            
            let notificationMessages = [
                ("Storage check", "Open Phone Cleaner to review duplicate photos and large videos."),
                ("Quick cleanup", "A short scan can help find space you may be able to recover."),
                ("Compress media", "Shrink photos and videos before sharing or archiving."),
                ("Review screenshots", "Old screenshots can add up. Review them when you have a minute."),
                ("Large videos", "Find heavy clips and decide what to keep."),
                ("Keep originals safe", "Compress copies while keeping originals available for review."),
                ("Photo cleanup", "Similar photos are easier to compare inside Phone Cleaner."),
                ("Weekend tidy-up", "Make a little storage space before capturing new memories."),
                ("Storage reminder", "Check your cleanup suggestions and keep your phone organized."),
                ("Smart scan", "Run a scan to see where your largest savings may be."),
                ("Media size check", "Find photos and videos that are taking more space than expected."),
                ("Clean with control", "Review every item before deleting or compressing."),
                ("Free up space", "A few minutes in Phone Cleaner can help clear old clutter."),
                ("Compress videos", "Lower video size while keeping a practical quality balance."),
                ("Organize media", "Keep photos, videos, and screenshots easier to manage."),
                ("Scan today", "Fresh suggestions are ready when you open Phone Cleaner."),
                ("Check storage", "Review your largest cleanup categories."),
                ("Small cleanup", "Start with screenshots for a quick storage win."),
                ("Stay organized", "A regular review keeps storage easier to manage."),
                ("Ready to clean", "Open Phone Cleaner and start a smart scan.")
            ]
            
            let notificationTimes: [(hour: Int, minute: Int)] = [
                (12, 0),
                (20, 0)
            ]
            
            var messageIndex = 0
            
            for dayOffset in 0..<10 {
                for (timeSlotIndex, time) in notificationTimes.enumerated() {
                    
                    guard messageIndex < notificationMessages.count else { break }
                    
                    let message = notificationMessages[messageIndex]
                    
                    let content = UNMutableNotificationContent()
                    content.title = message.0
                    content.body = message.1
                    content.sound = .default
                    
                    guard let scheduledDate = Calendar.current.date(
                        byAdding: .day,
                        value: dayOffset,
                        to: Date()
                    ) else { continue }
                    
                    var components = Calendar.current.dateComponents(
                        [.year, .month, .day],
                        from: scheduledDate
                    )
                    components.hour = time.hour
                    components.minute = time.minute
                    
                    let trigger = UNCalendarNotificationTrigger(
                        dateMatching: components,
                        repeats: false
                    )
                    
                    let identifier = "localNotification_day\(dayOffset)_slot\(timeSlotIndex)"
                    
                    let request = UNNotificationRequest(
                        identifier: identifier,
                        content: content,
                        trigger: trigger
                    )
                    
                    notificationCenter.add(request)
                    messageIndex += 1
                }
            }
            
            print("✅ Scheduled 20 local notifications (10 days × 2 per day) in background")
        }
    }
    
    // MARK: - UNUserNotificationCenterDelegate
    
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        // Show banner and play sound even if app is in foreground
        if #available(iOS 14.0, *) {
            completionHandler([.banner, .sound, .badge])
        } else {
            completionHandler([.alert, .sound, .badge])
        }
    }
    
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        didReceive response: UNNotificationResponse,
        withCompletionHandler completionHandler: @escaping () -> Void
    ) {
        print("👆 User tapped notification: \(response.notification.request.identifier)")
        // Add navigation or deep link logic here if needed in the future
        completionHandler()
    }
}
