//
//  RatingManager.swift
//  PhoneCleanApp
//
//  Created by MAC on 30/05/26.
//


import UIKit
import StoreKit

/// Shows the App Store rating dialog after every save and every purchase.
@MainActor
final class RatingManager {

    static let shared = RatingManager()
    private init() {}

    /// Set to `true` once the splash / onboarding flow is done
    /// and the main tab bar is visible to the user.
    var isAppReady = false

    private var reviewTask: Task<Void, Never>?

    /// Call after every successful income / expense / goal save.
    func recordSave() {
        requestReviewSoon()
    }

    /// Call after every successful purchase or restore.
    func recordPurchase() {
        requestReviewSoon(after: .seconds(1))
    }

    func requestReviewSoon(after delay: Duration = .seconds(1)) {
        guard RCManager.shared.showRatingPrompt else { return }
        guard isAppReady else { return }   // ignore calls during splash / onboarding
        reviewTask?.cancel()
        reviewTask = Task { @MainActor in
            do {
                try await Task.sleep(for: delay)
            } catch {
                return // Task was cancelled by another save
            }
            
            guard !Task.isCancelled else { return }
            
            if UserDefaults.standard.bool(forKey: "hasAgreedToLoveApp") {
                if let scene = UIApplication.shared.connectedScenes.first(where: { $0.activationState == .foregroundActive }) as? UIWindowScene {
                    SKStoreReviewController.requestReview(in: scene)
                }
            } else {
                showRatingPrompt()
            }
        }
    }
    
    private func showRatingPrompt() {
        let alert = UIAlertController(
            title: "❤️ Do you love our app?",
            message: "Your feedback helps us grow!",
            preferredStyle: .alert
        )
        
        let noAction = UIAlertAction(title: "No 😕", style: .cancel) { _ in
            LocalNotificationManager.shared.requestNotificationPermission()
        }
        
        let yesAction = UIAlertAction(title: "Yes 😍", style: .default) { _ in
            UserDefaults.standard.set(true, forKey: "hasAgreedToLoveApp")
            if let scene = UIApplication.shared.connectedScenes.first(where: { $0.activationState == .foregroundActive }) as? UIWindowScene {
                SKStoreReviewController.requestReview(in: scene)
            }
        }
        
        alert.addAction(noAction)
        alert.addAction(yesAction)
        
        AdsManager.gettopViewController().present(alert, animated: true, completion: nil)
    }
}
