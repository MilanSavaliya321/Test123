import Foundation
import UserNotifications

@MainActor
final class NotificationScheduler {
    static let shared = NotificationScheduler()
    
    private let lastScheduledKey = "lastNotificationScheduledDate"
    
    private init() {}
    
    func requestNotificationPermission(completion: @escaping @Sendable (Bool) -> Void) {
        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if let error = error {
                print("Error requesting notification permission: \(error)")
            }
            completion(granted)
        }
    }
    
    // Call this in AppDelegate or SceneDelegate
    func checkAndRescheduleIfNeeded() {
        guard let lastScheduled = UserDefaults.standard.object(forKey: lastScheduledKey) as? Date else {
            // First time - schedule notifications
            scheduleNotifications()
            return
        }
        
        let daysSinceScheduled = Calendar.current.dateComponents(
            [.day],
            from: lastScheduled,
            to: Date()
        ).day ?? 0
        
        // If 8+ days passed, reschedule (gives 2 days buffer)
        if daysSinceScheduled >= 8 {
            print("🔄 Rescheduling notifications...")
            scheduleNotifications()
        } else {
            print("✅ Notifications still valid (\(10 - daysSinceScheduled) days remaining)")
        }
    }
    
    func scheduleNotifications() {
        let center = UNUserNotificationCenter.current()
        
        // Cancel old notifications first
        center.removeAllPendingNotificationRequests()
        
        // Save current date
        UserDefaults.standard.set(Date(), forKey: lastScheduledKey)
        
        let notifications = [
            ("Storage check", "Open Phone Cleaner to review duplicate photos and large videos."),
            ("Quick cleanup", "A short scan can help find space you may be able to recover."),
            ("Compress media", "Shrink photos and videos before sharing or archiving."),
            ("Review screenshots", "Old screenshots can add up. Review them when you have a minute."),
            ("Large videos", "Find heavy clips and decide what to keep."),
            ("Keep originals safe", "Compress copies while keeping originals available for review."),
            ("Photo cleanup", "Similar photos are easier to compare inside Phone Cleaner."),
            ("Weekend tidy-up", "Make a little storage space before capturing new memories."),
            ("Storage reminder", "Check your cleanup suggestions and keep your phone organized."),
            ("Smart scan", "Run a scan to see where your largest savings may be."),
            ("Media size check", "Find photos and videos that are taking more space than expected."),
            ("Clean with control", "Review every item before deleting or compressing."),
            ("Free up space", "A few minutes in Phone Cleaner can help clear old clutter."),
            ("Compress videos", "Lower video size while keeping a practical quality balance."),
            ("Organize media", "Keep photos, videos, and screenshots easier to manage."),
            ("Scan today", "Fresh suggestions are ready when you open Phone Cleaner."),
            ("Check storage", "Review your largest cleanup categories."),
            ("Small cleanup", "Start with screenshots for a quick storage win."),
            ("Stay organized", "A regular review keeps storage easier to manage."),
            ("Ready to clean", "Open Phone Cleaner and start a smart scan.")
        ]
        
        let dailyTimes: [(hour: Int, minute: Int)] = [
            (9, 0),
            (20, 0)
        ]
        
        var notificationIndex = 0
        
        for day in 0..<10 {
            for (timeIndex, time) in dailyTimes.enumerated() {
                guard notificationIndex < notifications.count else { break }
                
                let notification = notifications[notificationIndex]
                
                let content = UNMutableNotificationContent()
                content.title = notification.0
                content.body = notification.1
                content.sound = .default
                
                guard let triggerDate = Calendar.current.date(
                    byAdding: .day,
                    value: day,
                    to: Date()
                ) else { continue }
                
                var dateComponents = Calendar.current.dateComponents(
                    [.year, .month, .day],
                    from: triggerDate
                )
                dateComponents.hour = time.hour
                dateComponents.minute = time.minute
                
                let trigger = UNCalendarNotificationTrigger(
                    dateMatching: dateComponents,
                    repeats: false
                )
                
                let identifier = "notification-day\(day)-time\(timeIndex)"
                let request = UNNotificationRequest(
                    identifier: identifier,
                    content: content,
                    trigger: trigger
                )
                
                center.add(request)
                notificationIndex += 1
            }
        }
        
        print("✅ 20 notifications scheduled for next 10 days")
    }
}
