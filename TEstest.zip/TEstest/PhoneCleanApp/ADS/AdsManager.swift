import GoogleMobileAds
import UIKit
import Foundation

// MARK: - Thread-Safe NSLock Extension
extension NSLock {
    @discardableResult
    func sync<T>(execute work: () -> T) -> T {
        lock()
        defer { unlock() }
        return work()
    }
}

// MARK: - Enums & Models
enum AdType: String, CaseIterable {
    case interstitial = "int"
    case rewardAd = "reward"
    case nativeAd = "native"
    case banner = "banner"
    case appOpenAd = "app_open"
}

// MARK: - Ad Event Completion
struct AdEventCompletion {
    var onRequest: (() -> Void)?
    var onLoaded: (() -> Void)?
    var onFail: ((Error) -> Void)?
    var onShow: (() -> Void)?
    var onClose: (() -> Void)?
    var onImpression: (() -> Void)?
    var onClick: (() -> Void)?
    var onBannerLoaded: ((UIView) -> Void)?
    var onNativeAdLoaded: ((NativeAd) -> Void)?
}

// MARK: - AdType Extension for Fullscreen Check
extension AdType {
    var isFullScreen: Bool {
        switch self {
        case .interstitial, .rewardAd, .appOpenAd:
            return true
        case .banner, .nativeAd:
            return false
        }
    }
}

// MARK: - Ad ID Configuration
struct AdIDConfig {
    let primary: String
    let secondary: String
    
    init(primary: String, secondary: String = "") {
        self.primary = primary
        self.secondary = secondary
    }
    
    var hasBackup: Bool {
        return !secondary.isEmpty
    }
    
    var description: String {
        return hasBackup ? "Primary: \(primary), Backup: \(secondary)" : "Primary: \(primary)"
    }
}

// MARK: - Simple Ad Wrapper
final class AdWrapper: @unchecked Sendable {
    let uuid = UUID()
    var adIDConfig: AdIDConfig
    let adType: AdType
    
    // Store which ad unit ID was used
    var usedAdUnitID: String = ""
    var isUsingBackup: Bool = false
    
    // Store concrete ad types
    var interstitialAd: InterstitialAd?
    var rewardedAd: RewardedAd?
    var nativeAd: NativeAd?
    var bannerView: BannerView?
    var appOpenAd: AppOpenAd?
    
    // Loading state
    var adLoader: AdLoader?
    var isLoaded: Bool = false
    var loadDate: Date = Date()
    var isImpressionRecorded: Bool = false
    var retryCount: Int = 0
    let maxRetries: Int = 1 // One retry for backup
    
    init(adIDConfig: AdIDConfig, adType: AdType) {
        self.adIDConfig = adIDConfig
        self.adType = adType
        self.usedAdUnitID = adIDConfig.primary
    }
    
    func tryBackup() -> Bool {
        guard adIDConfig.hasBackup, retryCount < maxRetries else { return false }
        
        retryCount += 1
        isUsingBackup = true
        usedAdUnitID = adIDConfig.secondary
        print("[AdWrapper] ⚠️ Switching to backup ad unit ID for \(adType.rawValue)")
        return true
    }
    
    var isExpired: Bool {
        // Ads expire after 1 hour
        Date().timeIntervalSince(loadDate) > 3600
    }
}

// MARK: - Simple Ad Manager
@MainActor
final class AdsManager: NSObject {
    static let shared = AdsManager()
    
    var isDeveloperMode: Bool = true
    
    // MARK: - Ad Unit IDs Configuration (now using AdIDConfig)
    var int_adid: AdIDConfig = AdIDConfig(primary: "")
    var rewd_adid: AdIDConfig = AdIDConfig(primary: "")
    var banner_adid: AdIDConfig = AdIDConfig(primary: "")
    var native_adid: AdIDConfig = AdIDConfig(primary: "")
    var iappopen_adid: AdIDConfig = AdIDConfig(primary: "")
    
    // MARK: - Volume Configuration (how many ads to preload per type)
    var int_volume: Int = 1
    var rewd_volume: Int = 1
    var banner_volume: Int = 1
    var native_volume: Int = 1
    var iappopen_volume: Int = 1
    
    // MARK: - Ad Pool (Thread-Safe)
    private var adPool: [AdType: [AdWrapper]] = [:]
    private let poolLock = NSLock()
    
    // MARK: - State Management
    private var isAdShowing = false
    weak var currentViewController: UIViewController?
    
    // MARK: - Current Ad State
    private var currentAdWrapper: AdWrapper?
    
    // MARK: - Ad Placements
    enum AdPlacement: String {
        case tap
    }
    
    // ------------------- CHANGED -------------------
    // Separate completions to prevent overwrite conflicts
    private var fullscreenCompletion: AdEventCompletion?
    private var inlineCompletion: AdEventCompletion?
    // -----------------------------------------------
    
    var isCollapseBannerAdShowing: Bool = false
    
    private override init() {
        super.init()
    }
    
    // Active ad object to wrapper maps for non-fullscreen ads
    private let activeMapLock = NSLock()
    private var activeBannerWrappers: [ObjectIdentifier: AdWrapper] = [:]
    private var activeNativeWrappers: [ObjectIdentifier: AdWrapper] = [:]
    
    // MARK: - Public Configuration (Updated for backup IDs)
    func configure(
        int_primary: String = "",
        int_backup: String = "",
        rewd_primary: String = "",
        rewd_backup: String = "",
        banner_primary: String = "",
        banner_backup: String = "",
        native_primary: String = "",
        native_backup: String = "",
        iappopen_primary: String = "",
        iappopen_backup: String = "",
        int_volume: Int = 1,
        rewd_volume: Int = 1,
        banner_volume: Int = 1,
        native_volume: Int = 1,
        iappopen_volume: Int = 1
    ) {
        self.int_adid = AdIDConfig(primary: int_primary, secondary: int_backup)
        self.rewd_adid = AdIDConfig(primary: rewd_primary, secondary: rewd_backup)
        self.banner_adid = AdIDConfig(primary: banner_primary, secondary: banner_backup)
        self.native_adid = AdIDConfig(primary: native_primary, secondary: native_backup)
        self.iappopen_adid = AdIDConfig(primary: iappopen_primary, secondary: iappopen_backup)
        
        self.int_volume = int_volume
        self.rewd_volume = rewd_volume
        self.banner_volume = banner_volume
        self.native_volume = native_volume
        self.iappopen_volume = iappopen_volume
        
        print("[AdsManager] Configured with backup ad IDs:")
        print("  Interstitial: \(int_adid.description)")
        print("  Rewarded: \(rewd_adid.description)")
        print("  Banner: \(banner_adid.description)")
        print("  Native: \(native_adid.description)")
        print("  App Open: \(iappopen_adid.description)")
        print("  Volumes: int(\(int_volume)), rewd(\(rewd_volume)), banner(\(banner_volume)), native(\(native_volume)), iappopen(\(iappopen_volume))")
    }
    
    // MARK: - Legacy Configuration (for backward compatibility)
    func configure(
        int_adid: String = "",
        rewd_adid: String = "",
        banner_adid: String = "",
        native_adid: String = "",
        iappopen_adid: String = "",
        int_volume: Int = 1,
        rewd_volume: Int = 1,
        banner_volume: Int = 1,
        native_volume: Int = 1,
        iappopen_volume: Int = 1
    ) {
        self.configure(
            int_primary: int_adid,
            int_backup: "",
            rewd_primary: rewd_adid,
            rewd_backup: "",
            banner_primary: banner_adid,
            banner_backup: "",
            native_primary: native_adid,
            native_backup: "",
            iappopen_primary: iappopen_adid,
            iappopen_backup: "",
            int_volume: int_volume,
            rewd_volume: rewd_volume,
            banner_volume: banner_volume,
            native_volume: native_volume,
            iappopen_volume: iappopen_volume
        )
    }
    
    // MARK: - Remote Config gating
    func isAdEnabled(_ adType: AdType) -> Bool {
        // If RC not loaded yet, be conservative and allow. Callers can decide when to preload.
        let rc = RCManager.shared
        switch adType {
        case .interstitial:
            return rc.enableInterstitialAd
        case .rewardAd:
            return rc.enableRewardAd
        case .nativeAd:
            return rc.enableNativeAd
        case .banner:
            return rc.enableBannerAd
        case .appOpenAd:
            return rc.enableOpenAd
        }
    }

    private func adDisabledError(for adType: AdType) -> NSError {
        return NSError(domain: "AdsManager",
                        code: 100,
                        userInfo: [NSLocalizedDescriptionKey: "Ad disabled by remote config: \(adType.rawValue)"])
    }

    private func shouldUseLoader(for adType: AdType) -> Bool {
        switch adType {
        case .interstitial, .rewardAd, .appOpenAd:
            return true
        case .banner, .nativeAd:
            return false
        }
    }
    
    // MARK: - Get Ad ID Config
    private func getAdIDConfig(for adType: AdType) -> AdIDConfig {
        if isDeveloperMode {
            return testAdIDConfig(for: adType)
        }
        
        switch adType {
        case .interstitial:
            return int_adid
        case .rewardAd:
            return rewd_adid
        case .banner:
            return banner_adid
        case .nativeAd:
            return native_adid
        case .appOpenAd:
            return iappopen_adid
        }
    }

    // MARK: - Preload Methods
    func preloadAd(_ adType: AdType, volume: Int? = nil, viewController: UIViewController? = nil) {
        guard !IAPurchaseHelper.shared.isSubscribed else { return }

        if RCManager.shared.onload_ad == true {
            return
        }
        
        guard isAdEnabled(adType) else {
            print("[AdsManager] ⛔️ Skip preload. Ad disabled by RC: \(adType.rawValue)")
            return
        }
        
        if let vc = viewController {
            currentViewController = vc
        }
        
        let adIDConfig = getAdIDConfig(for: adType)
        guard !adIDConfig.primary.isEmpty else {
            print("[AdsManager] ❌ Primary ad unit ID not configured for \(adType.rawValue)")
            return
        }
        
        let targetVolume = volume ?? getVolume(for: adType)
        let currentCount = getCurrentPoolCount(for: adType)
        let missingCount = max(0, targetVolume - currentCount)
        
        print("[AdsManager] 🔄 Preloading need=\(missingCount)/target=\(targetVolume) for \(adType.rawValue)")
        print("  Config: \(adIDConfig.description)")
        guard missingCount > 0 else { return }
        
        Task {
            await withTaskGroup(of: Void.self) { group in
                for i in 0..<missingCount {
                    group.addTask {
                        await self.loadAndCacheAd(adIDConfig: adIDConfig, adType: adType, index: i + 1)
                    }
                }
            }
        }
    }
    
    func preloadAllAds(viewController: UIViewController) {
        guard !IAPurchaseHelper.shared.isSubscribed else { return }
        
        if RCManager.shared.onload_ad == true {
            return
        }
        
        currentViewController = viewController
        
        Task {
            await withTaskGroup(of: Void.self) { group in
                for adType in AdType.allCases {
                    group.addTask {
                        await self.preloadAd(adType, viewController: viewController)
                    }
                }
            }
        }
    }
    
    // MARK: - Show Methods
    func showPreload(_ adType: AdType,
                     from viewController: UIViewController,
                     refill: Bool = false,
                     completion: AdEventCompletion = AdEventCompletion()) {

        guard !IAPurchaseHelper.shared.isSubscribed else {
            completion.onFail?(NSError(domain: "AdsManager", code: 1, userInfo: [NSLocalizedDescriptionKey: "isAppPurchased"]))
            return
        }
        
        // Only check isAdShowing for fullscreen ads
        if adType.isFullScreen && isAdShowing {
            print("[AdsManager] ⚠️ Ad already showing (isAdShowing=true). Blocking showPreload for \(adType.rawValue)")
            completion.onFail?(NSError(domain: "AdsManager", code: 1, userInfo: [NSLocalizedDescriptionKey: "Ad already showing"]))
            return
        }
        
        guard isAdEnabled(adType) else {
            let error = adDisabledError(for: adType)
            completion.onFail?(error)
            AdsAppLogger.logAdEvent(adType: adType, eventType: .failToShow, error: error, passVC: viewController)
            print("[AdsManager] ⛔️ showPreload blocked. Ad disabled by RC: \(adType.rawValue)")
            return
        }
        
        currentViewController = viewController
        // ------------------- CHANGED -------------------
        // Store completion in the correct bucket
        if adType.isFullScreen {
            fullscreenCompletion = completion
        } else {
            inlineCompletion = completion
        }
        // -----------------------------------------------
        
        if let cachedAd = getAvailableAd(adType: adType) {
            handleAdShow(wrapper: cachedAd, refill: refill)
        } else {
            
            // No preloaded ad available
            let error = NSError(domain: "AdsManager", code: 2, userInfo: [NSLocalizedDescriptionKey: "No preloaded ad available for \(adType.rawValue)"])
            // ------------------- CHANGED -------------------
            // Trigger failure on the correct completion
            if adType.isFullScreen {
                fullscreenCompletion?.onFail?(error)
            } else {
                inlineCompletion?.onFail?(error)
            }
            // -----------------------------------------------
            print("[AdsManager] ❌ No preloaded ad available for \(adType.rawValue)")
            return
        }
    }
    
    func showOnload(_ adType: AdType,
                    from viewController: UIViewController,
                    refill: Bool = false,
                    completion: AdEventCompletion = AdEventCompletion()) {
        
        guard !IAPurchaseHelper.shared.isSubscribed else {
            completion.onFail?(NSError(domain: "AdsManager", code: 1, userInfo: [NSLocalizedDescriptionKey: "isAppPurchased"]))
            return
        }
        
        // Only check isAdShowing for fullscreen ads
        if adType.isFullScreen && isAdShowing {
            print("[AdsManager] ⚠️ Ad already showing (isAdShowing=true). Blocking showOnload for \(adType.rawValue)")
            completion.onFail?(NSError(domain: "AdsManager", code: 1, userInfo: [NSLocalizedDescriptionKey: "Ad already showing"]))
            return
        }
        
        guard isAdEnabled(adType) else {
            let error = adDisabledError(for: adType)
            completion.onFail?(error)
            AdsAppLogger.logAdEvent(adType: adType, eventType: .failToShow, error: error, passVC: viewController)
            print("[AdsManager] ⛔️ showOnload blocked. Ad disabled by RC: \(adType.rawValue)")
            hideLoadingIndicator()
            return
        }
        
        currentViewController = viewController
        // ------------------- CHANGED -------------------
        if adType.isFullScreen {
            fullscreenCompletion = completion
        } else {
            inlineCompletion = completion
        }
        // -----------------------------------------------
        
        // If a preloaded ad is already available for this type, present it immediately
        if let cachedAd = getAvailableAd(adType: adType) {
            print("[AdsManager] ⚡️ Using preloaded ad for onload: \(adType.rawValue)")
            handleAdShow(wrapper: cachedAd, refill: refill)
            return
        }
        
        let adIDConfig = getAdIDConfig(for: adType)
        guard !adIDConfig.primary.isEmpty else {
            let error = NSError(domain: "AdsManager", code: 3, userInfo: [NSLocalizedDescriptionKey: "Ad unit ID not configured for \(adType.rawValue)"])
            // ------------------- CHANGED -------------------
            // Trigger failure on the correct completion
            if adType.isFullScreen {
                fullscreenCompletion?.onFail?(error)
            } else {
                inlineCompletion?.onFail?(error)
            }
            // -----------------------------------------------
            hideLoadingIndicator()
            return
        }
        
        // Load ad on demand
        if shouldUseLoader(for: adType) { showLoadingIndicator() }
        Task {
            await loadAndShowAd(adIDConfig: adIDConfig, adType: adType, refill: refill)
        }
    }
    
    /// Shows an onload interstitial ad for a specific placement. When the ad is dismissed (or if showing fails/is bypassed), the `completion` is executed.
    func showInterstitial(for placement: AdPlacement, from viewController: UIViewController? = nil, completion: @escaping () -> Void) {
        // If the user has purchased/subscribed, bypass ads and execute completion immediately
        guard !IAPurchaseHelper.shared.isSubscribed else {
            completion()
            return
        }
        
        // If this specific placement is disabled in remote config, bypass
        guard RCManager.shared.isPlacementEnabled(placement.rawValue) else {
            completion()
            return
        }
        
        let targetVC = viewController ?? AdsManager.gettopViewController()
        
        let adCompletion = AdEventCompletion(
            onFail: { _ in
                completion()
            },
            onClose: {
                completion()
            }
        )
        
        showOnload(.interstitial, from: targetVC, completion: adCompletion)
    }
    
    /// Shows a rewarded or interstitial ad specifically for the play button based on remote config.
    func showAdForPlayButton(for placement: AdPlacement, from viewController: UIViewController? = nil, completion: @escaping () -> Void) {
        // If the user has purchased/subscribed, bypass ads and execute completion immediately
        guard !IAPurchaseHelper.shared.isSubscribed else {
            completion()
            return
        }
        
        // If this specific placement is disabled in remote config, bypass
        guard RCManager.shared.isPlacementEnabled(placement.rawValue) else {
            completion()
            return
        }
        
        let targetVC = viewController ?? AdsManager.gettopViewController()
        
        let adCompletion = AdEventCompletion(
            onFail: { _ in
                completion()
            },
            onClose: {
                completion()
            }
        )
        
        // Use show_int_or_rwd string from RC to determine ad type
        // if "reward" or "rwd", show rewardAd, else show interstitial
        let configString = RCManager.shared.show_int_or_rwd.lowercased()
        let adType: AdType = (configString.contains("reward") || configString.contains("rwd")) ? .rewardAd : .interstitial
        
        showOnload(adType, from: targetVC, completion: adCompletion)
    }
    
    // MARK: - Private Methods
    private func getVolume(for adType: AdType) -> Int {
        switch adType {
        case .interstitial:
            return int_volume
        case .rewardAd:
            return rewd_volume
        case .banner:
            return banner_volume
        case .nativeAd:
            return native_volume
        case .appOpenAd:
            return iappopen_volume
        }
    }
    
    private func getCurrentPoolCount(for adType: AdType) -> Int {
        return poolLock.sync {
            return adPool[adType]?.filter { !$0.isExpired && isAdReady($0) }.count ?? 0
        }
    }
    
    // MARK: - Load with Backup Support
    private func loadAndCacheAd(adIDConfig: AdIDConfig, adType: AdType, index: Int = 1) async {
        guard isAdEnabled(adType) else {
            print("[AdsManager] ⛔️ loadAndCacheAd blocked. Ad disabled by RC: \(adType.rawValue)")
            return
        }
        print("[AdsManager] Starting parallel load for \(adType.rawValue) #\(index)")
        
        let wrapper = AdWrapper(adIDConfig: adIDConfig, adType: adType)
        
        do {
            switch adType {
            case .interstitial:
                try await loadInterstitialWithBackup(wrapper: wrapper)
            case .rewardAd:
                try await loadRewardedWithBackup(wrapper: wrapper)
            case .appOpenAd:
                try await loadAppOpenWithBackup(wrapper: wrapper)
            case .banner:
                await loadBannerWithBackup(wrapper: wrapper)
                return
            case .nativeAd:
                await MainActor.run {
                    loadNativeWithBackup(wrapper: wrapper)
                    cacheAdInPool(wrapper)
                }
                return
            }
            
            wrapper.isLoaded = true
            wrapper.loadDate = Date()
            cacheAdInPool(wrapper)
            setupPaidEventHandler(for: wrapper)
            
            // Only trigger onLoaded if it's not handled by a delegate (usually for fullscreen ads)
            let completion = adType.isFullScreen ? fullscreenCompletion : inlineCompletion
            completion?.onLoaded?() // <-- FIXED
            print("[AdsManager] ✅ Loaded \(adType.rawValue) #\(index) using \(wrapper.isUsingBackup ? "BACKUP" : "PRIMARY")")
            AdsAppLogger.logAdEvent(adType: adType, eventType: .loaded, error: nil, passVC: currentViewController)
            
        } catch {
            print("[AdsManager] ❌ Failed to load \(adType.rawValue) #\(index) after trying both IDs: \(error.localizedDescription)")
            AdsAppLogger.logAdEvent(adType: adType, eventType: .failToLoad, error: error, passVC: currentViewController)
            return
        }
    }
    
    private func loadAndShowAd(adIDConfig: AdIDConfig, adType: AdType, refill: Bool) async {
        // ------------------- CHANGED -------------------
        // Capture the correct completion for this specific load request
        let savedCompletion = adType.isFullScreen ? fullscreenCompletion : inlineCompletion
        
        guard isAdEnabled(adType) else {
            let error = adDisabledError(for: adType)
            savedCompletion?.onFail?(error)
            AdsAppLogger.logAdEvent(adType: adType, eventType: .failToShow, error: error, passVC: currentViewController)
            print("[AdsManager] ⛔️ loadAndShowAd blocked. Ad disabled by RC: \(adType.rawValue)")
            if shouldUseLoader(for: adType) { hideLoadingIndicator() }
            return
        }
        
        print("[AdsManager] Starting on-demand load for \(adType.rawValue)")
        
        let wrapper = AdWrapper(adIDConfig: adIDConfig, adType: adType)

        // -----------------------------------------------
        print("[AdsManager] Started loading on-demand \(adType.rawValue)")
        
        savedCompletion?.onRequest?()
        
        AdsAppLogger.logAdEvent(adType: adType, eventType: .request, error: nil, passVC: currentViewController)
        
        do {
            switch adType {
            case .interstitial:
                try await loadInterstitialWithBackup(wrapper: wrapper)
            case .rewardAd:
                try await loadRewardedWithBackup(wrapper: wrapper)
            case .appOpenAd:
                try await loadAppOpenWithBackup(wrapper: wrapper)
            case .banner:
                await loadBannerWithBackup(wrapper: wrapper)
                // For banner, store wrapper with saved completion
                await MainActor.run {
                    // Store wrapper temporarily for onload handling
                    if !self.isAdShowing {
                        self.currentAdWrapper = wrapper
                    } else {
                        // Store in a separate tracking structure for non-fullscreen ads
                        self.activeMapLock.sync {
                            if let bannerView = wrapper.bannerView {
                                self.activeBannerWrappers[ObjectIdentifier(bannerView)] = wrapper
                            }
                        }
                    }
                }
                return
            case .nativeAd:
                await MainActor.run {
                    loadNativeWithBackup(wrapper: wrapper)
                    // For native ad, always track it even if fullscreen ad is showing
                    if !self.isAdShowing {
                        self.currentAdWrapper = wrapper
                    } else {
                        print("[AdsManager] ⚠️ Fullscreen ad is showing, will track native ad separately")
                        // We'll add this wrapper to the pool so findWrapper can locate it
                        self.cacheAdInPool(wrapper)
                    }
                }
                return
            }
            
            wrapper.isLoaded = true
            wrapper.loadDate = Date()
            setupPaidEventHandler(for: wrapper)
            
            savedCompletion?.onLoaded?()
            print("[AdsManager] ✅ Loaded on-demand \(adType.rawValue) using \(wrapper.isUsingBackup ? "BACKUP" : "PRIMARY")")
            AdsAppLogger.logAdEvent(adType: adType, eventType: .loaded, error: nil, passVC: currentViewController)
            
            // Show immediately for onload
            await handleOnloadAdShow(wrapper: wrapper, refill: refill, completion: savedCompletion)
            
        } catch {
            savedCompletion?.onFail?(error)
            print("[AdsManager] ❌ Failed to load on-demand \(adType.rawValue) after trying both IDs: \(error.localizedDescription)")
            AdsAppLogger.logAdEvent(adType: adType, eventType: .failToLoad, error: error, passVC: currentViewController)
            if shouldUseLoader(for: adType) { hideLoadingIndicator() }
        }
    }
    
    // MARK: - Ad Loading with Backup Logic
    private func loadInterstitialWithBackup(wrapper: AdWrapper) async throws {
        repeat {
            do {
                print("[AdsManager] Attempting to load interstitial with ID: \(wrapper.usedAdUnitID)")
                let ad = try await InterstitialAd.load(with: wrapper.usedAdUnitID, request: Request())
                wrapper.interstitialAd = ad
                ad.fullScreenContentDelegate = self
                return // Success
            } catch {
                print("[AdsManager] ❌ Interstitial load failed with ID: \(wrapper.usedAdUnitID), error: \(error.localizedDescription)")
                if !wrapper.tryBackup() {
                    throw error // No backup available or max retries reached
                }
            }
        } while wrapper.retryCount <= wrapper.maxRetries
    }
    
    private func loadRewardedWithBackup(wrapper: AdWrapper) async throws {
        repeat {
            do {
                print("[AdsManager] Attempting to load rewarded with ID: \(wrapper.usedAdUnitID)")
                let ad = try await RewardedAd.load(with: wrapper.usedAdUnitID, request: Request())
                wrapper.rewardedAd = ad
                ad.fullScreenContentDelegate = self
                return // Success
            } catch {
                print("[AdsManager] ❌ Rewarded load failed with ID: \(wrapper.usedAdUnitID), error: \(error.localizedDescription)")
                if !wrapper.tryBackup() {
                    throw error
                }
            }
        } while wrapper.retryCount <= wrapper.maxRetries
    }
    
    private func loadAppOpenWithBackup(wrapper: AdWrapper) async throws {
        repeat {
            do {
                print("[AdsManager] Attempting to load app open with ID: \(wrapper.usedAdUnitID)")
                let ad = try await AppOpenAd.load(with: wrapper.usedAdUnitID, request: Request())
                wrapper.appOpenAd = ad
                ad.fullScreenContentDelegate = self
                return // Success
            } catch {
                print("[AdsManager] ❌ App open load failed with ID: \(wrapper.usedAdUnitID), error: \(error.localizedDescription)")
                if !wrapper.tryBackup() {
                    throw error
                }
            }
        } while wrapper.retryCount <= wrapper.maxRetries
    }
    
    private func loadBannerWithBackup(wrapper: AdWrapper) async {
        await MainActor.run {
            // 1. Get the top view controller to safely access the view context
            let vc = currentViewController ?? AdsManager.gettopViewController()
            
            // 2. Safely get the width avoiding UIScreen.main.
            // Using the view's bounds width is the standard practice for adaptive banners.
            let viewWidth = vc.view.bounds.width
            
            // 3. Use the newly recommended GAD method for the ad size
            let adSize = largeAnchoredAdaptiveBanner(width: viewWidth)
            
            let banner = BannerView(adSize: adSize)
            banner.adUnitID = wrapper.usedAdUnitID
            banner.rootViewController = vc
            banner.delegate = self
            
            let request = Request()
            if isCollapseBannerAdShowing {
                let extras = Extras()
                extras.additionalParameters = ["collapsible": "bottom"]
                request.register(extras)
            }
            
            banner.load(request)
            wrapper.bannerView = banner
        }
    }
    
    private func loadNativeWithBackup(wrapper: AdWrapper) {
        let loader = AdLoader(
            adUnitID: wrapper.usedAdUnitID,
            rootViewController: currentViewController,
            adTypes: [.native],
            options: [MultipleAdsAdLoaderOptions()]
        )
        loader.delegate = self
        wrapper.adLoader = loader
        loader.load(Request())
    }
    
    private func handleOnloadAdShow(wrapper: AdWrapper, refill: Bool, completion: AdEventCompletion? = nil) async {
        await MainActor.run {
            // Use the saved completion or fall back to currentCompletion
            // ------------------- CHANGED -------------------
            // Prefer passed completion, otherwise fallback to stored specific completion
            let fallback = wrapper.adType.isFullScreen ? self.fullscreenCompletion : self.inlineCompletion
            let activeCompletion = completion ?? fallback
            // -----------------------------------------------
            
            // Only update currentAdWrapper for fullscreen ads
            if wrapper.adType.isFullScreen {
                self.currentAdWrapper = wrapper
            }
            
            if wrapper.adType == .banner || wrapper.adType == .nativeAd {
                // For banner and native, handle in delegates
                // keep loader visible until their delegate confirms load or failure
                return
            }
            
            // Only set isAdShowing for fullscreen ads BEFORE presenting
            if wrapper.adType.isFullScreen {
                self.isAdShowing = true
                print("[AdsManager] 🔒 Set isAdShowing=true for \(wrapper.adType.rawValue)")
            }
            
            let vc = currentViewController ?? AdsManager.gettopViewController()
            
            // Add safety wrapper to reset flag on any failure
            let safePresent: () -> Void = {
                if let interstitialAd = wrapper.interstitialAd {
                    interstitialAd.present(from: vc)
                    activeCompletion?.onShow?()
                    print("[AdsManager] Presenting on-demand \(wrapper.adType.rawValue)")
                    AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .show, error: nil, passVC: self.currentViewController)
                    if self.shouldUseLoader(for: wrapper.adType) { hideLoadingIndicator() }
                } else if let rewardedAd = wrapper.rewardedAd {
                    rewardedAd.present(from: vc) { }
                    activeCompletion?.onShow?()
                    print("[AdsManager] Presenting on-demand \(wrapper.adType.rawValue)")
                    AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .show, error: nil, passVC: vc)
                    if self.shouldUseLoader(for: wrapper.adType) { hideLoadingIndicator() }
                } else if let appOpenAd = wrapper.appOpenAd {
                    delay(time: 1.0) {
                        appOpenAd.present(from: vc)
                        activeCompletion?.onShow?()
                        print("[AdsManager] Presenting on-demand \(wrapper.adType.rawValue)")
                        AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .show, error: nil, passVC: vc)
                        if self.shouldUseLoader(for: wrapper.adType) { hideLoadingIndicator() }
                    }
                } else {
                    // Ad object is nil - reset flag immediately
                    if wrapper.adType.isFullScreen {
                        self.isAdShowing = false
                        print("[AdsManager] 🔓 Reset isAdShowing=false (ad is nil)")
                    }
                    let error = NSError(domain: "AdsManager", code: 5, userInfo: [NSLocalizedDescriptionKey: "Ad is nil"])
                    activeCompletion?.onFail?(error)
                    AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .failToShow, error: error, passVC: vc)
                    if self.shouldUseLoader(for: wrapper.adType) { hideLoadingIndicator() }
                    return
                }
            }
            
            safePresent()
            
            // Refill if needed
            if refill {
                Task {
                    await self.loadAndCacheAd(adIDConfig: wrapper.adIDConfig, adType: wrapper.adType, index: 1)
                }
            }
        }
    }
    
    private func cacheAdInPool(_ wrapper: AdWrapper) {
        poolLock.sync {
            var ads = adPool[wrapper.adType] ?? []
            ads.append(wrapper)
            adPool[wrapper.adType] = ads
        }
    }
    
    private func removeAdFromPool(_ wrapper: AdWrapper) {
        poolLock.sync {
            adPool[wrapper.adType]?.removeAll { $0.uuid == wrapper.uuid }
        }
    }
    
    private func getAvailableAd(adType: AdType) -> AdWrapper? {
        if RCManager.shared.onload_ad == true {
            return nil
        }
        return poolLock.sync {
            return adPool[adType]?.first { wrapper in
                !wrapper.isExpired && isAdReady(wrapper)
            }
        }
    }
    
    private func isAdReady(_ wrapper: AdWrapper) -> Bool {
        switch wrapper.adType {
        case .interstitial:
            return wrapper.interstitialAd != nil
        case .rewardAd:
            return wrapper.rewardedAd != nil
        case .appOpenAd:
            return wrapper.appOpenAd != nil
        case .banner:
            return wrapper.bannerView != nil && wrapper.isLoaded
        case .nativeAd:
            return wrapper.nativeAd != nil && wrapper.isLoaded
        }
    }
    
    private func handleAdShow(wrapper: AdWrapper, refill: Bool) {
        removeAdFromPool(wrapper)
        
        // 1. Determine the correct completion handler
        let completion = wrapper.adType.isFullScreen ? fullscreenCompletion : inlineCompletion
        
        // Handle banner and native ads - no isAdShowing flag needed
        if wrapper.adType == .banner, let bannerView = wrapper.bannerView {
            activeMapLock.sync {
                activeBannerWrappers[ObjectIdentifier(bannerView)] = wrapper
            }
            completion?.onBannerLoaded?(bannerView)
            completion?.onShow?()
            print("[AdsManager] Showing preloaded banner")
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .show, error: nil, passVC: currentViewController)
            
            if refill {
                Task {
                    await loadAndCacheAd(adIDConfig: wrapper.adIDConfig, adType: wrapper.adType, index: 1)
                }
            }
            return
        }
        
        if wrapper.adType == .nativeAd, let nativeAd = wrapper.nativeAd {
            activeMapLock.sync {
                activeNativeWrappers[ObjectIdentifier(nativeAd)] = wrapper
            }
            DispatchQueue.main.async {
                completion?.onNativeAdLoaded?(nativeAd)
                completion?.onShow?()
            }
            print("[AdsManager] Showing preloaded native ad")
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .show, error: nil, passVC: currentViewController)
            
            if refill {
                Task {
                    await loadAndCacheAd(adIDConfig: wrapper.adIDConfig, adType: wrapper.adType, index: 1)
                }
            }
            return
        }
        
        // Handle fullscreen ads - manage isAdShowing flag
        currentAdWrapper = wrapper
        if wrapper.adType.isFullScreen {
            isAdShowing = true
            print("[AdsManager] 🔒 Set isAdShowing=true for \(wrapper.adType.rawValue)")
        }
        
        let vc = currentViewController ?? AdsManager.gettopViewController()

        if let interstitialAd = wrapper.interstitialAd {
            interstitialAd.present(from: vc)
            completion?.onShow?()
            print("[AdsManager] Presenting preloaded \(wrapper.adType.rawValue)")
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .show, error: nil, passVC: vc)
        } else if let rewardedAd = wrapper.rewardedAd {
            rewardedAd.present(from: vc) { }
            completion?.onShow?()
            print("[AdsManager] Presenting preloaded \(wrapper.adType.rawValue)")
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .show, error: nil, passVC: vc)
        } else if let appOpenAd = wrapper.appOpenAd {
            delay(time: 1.0) {
                appOpenAd.present(from: vc)
                completion?.onShow?()
                print("[AdsManager] Presenting preloaded \(wrapper.adType.rawValue)")
                AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .show, error: nil, passVC: vc)
            }
        } else {
            // Only reset isAdShowing for fullscreen ads on failure
            if wrapper.adType.isFullScreen {
                isAdShowing = false
                print("[AdsManager] 🔓 Reset isAdShowing=false (ad is nil in handleAdShow)")
            }
            let error = NSError(domain: "AdsManager", code: 5, userInfo: [NSLocalizedDescriptionKey: "Ad is nil"])
            completion?.onFail?(error) // <-- FIXED
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .failToShow, error: error, passVC: vc)
            return
        }
        
        // Refill if needed
        if refill {
            Task {
                await loadAndCacheAd(adIDConfig: wrapper.adIDConfig, adType: wrapper.adType, index: 1)
            }
        }
    }
    
    private func recordImpression(for wrapper: AdWrapper) {
        guard !wrapper.isImpressionRecorded else { return }
            
        wrapper.isImpressionRecorded = true
        
        // Determine the correct completion handler
        let completion = wrapper.adType.isFullScreen ? fullscreenCompletion : inlineCompletion
        
        completion?.onImpression?() // <-- Use the determined completion
        print("[AdsManager] Impression recorded for \(wrapper.adType.rawValue)")
    }
    
    private func setupPaidEventHandler(for wrapper: AdWrapper) {
        let handler: (AdValue) -> Void = { adValue in
            let parameters: [String: Any] = [
                "ValueMicros": adValue.value,
                "CurrencyCode": adValue.currencyCode,
                "Precision": adValue.precision.rawValue,
                "AdUnitId": wrapper.usedAdUnitID,
                "IsBackup": wrapper.isUsingBackup
            ]
            AdsAppLogger.logPaidEvent(eventName: "paid_ad_impression", parameters: parameters)
            print("[AdsManager] Paid event for \(wrapper.adType.rawValue) using \(wrapper.isUsingBackup ? "BACKUP" : "PRIMARY"): \(parameters)")
        }
        
        if let ad = wrapper.interstitialAd {
            ad.paidEventHandler = handler
        } else if let ad = wrapper.rewardedAd {
            ad.paidEventHandler = handler
        } else if let ad = wrapper.appOpenAd {
            ad.paidEventHandler = handler
        } else if let ad = wrapper.bannerView {
            ad.paidEventHandler = handler
        } else if let ad = wrapper.nativeAd {
            ad.paidEventHandler = handler
        }
    }
    
    private func testAdIDConfig(for adType: AdType) -> AdIDConfig {
        // For testing, we can optionally add backup test IDs
        switch adType {
        case .interstitial:
            return AdIDConfig(
                primary: "ca-app-pub-3940256099942544/1033173712",
                secondary: "ca-app-pub-3940256099942544/1033173712" // Same for testing
            )
        case .rewardAd:
            return AdIDConfig(
                primary: "ca-app-pub-3940256099942544/5224354917",
                secondary: "ca-app-pub-3940256099942544/5224354917"
            )
        case .nativeAd:
            return AdIDConfig(
                primary: "ca-app-pub-3940256099942544/2247696110",
                secondary: "ca-app-pub-3940256099942544/2247696110"
            )
        case .banner:
            return AdIDConfig(
                primary: "ca-app-pub-3940256099942544/9214589741",
                secondary: "ca-app-pub-3940256099942544/9214589741"
            )
        case .appOpenAd:
            return AdIDConfig(
                primary: "ca-app-pub-3940256099942544/9257395921",
                secondary: "ca-app-pub-3940256099942544/9257395921"
            )
        }
    }
}

// MARK: - FullScreenContentDelegate
extension AdsManager: FullScreenContentDelegate {
    
    func adDidRecordImpression(_ ad: any FullScreenPresentingAd) {
        guard let wrapper = currentAdWrapper else { return }
        recordImpression(for: wrapper)
        AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .impression, error: nil, passVC: currentViewController)
    }
    
    func adDidRecordClick(_ ad: any FullScreenPresentingAd) {
        guard let wrapper = currentAdWrapper else { return }
        fullscreenCompletion?.onClick?()
        print("[AdsManager] Ad clicked: \(wrapper.adType.rawValue)")
        AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .click, error: nil, passVC: currentViewController)
    }
    
    func adDidDismissFullScreenContent(_ ad: FullScreenPresentingAd) {
        guard let wrapper = currentAdWrapper else {
            // Safety: If wrapper is nil but flag is set, reset it
            if isAdShowing {
                isAdShowing = false
                print("[AdsManager] 🔓 Reset isAdShowing=false (wrapper was nil in dismiss)")
            }
            return
        }
        
        fullscreenCompletion?.onClose?()
        print("[AdsManager] Ad dismissed: \(wrapper.adType.rawValue)")
        AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .dismiss, error: nil, passVC: currentViewController)
        AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .close, error: nil, passVC: currentViewController)
        
        // Only reset isAdShowing for fullscreen ads
        if wrapper.adType.isFullScreen {
            isAdShowing = false
            print("[AdsManager] 🔓 Reset isAdShowing=false (ad dismissed)")
        }
        currentAdWrapper = nil
        fullscreenCompletion = nil
    }
    
    func adWillPresentFullScreenContent(_ ad: any FullScreenPresentingAd) {
        fullscreenCompletion?.onShow?()
        print("[AdsManager] Ad will present")
        if let wrapper = currentAdWrapper {
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .open, error: nil, passVC: currentViewController)
        }
    }
    
    func ad(_ ad: FullScreenPresentingAd, didFailToPresentFullScreenContentWithError error: Error) {
        guard let wrapper = currentAdWrapper else {
            // Safety: If wrapper is nil but flag is set, reset it
            if isAdShowing {
                isAdShowing = false
                print("[AdsManager] 🔓 Reset isAdShowing=false (wrapper was nil in fail)")
            }
            return
        }
        
        fullscreenCompletion?.onFail?(error)
        print("[AdsManager] Ad failed to present: \(wrapper.adType.rawValue) - Error: \(error.localizedDescription)")
        AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .failToShow, error: error, passVC: currentViewController)
        
        // Only reset isAdShowing for fullscreen ads
        if wrapper.adType.isFullScreen {
            isAdShowing = false
            print("[AdsManager] 🔓 Reset isAdShowing=false (ad failed to present)")
        }
        currentAdWrapper = nil
        fullscreenCompletion = nil
    }
}

// MARK: - BannerViewDelegate
extension AdsManager: BannerViewDelegate {
    func bannerViewDidReceiveAd(_ bannerView: BannerView) {
        if let wrapper = findWrapper(for: bannerView) {
            wrapper.isLoaded = true
            wrapper.loadDate = Date()
            setupPaidEventHandler(for: wrapper)
            
            // ------------------- FIXED LOGIC -------------------
            if let completion = inlineCompletion {
                completion.onLoaded?()
                completion.onBannerLoaded?(bannerView) // <-- GUARANTEED DISPLAY CALL
                completion.onShow?()
                
                AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .loaded, error: nil, passVC: currentViewController)
                AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .show, error: nil, passVC: currentViewController)
                print("[AdsManager] Onload Banner ad loaded and called completion handlers.")
                
                // Move to active wrappers
                activeMapLock.sync {
                    activeBannerWrappers[ObjectIdentifier(bannerView)] = wrapper
                }
            } else {
                // Background preload: No active consumer is waiting for the completion
                AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .loaded, error: nil, passVC: currentViewController)
                print("[AdsManager] Banner preloaded successfully (background cache)")
            }
            // ------------------- END FIXED LOGIC -------------------
            
            // Clear currentAdWrapper if it was temporarily holding this ad for onload tracking
            let isOnloadAd = currentAdWrapper?.uuid == wrapper.uuid
            if isOnloadAd {
                currentAdWrapper = nil
            }
        }
    }
    
    func bannerView(_ bannerView: BannerView, didFailToReceiveAdWithError error: Error) {
        if let wrapper = findWrapper(for: bannerView) {
            // Try backup if available
            if wrapper.tryBackup() {
                print("[AdsManager] ⚠️ Banner primary failed, trying backup ID: \(wrapper.usedAdUnitID)")
                bannerView.adUnitID = wrapper.usedAdUnitID
                bannerView.load(Request())
                return
            }
            
            // Both primary and backup failed
            removeAdFromPool(wrapper)
            
            // Check if this was an onload banner
            let isOnloadAd = currentAdWrapper?.uuid == wrapper.uuid
            
            if isOnloadAd {
                inlineCompletion?.onFail?(error)
                print("[AdsManager] ❌ Onload banner failed to load")
                
                // Clear currentAdWrapper only if no fullscreen ad is showing
                if !isAdShowing {
                    currentAdWrapper = nil
                }
            }
            
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .failToLoad, error: error, passVC: currentViewController)
            print("[AdsManager] Banner failed to load after trying both IDs: \(error.localizedDescription)")
        }
    }
    
    func bannerViewDidRecordImpression(_ bannerView: BannerView) {
        if let wrapper = findWrapper(for: bannerView) {
            recordImpression(for: wrapper)
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .impression, error: nil, passVC: currentViewController)
        }
    }
    
    func bannerViewDidRecordClick(_ bannerView: BannerView) {
        if let wrapper = findWrapper(for: bannerView) {
            inlineCompletion?.onClick?()
            print("[AdsManager] Banner clicked")
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .click, error: nil, passVC: currentViewController)
        }
    }
    
    func bannerViewWillPresentScreen(_ bannerView: BannerView) {
        if let wrapper = findWrapper(for: bannerView) {
            inlineCompletion?.onShow?()
            print("[AdsManager] Banner will present screen")
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .open, error: nil, passVC: currentViewController)
        }
    }
    
    func bannerViewDidDismissScreen(_ bannerView: BannerView) {
        if let wrapper = findWrapper(for: bannerView) {
            inlineCompletion?.onClose?()
            print("[AdsManager] Banner did dismiss screen")
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .dismiss, error: nil, passVC: currentViewController)
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .close, error: nil, passVC: currentViewController)
        }
        
        _ = activeMapLock.sync {
            activeBannerWrappers.removeValue(forKey: ObjectIdentifier(bannerView))
        }
    }
    
    private func findWrapper(for bannerView: BannerView) -> AdWrapper? {
        // Check active banners first
        if let mapped = activeMapLock.sync(execute: { activeBannerWrappers[ObjectIdentifier(bannerView)] }) {
            return mapped
        }
        
        // Check currentAdWrapper for onload banners
        if let currentWrapper = currentAdWrapper, currentWrapper.bannerView === bannerView {
            return currentWrapper
        }
        
        // Check pool
        return poolLock.sync {
            for wrappers in adPool.values {
                if let wrapper = wrappers.first(where: { $0.bannerView === bannerView }) {
                    return wrapper
                }
            }
            return nil
        }
    }
}

// MARK: - NativeAdLoaderDelegate
extension AdsManager: NativeAdLoaderDelegate, NativeAdDelegate {
    func adLoader(_ adLoader: AdLoader, didReceive nativeAd: NativeAd) {
        if let wrapper = findWrapper(for: adLoader) {
            wrapper.nativeAd = nativeAd
            wrapper.isLoaded = true
            wrapper.loadDate = Date()
            wrapper.adLoader = nil
            nativeAd.delegate = self
            setupPaidEventHandler(for: wrapper)
            
            // ------------------- FIXED LOGIC -------------------
            if let completion = inlineCompletion {
                completion.onLoaded?()
                completion.onNativeAdLoaded?(nativeAd) // <-- GUARANTEED DISPLAY CALL
                completion.onShow?()
                
                AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .loaded, error: nil, passVC: currentViewController)
                AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .show, error: nil, passVC: currentViewController)
                print("[AdsManager] Onload Native ad loaded and called completion handlers.")
                
                // Move to active wrappers
                activeMapLock.sync {
                    activeNativeWrappers[ObjectIdentifier(nativeAd)] = wrapper
                }
            } else {
                // Background preload: No active consumer is waiting for the completion
                AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .loaded, error: nil, passVC: currentViewController)
                print("[AdsManager] Native ad preloaded successfully (background cache)")
            }
            // ------------------- END FIXED LOGIC -------------------
            
            // Clear currentAdWrapper if it was temporarily holding this ad for onload tracking
            let isOnloadAd = currentAdWrapper?.uuid == wrapper.uuid
            if isOnloadAd {
                currentAdWrapper = nil
            }
        }
    }
    
    func adLoader(_ adLoader: AdLoader, didFailToReceiveAdWithError error: Error) {
        if let wrapper = findWrapper(for: adLoader) {
            // Try backup if available
            if wrapper.tryBackup() {
                print("[AdsManager] ⚠️ Native ad primary failed, trying backup ID: \(wrapper.usedAdUnitID)")
                let newLoader = AdLoader(
                    adUnitID: wrapper.usedAdUnitID,
                    rootViewController: currentViewController,
                    adTypes: [.native],
                    options: [MultipleAdsAdLoaderOptions()]
                )
                newLoader.delegate = self
                wrapper.adLoader = newLoader
                newLoader.load(Request())
                return
            }
            
            // Both primary and backup failed
            removeAdFromPool(wrapper)
            
            // Check if this was an onload native ad
            let isOnloadAd = currentAdWrapper?.uuid == wrapper.uuid
            
            if isOnloadAd {
                inlineCompletion?.onFail?(error)
                print("[AdsManager] ❌ Onload native ad failed to load")
                
                // Clear currentAdWrapper only if no fullscreen ad is showing
                if !isAdShowing {
                    currentAdWrapper = nil
                }
            }
            
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .failToLoad, error: error, passVC: currentViewController)
            print("[AdsManager] Native ad failed to load after trying both IDs: \(error.localizedDescription)")
        }
    }

    
    private func findWrapper(for adLoader: AdLoader) -> AdWrapper? {
        // Check currentAdWrapper for onload native ads first
        if let currentWrapper = currentAdWrapper, currentWrapper.adLoader === adLoader {
            return currentWrapper
        }
        
        // Check pool
        return poolLock.sync {
            for wrappers in adPool.values {
                if let wrapper = wrappers.first(where: { $0.adLoader === adLoader }) {
                    return wrapper
                }
            }
            return nil
        }
    }
    
    // MARK: - NativeAdDelegate Methods
    func nativeAdDidRecordClick(_ nativeAd: NativeAd) {
        if let wrapper = findWrapper(for: nativeAd) {
            inlineCompletion?.onClick?()
            print("[AdsManager] Native ad clicked")
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .click, error: nil, passVC: currentViewController)
        }
    }
    
    func nativeAdDidRecordImpression(_ nativeAd: NativeAd) {
        if let wrapper = findWrapper(for: nativeAd) {
            recordImpression(for: wrapper)
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .impression, error: nil, passVC: currentViewController)
        }
    }
    
    func nativeAdWillPresentScreen(_ nativeAd: NativeAd) {
        if let wrapper = findWrapper(for: nativeAd) {
            inlineCompletion?.onShow?()
            print("[AdsManager] Native ad will present screen")
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .open, error: nil, passVC: currentViewController)
        }
    }
    
    func nativeAdDidDismissScreen(_ nativeAd: NativeAd) {
        if let wrapper = findWrapper(for: nativeAd) {
            inlineCompletion?.onClose?()
            print("[AdsManager] Native ad did dismiss screen")
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .dismiss, error: nil, passVC: currentViewController)
            AdsAppLogger.logAdEvent(adType: wrapper.adType, eventType: .close, error: nil, passVC: currentViewController)
        }
        
        _ = activeMapLock.sync {
            activeNativeWrappers.removeValue(forKey: ObjectIdentifier(nativeAd))
        }
    }
    
    private func findWrapper(for nativeAd: NativeAd) -> AdWrapper? {
        if let mapped = activeMapLock.sync(execute: { activeNativeWrappers[ObjectIdentifier(nativeAd)] }) {
            return mapped
        }
        return poolLock.sync {
            for wrappers in adPool.values {
                if let wrapper = wrappers.first(where: { $0.nativeAd === nativeAd }) {
                    return wrapper
                }
            }
            return nil
        }
    }
}

// MARK: - Public Helper Methods
extension AdsManager {
    
    /// Get current pool status for debugging
    func getPoolStatus() -> [String: Int] {
        return poolLock.sync {
            var status: [String: Int] = [:]
            for (adType, wrappers) in adPool {
                status[adType.rawValue] = wrappers.filter { !$0.isExpired && isAdReady($0) }.count
            }
            return status
        }
    }
    
    /// Clear all expired ads from pools
    func clearExpiredAds() {
        poolLock.sync {
            for adType in adPool.keys {
                adPool[adType]?.removeAll { $0.isExpired }
            }
        }
    }

    func clearAllInlineAdsForPurchase() {
        poolLock.sync {
            adPool[.banner]?.removeAll()
            adPool[.nativeAd]?.removeAll()
        }
        activeMapLock.sync {
            activeBannerWrappers.removeAll()
            activeNativeWrappers.removeAll()
        }
        if currentAdWrapper?.adType == .banner || currentAdWrapper?.adType == .nativeAd {
            currentAdWrapper = nil
        }
        inlineCompletion = nil
        print("[AdsManager] Cleared inline ad cache after purchase")
    }
    
    /// Check if ads are available for a specific type
    func hasAvailableAd(adType: AdType) -> Bool {
        return getAvailableAd(adType: adType) != nil
    }
    
    /// Get current loading states for debugging
    func getCurrentLoadingStates() -> [String: Bool] {
        // Since we now allow parallel loading, we return the loading status based on pool size vs target volume
        var states: [String: Bool] = [:]
        for adType in AdType.allCases {
            let currentCount = getCurrentPoolCount(for: adType)
            let targetVolume = getVolume(for: adType)
            states[adType.rawValue] = currentCount < targetVolume
        }
        return states
    }
    
    
    static func gettopViewController() -> UIViewController {
        // App may be .foregroundInactive when willEnterForeground fires
        guard let windowScene = UIApplication.shared.connectedScenes
                .compactMap({ $0 as? UIWindowScene })
                .first(where: { $0.activationState == .foregroundActive || $0.activationState == .foregroundInactive }),
              let window = windowScene.windows.first(where: { $0.isKeyWindow }) ?? windowScene.windows.first,
              let root = window.rootViewController
        else {
            return UIViewController()
        }

        var top = root
        // Safely traverse up the presentation chain
        while let presented = top.presentedViewController {
            // Don't traverse if the presented VC is being dismissed
            guard !presented.isBeingDismissed else { break }
            top = presented
        }
        return top
    }
    // MARK: - Usage Example
    /*
    // How to configure with backup IDs:
    AdsManager.shared.configure(
        int_primary: "ca-app-pub-xxxxxxxxxxxxxxxx/yyyyyyyyyy",
        int_backup: "ca-app-pub-xxxxxxxxxxxxxxxx/zzzzzzzzzz",
        rewd_primary: "ca-app-pub-xxxxxxxxxxxxxxxx/yyyyyyyyyy",
        rewd_backup: "ca-app-pub-xxxxxxxxxxxxxxxx/zzzzzzzzzz",
        banner_primary: "ca-app-pub-xxxxxxxxxxxxxxxx/yyyyyyyyyy",
        banner_backup: "ca-app-pub-xxxxxxxxxxxxxxxx/zzzzzzzzzz",
        native_primary: "ca-app-pub-xxxxxxxxxxxxxxxx/yyyyyyyyyy",
        native_backup: "ca-app-pub-xxxxxxxxxxxxxxxx/zzzzzzzzzz",
        iappopen_primary: "ca-app-pub-xxxxxxxxxxxxxxxx/yyyyyyyyyy",
        iappopen_backup: "ca-app-pub-xxxxxxxxxxxxxxxx/zzzzzzzzzz",
        int_volume: 2,
        rewd_volume: 1,
        banner_volume: 1,
        native_volume: 2,
        iappopen_volume: 1
    )
    
    // The system will automatically:
    // 1. Try the primary ad unit ID first
    // 2. If it fails (no fill, error), automatically try the backup
    // 3. Use whichever succeeds
    // 4. All logging will show which ID was used (primary or backup)
    */
}

func delay(time: Double, closure: @escaping @Sendable @MainActor () -> Void) {
    DispatchQueue.main.asyncAfter(deadline: .now() + time) {
        Task { @MainActor in
            closure()
        }
    }
}

@MainActor
private enum LoadingIndicatorOverlay {
    private static weak var currentOverlay: UIView?
    
    static func show() {
        guard let window = activeWindow else {
            return
        }
        
        window.endEditing(true)
        
        if currentOverlay?.superview != nil {
            return
        }
        
        let overlay = UIView()
        overlay.translatesAutoresizingMaskIntoConstraints = false
        overlay.backgroundColor = UIColor.black.withAlphaComponent(0.18)
        overlay.alpha = 0
        
        let blurView = UIVisualEffectView(effect: UIBlurEffect(style: .systemUltraThinMaterialDark))
        blurView.translatesAutoresizingMaskIntoConstraints = false
        blurView.layer.cornerRadius = 18
        blurView.clipsToBounds = true
        
        let spinner = UIActivityIndicatorView(style: .large)
        spinner.translatesAutoresizingMaskIntoConstraints = false
        spinner.color = .white
        spinner.startAnimating()
        
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Loading..."
        label.textColor = .white
        label.font = .preferredFont(forTextStyle: .headline)
        
        blurView.contentView.addSubview(spinner)
        blurView.contentView.addSubview(label)
        overlay.addSubview(blurView)
        window.addSubview(overlay)
        
        NSLayoutConstraint.activate([
            overlay.leadingAnchor.constraint(equalTo: window.leadingAnchor),
            overlay.trailingAnchor.constraint(equalTo: window.trailingAnchor),
            overlay.topAnchor.constraint(equalTo: window.topAnchor),
            overlay.bottomAnchor.constraint(equalTo: window.bottomAnchor),
            
            blurView.centerXAnchor.constraint(equalTo: overlay.centerXAnchor),
            blurView.centerYAnchor.constraint(equalTo: overlay.centerYAnchor),
            blurView.widthAnchor.constraint(greaterThanOrEqualToConstant: 150),
            blurView.heightAnchor.constraint(equalToConstant: 112),
            
            spinner.centerXAnchor.constraint(equalTo: blurView.contentView.centerXAnchor),
            spinner.topAnchor.constraint(equalTo: blurView.contentView.topAnchor, constant: 24),
            
            label.centerXAnchor.constraint(equalTo: blurView.contentView.centerXAnchor),
            label.topAnchor.constraint(equalTo: spinner.bottomAnchor, constant: 12),
            label.leadingAnchor.constraint(greaterThanOrEqualTo: blurView.contentView.leadingAnchor, constant: 20),
            label.trailingAnchor.constraint(lessThanOrEqualTo: blurView.contentView.trailingAnchor, constant: -20)
        ])
        
        currentOverlay = overlay
        UIView.animate(withDuration: 0.18) {
            overlay.alpha = 1
        }
    }
    
    static func hide() {
        guard let overlay = currentOverlay else {
            return
        }
        
        UIView.animate(withDuration: 0.18, animations: {
            overlay.alpha = 0
        }, completion: { _ in
            overlay.removeFromSuperview()
        })
        currentOverlay = nil
    }
    
    private static var activeWindow: UIWindow? {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first { $0.activationState == .foregroundActive || $0.activationState == .foregroundInactive }?
            .windows
            .first { $0.isKeyWindow }
        ?? UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?
            .windows
            .first
    }
}

func showLoadingIndicator() {
    Task { @MainActor in
        LoadingIndicatorOverlay.show()
    }
}

func hideLoadingIndicator() {
    Task { @MainActor in
        LoadingIndicatorOverlay.hide()
    }
}
