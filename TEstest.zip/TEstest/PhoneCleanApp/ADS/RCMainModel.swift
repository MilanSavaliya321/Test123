//
//  RCMainModel.swift
//  
//
//  Created by MAC on 24/03/26.
//


// RCManager.swift — Optimized for 
import FirebaseRemoteConfig
import Foundation

// MARK: - RC Data Models (replaces ObjectMapper dependency)

private struct AGROW: Decodable {
    let ads_manager: RCAdsManager?
    let ads_id:      RCAdsID?
}

private struct RCAdPlacements: Decodable {
    let movie_card: Bool?
    let tv_card: Bool?
    let person_card: Bool?
    let carousel_item: Bool?
    let see_all: Bool?
    let episode: Bool?
    let gallery_image: Bool?
    let watch_provider: Bool?
    let search_result: Bool?
    let search_button: Bool?
    let back_button: Bool?
    let close_button: Bool?
    let download_button: Bool?
    let settings_button: Bool?
    let trailer_button: Bool?
    let season_switch: Bool?
    let roulette: Bool?
    let discover_banner: Bool?
    let play_button: Bool?
}

private struct RCAdsManager: Decodable {
    let enableInterstitialAd:            Bool?
    let enableNativeAd:                  Bool?
    let enableOpenAd:                    Bool?
    let enableRewardAd:                  Bool?
    let enableBannerAd:                  Bool?
    let ad_placements:                   RCAdPlacements?
    let show_gdpr:                       Bool?
    let show_int_or_rwd:                 String?
    let onload_ad:                       Bool?
    let allow_double_open:               Bool?
    let showPlayButton:                  Bool?
    let show_rating_prompt:              Bool?
    
    private enum CodingKeys: String, CodingKey {
        case enableInterstitialAd
        case enableNativeAd
        case enableOpenAd
        case enableRewardAd
        case enableBannerAd
        case show_gdpr
        case show_int_or_rwd
        case onload_ad
        case allow_double_open
        case showPlayButton = "show_play_button"
        case show_rating_prompt
        case ad_placements
    }
}

private struct RCAdsID: Decodable {
    let adid_interstitial:               String?
    let adid_native:                     String?
    let adid_banner:                     String?
    let adid_reward:                     String?
    let adid_open_ad:                    String?
    let adid_interstitial_backup:        String?
    let adid_native_backup:              String?
    let adid_banner_backup:              String?
    let adid_reward_backup:              String?
    let adid_open_ad_backup:             String?
}

// MARK: - RCManager

@MainActor
final class RCManager {
    static let shared = RCManager()
    private init() {}

    // MARK: Ad Flags (from RC)
    private(set) var enableInterstitialAd = false
    private(set) var enableNativeAd       = false
    private(set) var enableOpenAd         = false
    private(set) var enableRewardAd       = false
    private(set) var enableBannerAd       = false
    private(set) var show_gdpr            = false
    private(set) var show_int_or_rwd      = "int"
    private(set) var onload_ad            = false
    private(set) var allow_double_open    = false
    private(set) var showPlayButton       = true
    private(set) var showRatingPrompt     = true
    
    // MARK: Ad Placements
    private var adPlacements = [String: Bool]()
    func isPlacementEnabled(_ placement: String) -> Bool {
        return adPlacements[placement] ?? true // default to true if missing
    }

    // MARK: Ad IDs (from RC)
    private(set) var adid_interstitial         = ""
    private(set) var adid_native               = ""
    private(set) var adid_banner               = ""
    private(set) var adid_reward               = ""
    private(set) var adid_open_ad              = ""
    private(set) var adid_interstitial_backup  = ""
    private(set) var adid_native_backup        = ""
    private(set) var adid_banner_backup        = ""
    private(set) var adid_reward_backup        = ""
    private(set) var adid_open_ad_backup       = ""

    private(set) var isRCLoaded = false

    // MARK: - Load

    /// Loads RC with default fallback. Calls completion on main thread.
    func load(completion: @escaping @MainActor @Sendable () -> Void) {
        applyDefaults()
        fetchAndActivate(completion: completion)
    }

    // MARK: - Private

    private func applyDefaults() {
        guard let path = Bundle.main.path(forResource: "DefaultRC", ofType: "json"),
              let data = try? Data(contentsOf: URL(fileURLWithPath: path)) else { return }
        let rc = RemoteConfig.remoteConfig()
        if var json = try? JSONSerialization.jsonObject(with: data) as? [String: NSObject] {
            if json["AGROW"] == nil,
               let jsonString = String(data: data, encoding: .utf8) {
                json["AGROW"] = jsonString as NSString
            }
            rc.setDefaults(json)
        }
        // Apply defaults immediately so we have values even if fetch fails
        parseRemoteConfig()
    }

    private func fetchAndActivate(completion: @escaping @MainActor @Sendable () -> Void) {
        let rc = RemoteConfig.remoteConfig()
        let settings = RemoteConfigSettings()
        settings.minimumFetchInterval = 0 // 1 hour in production
        rc.configSettings = settings

        rc.fetchAndActivate { [weak self] status, error in
            Task { @MainActor [weak self] in
                guard let self else {
                    completion()
                    return
                }

                if let error {
                    print("[RC] Fetch failed, using defaults: \(error.localizedDescription)")
                    self.applyDefaults()
                } else {
                    print("[RC] Fetched successfully. Status: \(status)")
                }

                self.parseRemoteConfig()
                self.isRCLoaded = true
                completion()
            }
        }
    }

    private func parseRemoteConfig() {
        let rc = RemoteConfig.remoteConfig()
        
        let data = rc.configValue(forKey: "AGROW").dataValue
        
        do {
            let decoder = JSONDecoder()
            let decodedModel: AGROW
            
            // 🛠 SCENARIO 1: The JSON is wrapped inside an "AGOROW" root key (Like your printout)
            if let wrappedDict = try? decoder.decode([String: AGROW].self, from: data),
               let innerModel = wrappedDict["AGROW"] {
                decodedModel = innerModel
                print("[RC] ✅ Decoded WRAPPED JSON successfully")
            }
            // 🛠 SCENARIO 2: The JSON is direct (Like your Firebase screenshot)
            else {
                decodedModel = try decoder.decode(AGROW.self, from: data)
                print("[RC] ✅ Decoded DIRECT JSON successfully")
            }
            
            // 🚀 1. Map the Ads Manager Flags
            if let mgr = decodedModel.ads_manager {
                enableInterstitialAd = mgr.enableInterstitialAd ?? false
                enableNativeAd       = mgr.enableNativeAd       ?? false
                enableOpenAd         = mgr.enableOpenAd         ?? false
                enableRewardAd       = mgr.enableRewardAd       ?? false
                enableBannerAd       = mgr.enableBannerAd       ?? false
                show_gdpr            = mgr.show_gdpr            ?? false
                show_int_or_rwd      = mgr.show_int_or_rwd      ?? "int"
                onload_ad            = mgr.onload_ad            ?? false
                allow_double_open    = mgr.allow_double_open    ?? false
                showPlayButton       = mgr.showPlayButton       ?? true
                showRatingPrompt     = mgr.show_rating_prompt   ?? true
                
                if let placements = mgr.ad_placements {
                    adPlacements["movieCard"] = placements.movie_card
                    adPlacements["tvCard"] = placements.tv_card
                    adPlacements["personCard"] = placements.person_card
                    adPlacements["carouselItem"] = placements.carousel_item
                    adPlacements["seeAll"] = placements.see_all
                    adPlacements["episode"] = placements.episode
                    adPlacements["galleryImage"] = placements.gallery_image
                    adPlacements["watchProvider"] = placements.watch_provider
                    adPlacements["searchResult"] = placements.search_result
                    adPlacements["searchButton"] = placements.search_button
                    adPlacements["backButton"] = placements.back_button
                    adPlacements["closeButton"] = placements.close_button
                    adPlacements["downloadButton"] = placements.download_button
                    adPlacements["settingsButton"] = placements.settings_button
                    adPlacements["trailerButton"] = placements.trailer_button
                    adPlacements["seasonSwitch"] = placements.season_switch
                    adPlacements["roulette"] = placements.roulette
                    adPlacements["discoverBanner"] = placements.discover_banner
                    adPlacements["playButton"] = placements.play_button
                }
                
                print("[RC Success] ✅ Interstitial Ad Enabled is now: \(enableInterstitialAd)")
                print("[RC Success] ✅ Play Button Enabled is now: \(showPlayButton)")
            } else {
                print("[RC Warning] ⚠️ ads_manager was nil in the decoded model!")
            }
            
            // 🚀 2. Map the Ads IDs
            if let ids = decodedModel.ads_id {
                adid_interstitial        = ids.adid_interstitial        ?? ""
                adid_native              = ids.adid_native              ?? ""
                adid_banner              = ids.adid_banner              ?? ""
                adid_reward              = ids.adid_reward              ?? ""
                adid_open_ad             = ids.adid_open_ad             ?? ""
                adid_interstitial_backup = ids.adid_interstitial_backup ?? ""
                adid_native_backup       = ids.adid_native_backup       ?? ""
                adid_banner_backup       = ids.adid_banner_backup       ?? ""
                adid_reward_backup       = ids.adid_reward_backup       ?? ""
                adid_open_ad_backup      = ids.adid_open_ad_backup      ?? ""
            }
            // Configure AdManager immediately after parsing
            configureAdManager()
            
        } catch {
            print("[RC Decode Error] ❌ Failed to decode JSON: \(error.localizedDescription)")
        }
    }

    private func configureAdManager() {
        AdsManager.shared.configure(
            int_primary:      adid_interstitial,
            int_backup:       adid_interstitial_backup,
            rewd_primary:     adid_reward,
            rewd_backup:      adid_reward_backup,
            banner_primary:   adid_banner,
            banner_backup:    adid_banner_backup,
            native_primary:   adid_native,
            native_backup:    adid_native_backup,
            iappopen_primary: adid_open_ad,
            iappopen_backup:  adid_open_ad_backup
        )
    }
}
