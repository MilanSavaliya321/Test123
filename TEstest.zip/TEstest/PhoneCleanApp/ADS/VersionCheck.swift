import Foundation

final class VersionCheck: @unchecked Sendable {

    static let shared = VersionCheck()
    private init() {}

    /// Returns `true` if a newer version is available on the App Store.
    func isUpdateAvailable() async -> Bool {
        let bundleId = Bundle.main.bundleIdentifier ?? ""
        let ts = Date().timeIntervalSince1970
        let urlString = "https://itunes.apple.com/lookup?bundleId=\(bundleId)&t=\(ts)"

        guard let url = URL(string: urlString) else { return false }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            guard
                let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                let results = json["results"] as? [[String: Any]],
                let storeVersion = results.first?["version"] as? String,
                let currentVersion = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String
            else { return false }

            print("[VersionCheck] Current: \(currentVersion) | Store: \(storeVersion)")
            return currentVersion.compare(storeVersion, options: .numeric) == .orderedAscending

        } catch {
            print("[VersionCheck] Error:", error)
            return false
        }
    }

    /// Resolves the App Store URL for the app (using iTunes lookup result).
    func appStoreURL() async -> URL? {
        let bundleId = Bundle.main.bundleIdentifier ?? ""
        let ts = Date().timeIntervalSince1970
        let urlString = "https://itunes.apple.com/lookup?bundleId=\(bundleId)&t=\(ts)"
        guard let url = URL(string: urlString) else { return nil }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            guard
                let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                let results = json["results"] as? [[String: Any]],
                let trackViewUrl = results.first?["trackViewUrl"] as? String,
                let storeURL = URL(string: trackViewUrl)
            else { return nil }
            return storeURL
        } catch {
            return nil
        }
    }
}
