//
//  GDPRManager.swift
//  
//
//  Created by MAC on 24/03/26.
//

import AppTrackingTransparency
@preconcurrency import GoogleMobileAds
@preconcurrency import UserMessagingPlatform
import UIKit

@MainActor
final class GDPRManager {
    static let shared = GDPRManager()

    private init() {}

    func requestConsent(completion: @escaping @Sendable (Bool) -> Void) {
        Task { @MainActor in
            completion(await requestConsent())
        }
    }

    private func requestConsent() async -> Bool {
        let attGranted = await requestATT()

        let status = ConsentInformation.shared.consentStatus
        if status == .notRequired {
            print("✅ GDPR not required, enabling personalized ads")
            return true
        }

        if status == .obtained {
            print("✅ Consent already obtained")
            return true
        }

        guard attGranted else {
            print("❌ ATT not authorized, skipping GDPR")
            return true
        }

        return await requestGDPRConsent()
    }

    private func requestATT() async -> Bool {
        guard #available(iOS 14, *) else {
            return true
        }

        let usageDescription = Bundle.main.object(forInfoDictionaryKey: "NSUserTrackingUsageDescription") as? String
        guard usageDescription?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false else {
            print("⚠️ ATT permission skipped because NSUserTrackingUsageDescription is missing.")
            return false
        }

        let currentStatus = ATTrackingManager.trackingAuthorizationStatus
        guard currentStatus == .notDetermined else {
            return currentStatus == .authorized
        }

        return await withCheckedContinuation { continuation in
            ATTrackingManager.requestTrackingAuthorization { status in
                switch status {
                case .authorized:
                    print("✅ ATT authorized")
                    continuation.resume(returning: true)
                case .denied, .restricted, .notDetermined:
                    continuation.resume(returning: false)
                @unknown default:
                    continuation.resume(returning: false)
                }
            }
        }
    }

    private func requestGDPRConsent() async -> Bool {
        guard RCManager.shared.show_gdpr else {
            return true
        }

        guard NetworkMonitor.shared.isConnected else {
            return true
        }

        let parameters = RequestParameters()

        let updateSucceeded = await withCheckedContinuation { continuation in
            ConsentInformation.shared.requestConsentInfoUpdate(with: parameters) { error in
                if let error = error {
                    print("❌ Consent info update failed: \(error.localizedDescription)")
                    continuation.resume(returning: false)
                    return
                }

                continuation.resume(returning: true)
            }
        }

        guard updateSucceeded else {
            return false
        }

        let status = ConsentInformation.shared.consentStatus
        let formAvailable = ConsentInformation.shared.formStatus == .available

        if status == .required && formAvailable {
            return await loadAndShowConsentForm()
        }

        print("✅ Consent already obtained or not required")
        return status == .obtained || status == .notRequired
    }

    private func loadAndShowConsentForm() async -> Bool {
        do {
            let form = try await ConsentForm.load()
            try await form.present(from: GDPRManager.gettopViewController())
            return ConsentInformation.shared.consentStatus == .obtained
        } catch {
            print("❌ Consent form failed: \(error.localizedDescription)")
            return false
        }
    }

    static func gettopViewController() -> UIViewController {
        guard let windowScene = UIApplication.shared.connectedScenes
                .compactMap({ $0 as? UIWindowScene })
                .first(where: { $0.activationState == .foregroundActive || $0.activationState == .foregroundInactive }),
              let window = windowScene.windows.first(where: { $0.isKeyWindow }) ?? windowScene.windows.first,
              let root = window.rootViewController
        else {
            return UIViewController()
        }

        var top = root
        while let presented = top.presentedViewController {
            guard !presented.isBeingDismissed else { break }
            top = presented
        }
        return top
    }
}
