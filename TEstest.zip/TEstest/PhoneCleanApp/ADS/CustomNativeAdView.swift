import UIKit
import GoogleMobileAds

class CustomNativeAdView: XibLoadableView {

    @IBOutlet weak var mainAdView: NativeAdView!
    
    nonisolated override func awakeFromNib() {
        super.awakeFromNib()
        Task { @MainActor [weak self] in
            self?.configureAppearance()
        }
    }
    
    func populateAdData(_ nativeAd: NativeAd) {
        
        let callToAction = mainAdView.callToActionView as? UIButton
        callToAction?.layer.cornerRadius = 12
        
        mainAdView.mediaView?.mediaContent = nativeAd.mediaContent

        (mainAdView.headlineView as? UILabel)?.text = nativeAd.headline
        (mainAdView.bodyView as? UILabel)?.text = nativeAd.body
        (mainAdView.iconView as? UIImageView)?.image = nativeAd.icon?.image
        
        mainAdView.headlineView?.isHidden = nativeAd.headline == nil
        mainAdView.bodyView?.isHidden = nativeAd.body == nil
        mainAdView.iconView?.isHidden = nativeAd.icon == nil
        
        mainAdView.callToActionView?.isUserInteractionEnabled = false
        (mainAdView.callToActionView as? UIButton)?.setTitle(nativeAd.callToAction, for: .normal)
        mainAdView.callToActionView?.isHidden = nativeAd.callToAction == nil

        mainAdView.nativeAd = nativeAd
    }

    private func configureAppearance() {
        backgroundColor = .clear
        mainAdView.backgroundColor = .clear

        mainAdView.mediaView?.clipsToBounds = true
        mainAdView.mediaView?.layer.cornerRadius = 14
        mainAdView.mediaView?.backgroundColor = UIColor.secondarySystemGroupedBackground

        if let headlineLabel = mainAdView.headlineView as? UILabel {
            headlineLabel.font = .systemFont(ofSize: 15, weight: .black)
            headlineLabel.textColor = .label
            headlineLabel.numberOfLines = 2
        }

        if let bodyLabel = mainAdView.bodyView as? UILabel {
            bodyLabel.font = .systemFont(ofSize: 12, weight: .semibold)
            bodyLabel.textColor = .secondaryLabel
            bodyLabel.numberOfLines = 3
        }

        if let callToAction = mainAdView.callToActionView as? UIButton {
            callToAction.layer.cornerRadius = 12
            callToAction.clipsToBounds = true
            callToAction.backgroundColor = UIColor(hex: "#FFD600")
            callToAction.setTitleColor(.black, for: .normal)
            callToAction.titleLabel?.font = .systemFont(ofSize: 15, weight: .black)
        }

        if let adBadge = findAdAttributionLabel(in: mainAdView) {
            adBadge.textAlignment = .center
            adBadge.textColor = .black
            adBadge.backgroundColor = UIColor(hex: "#FFD600")
            adBadge.layer.cornerRadius = 3
            adBadge.clipsToBounds = true
            adBadge.font = .systemFont(ofSize: 10, weight: .black)
        }
    }

    private func findAdAttributionLabel(in view: UIView) -> UILabel? {
        for subview in view.subviews {
            if let label = subview as? UILabel, label.text?.lowercased() == "ad" {
                return label
            }
            if let nested = findAdAttributionLabel(in: subview) {
                return nested
            }
        }
        return nil
    }
}

// MARK: - Nib view for loading XIBs
class XibLoadableView: UIView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeFromXib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeFromXib()
    }
    
    func initializeFromXib() {
        let viewFromXib = Bundle.main.loadNibNamed(String(describing: type(of: self)), owner: self, options: nil)![0] as! UIView
        viewFromXib.frame = self.bounds
        viewFromXib.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        viewFromXib.clipsToBounds = true
        addSubview(viewFromXib)
    }
}
