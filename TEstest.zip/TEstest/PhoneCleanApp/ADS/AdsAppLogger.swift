//
//  AdsAppLogger.swift
//  
//
//  Created by MAC on 24/03/26.
//


import UIKit
import FirebaseAnalytics

class AdsAppLogger {
    
    static func logAdEvent(adType: AdType, eventType: AdEventType, error: Error? = nil, passVC: UIViewController?) {
        Task { @MainActor in
            let adTypeString = getAdTypeString(for: adType)
            var eventName = ""
            
            if eventType == .failToLoad || eventType == .failToShow {
                if let error = error {
                    let failString = eventType == .failToLoad ? "ftl" : "fts"
                    eventName = "ads_\(adTypeString)_\(failString)_" + "\(error._code)"
                }
            } else {
                eventName = "ads_\(adTypeString)_\(eventType.rawValue)"
            }
            
            // Log the event using Analytics
            Analytics.logEvent(eventName, parameters: nil)
            
            // Log error details if present
            if let error = error {
                print("[AdManager Event]: \(eventName) - Error: \(error.localizedDescription)")
            } else {
                print("[AdManager Event]: \(eventName)")
            }
        }
    }
    
    /// Converts AdType to string representation for events
    static func getAdTypeString(for adType: AdType) -> String {
        switch adType {
        case .interstitial:
            return "inter"
        case .rewardAd:
            return "reward"
        case .nativeAd:
            return "native"
        case .banner:
            return "banner"
        case .appOpenAd:
            return "open"
        }
    }

    static func logPaidEvent(eventName: String, parameters: [String: Any]) {
        let event = eventName.lowercased()
        print("[AdManager Event]: \(eventName), parameters: \(parameters)")
        Analytics.logEvent(event, parameters: parameters)
    }

}

// MARK: - Event Types Enum
enum AdEventType: String {
    case request = "request"
    case loaded = "loaded"
    case failToLoad = "fail_to_load"
    case failToShow = "fail_to_show"
    case show = "show"
    case open = "open"
    case close = "close"
    case dismiss = "dismiss"
    case impression = "impression"
    case click = "click"
}
