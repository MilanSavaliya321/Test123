//
//  AppConstants.swift
//  PhoneCleanApp
//
//  Created by MAC on 01/06/26.
//


import SwiftUI

// MARK: - UI Constants (MainActor)
@MainActor
enum AppConstants {
    // MARK: - Color Tokens
    static let canvas          = Color(hex: "#F2FAFF")
    static let surface         = Color.white
    static let elevatedSurface = Color(hex: "#EDF7FF")
    static let cardSurface     = Color.white
    static let primaryText     = Color(hex: "#152033")
    static let secondaryText   = Color(hex: "#64748B")
    static let accentBlue      = Color(hex: "#3BA2FF")
    static let accentDeepBlue  = Color(hex: "#1677FF")
    static let accentMint      = Color(hex: "#A7F3D0")
    static let border          = Color(hex: "#D7ECFA")

    // Compatibility aliases for copied shared infrastructure.
    static let canvasBlack     = canvas
    static let surfaceCharcoal = elevatedSurface
    static let accentGold      = accentBlue
    static let accentGry       = border
}
