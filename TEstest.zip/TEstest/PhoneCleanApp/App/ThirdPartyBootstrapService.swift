import FirebaseCore
import Foundation
@preconcurrency import GoogleMobileAds
import os

@MainActor
final class ThirdPartyBootstrapService {
    static let shared = ThirdPartyBootstrapService()

    private let logger = Logger(subsystem: "deep.clean.my.phone", category: "bootstrap")
    private var hasStartedMobileAds = false

    private init() {}

    func configureFirebaseIfPossible() {
        guard FirebaseApp.app() == nil else { return }

        guard Bundle.main.url(forResource: "GoogleService-Info", withExtension: "plist") != nil else {
            logger.error("Skipping Firebase setup because GoogleService-Info.plist is missing from the bundle.")
            return
        }

        FirebaseApp.configure()
    }

//    func configureRevenueCatIfPossible() {
//        guard !IAPurchaseHelper.shared.isConfigured else { return }
//
//        let apiKey = stringInfoValue(for: "RevenueCatAPIKey")
//        guard !apiKey.isEmpty else {
//            logger.error("Skipping RevenueCat setup because RevenueCatAPIKey is empty in Info.plist.")
//            return
//        }
//
//        IAPurchaseHelper.shared.configure(apiKey: apiKey)
//    }

    func configureMobileAdsIfPossible() async {
        guard !hasStartedMobileAds else { return }
        guard !stringInfoValue(for: "GADApplicationIdentifier").isEmpty else {
            logger.error("Skipping Google Mobile Ads setup because GADApplicationIdentifier is empty in Info.plist.")
            return
        }

        hasStartedMobileAds = true
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            MobileAds.shared.start { [logger] status in
                logger.info("Google Mobile Ads started with \(status.adapterStatusesByClassName.count, privacy: .public) adapters.")
                continuation.resume()
            }
        }
    }

    func configureAll() {
        configureFirebaseIfPossible()
//        configureRevenueCatIfPossible()
    }

    func stringInfoValue(for key: String) -> String {
        let rawValue = Bundle.main.object(forInfoDictionaryKey: key) as? String ?? ""
        return rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
