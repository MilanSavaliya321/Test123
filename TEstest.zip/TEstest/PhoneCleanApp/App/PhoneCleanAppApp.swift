import FirebaseCore
import SwiftUI
import SwiftData

struct PhoneCleanApp: View {
    @State private var router = Router()
    @State private var showCountryPicker = false

    @Environment(\.scenePhase) private var scenePhase

    @AppStorage("phoneClean.gdprConsentGranted") private var gdprConsentGranted = false
    @AppStorage("phoneClean.hasSeenOnboarding") private var hasSeenOnboarding = false

    @State private var hasStarted = false
    @State private var isStartingUp = true
    @State private var showOnboarding = false
    @State private var hasCompletedLaunchAdFlow = false
    @State private var isShowingFullscreenAd = false
    @State private var splashStage: PremiumSplashStage = .booting

    var body: some View {
        ZStack {
            MainTabView()
                .environment(router)
                .environment(UserPreferences.shared)
                .opacity(isStartingUp ? 0 : 1)

            if isStartingUp {
                PremiumSplashView(stage: splashStage)
                    .transition(.opacity)
            }
        }
        .preferredColorScheme(.light)
        .task {
            guard !hasStarted else { return }
            hasStarted = true
            await startupSequence()
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willEnterForegroundNotification)) { _ in
            guard hasCompletedLaunchAdFlow else { return }
            Task { @MainActor in
                await showForegroundAppOpenAdIfNeeded()
            }
        }
        .fullScreenCover(isPresented: $showOnboarding) {
            OnboardingView {
                completeOnboarding()
            }
        }
    }

    // MARK: - Startup Sequence (ads infrastructure)

    @MainActor
    private func startupSequence() async {
        isStartingUp = true
        showOnboarding = false
        splashStage = .booting

        ThirdPartyBootstrapService.shared.configureAll()
        splashStage = .preparingServices

        // Network gate
        if !NetworkMonitor.shared.isConnected {
            for _ in 0..<6 {
                try? await Task.sleep(for: .milliseconds(500))
                if NetworkMonitor.shared.isConnected { break }
            }
            if !NetworkMonitor.shared.isConnected {
                NetworkOverlayWindow.shared.onRetry = { [self] in
                    Task { @MainActor in
                        self.hasStarted = false
                        guard !self.hasStarted else { return }
                        self.hasStarted = true
                        await self.startupSequence()
                    }
                }
                NetworkOverlayWindow.shared.show()
                return
            }
        }

        let splashFloorTask = Task {
            try? await Task.sleep(for: .milliseconds(1600))
        }

        let preparationTask = Task {
            await Self.prepareLaunchDependencies(
                existingConsent: gdprConsentGranted,
                isConnected: NetworkMonitor.shared.isConnected
            )
        }

        let preparation = await Self.waitForTask(
            preparationTask,
            timeout: gdprConsentGranted ? .seconds(4) : .seconds(120),
            fallback: PhoneCleanLaunchPreparation.fallback(existingConsent: gdprConsentGranted)
        )

        _ = await splashFloorTask.result
        gdprConsentGranted = preparation.gdprConsentGranted

        // Force-update gate
        splashStage = .checkingUpdates
        async let updateAvailable = VersionCheck.shared.isUpdateAvailable()
        async let storeURL = VersionCheck.shared.appStoreURL()
        let (needsUpdate, fetchedURL) = await (updateAvailable, storeURL)
        if needsUpdate {
            let url = fetchedURL ?? URL(string: "https://apps.apple.com")!
            AppOverlayWindowManager.shared.showForceUpdate(appStoreURL: url)
            isStartingUp = false
            return
        }

        await showLaunchAppOpenAdsIfNeeded()
        hasCompletedLaunchAdFlow = true

        if !hasSeenOnboarding {
            splashStage = .openingOnboarding
            showOnboarding = true
            try? await Task.sleep(for: .milliseconds(100))
        }

        splashStage = .ready

        withAnimation(.easeOut(duration: 0.22)) {
            isStartingUp = false
        }
        
        // Now the tab bar is visible — allow rating prompts if onboarding is already completed
        if hasSeenOnboarding {
            RatingManager.shared.isAppReady = true
            RatingManager.shared.requestReviewSoon()
        }

        // Enable mid-app network overlay
        NetworkOverlayWindow.shared.onRetry = { [self] in
            Task { @MainActor in
                self.hasStarted = false
                guard !self.hasStarted else { return }
                self.hasStarted = true
                withAnimation { self.isStartingUp = true }
                await self.startupSequence()
            }
        }
        NetworkOverlayCoordinator.shared.start()
        NetworkOverlayCoordinator.shared.isActive = true
    }

    @MainActor
    private func completeOnboarding() {
        hasSeenOnboarding = true
        showOnboarding = false
        
        // Show rating prompt when onboarding completes and main tab bar becomes visible
        RatingManager.shared.isAppReady = true
        RatingManager.shared.requestReviewSoon()
    }

    // MARK: - Ad Helpers

    @MainActor
    private func showForegroundAppOpenAdIfNeeded() async {
        guard !isStartingUp else { return }
        guard NetworkMonitor.shared.isConnected, gdprConsentGranted else { return }
        guard RCManager.shared.isRCLoaded, RCManager.shared.enableOpenAd else { return }
        await showFullscreenAd(.appOpenAd, timeout: .seconds(3))
    }

    @MainActor
    private func showLaunchAppOpenAdsIfNeeded() async {
        guard NetworkMonitor.shared.isConnected, gdprConsentGranted else { return }
        guard RCManager.shared.isRCLoaded, RCManager.shared.enableOpenAd else { return }

        let desiredCount = RCManager.shared.allow_double_open ? 2 : 1
        splashStage = .preparingAds
        for adIndex in 1...desiredCount {
            splashStage = .showingAppOpen(current: adIndex, total: desiredCount)
            let didShowAndClose = await showFullscreenAd(.appOpenAd, timeout: .seconds(6))
            guard didShowAndClose else { return }
        }
    }

    @MainActor
    @discardableResult
    private func showFullscreenAd(_ adType: AdType, timeout: Duration? = nil) async -> Bool {
        guard !isShowingFullscreenAd else { return false }
        isShowingFullscreenAd = true
        defer { isShowingFullscreenAd = false }

        let topViewController = AdsManager.gettopViewController()
        return await withCheckedContinuation { (continuation: CheckedContinuation<Bool, Never>) in
            var hasResumed = false
            var hasShown = false

            func resumeOnce(_ result: Bool) {
                guard !hasResumed else { return }
                hasResumed = true
                continuation.resume(returning: result)
            }

            let completion = AdEventCompletion(
                onFail: { _ in resumeOnce(false) },
                onShow: { hasShown = true },
                onClose: { resumeOnce(hasShown) }
            )

            AdsManager.shared.showOnload(adType, from: topViewController, refill: false, completion: completion)

            if let timeout {
                Task { @MainActor in
                    try? await Task.sleep(for: timeout)
                    if !hasShown { resumeOnce(false) }
                }
            }
        }
    }

    // MARK: - Launch Dependencies

    private static func prepareLaunchDependencies(existingConsent: Bool, isConnected: Bool) async -> PhoneCleanLaunchPreparation {
        async let remoteConfigLoad: Void = loadRemoteConfigIfPossible()
        _ = await remoteConfigLoad

        let gdprGranted: Bool
        if isConnected {
            gdprGranted = await requestGDPRConsentIfNeeded(existingConsent: existingConsent)
        } else {
            gdprGranted = existingConsent
        }

        await ThirdPartyBootstrapService.shared.configureMobileAdsIfPossible()
        await preloadLaunchAdsIfPossible(gdprGranted: gdprGranted, isConnected: isConnected)
        return PhoneCleanLaunchPreparation(gdprConsentGranted: gdprGranted)
    }

    private static func waitForTask<T: Sendable>(_ task: Task<T, Never>, timeout: Duration, fallback: T) async -> T {
        await withTaskGroup(of: T.self) { group in
            group.addTask { await task.value }
            group.addTask {
                try? await Task.sleep(for: timeout)
                return fallback
            }
            let value = await group.next() ?? fallback
            group.cancelAll()
            return value
        }
    }

    @MainActor
    private static func loadRemoteConfigIfPossible() async {
        guard FirebaseApp.app() != nil else { return }
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            RCManager.shared.load {
                continuation.resume()
            }
        }
    }

    @MainActor
    private static func requestGDPRConsentIfNeeded(existingConsent: Bool) async -> Bool {
        await withCheckedContinuation { (continuation: CheckedContinuation<Bool, Never>) in
            GDPRManager.shared.requestConsent { granted in
                continuation.resume(returning: granted || existingConsent)
            }
        }
    }

    @MainActor
    private static func preloadLaunchAdsIfPossible(gdprGranted: Bool, isConnected: Bool) async {
        guard isConnected, gdprGranted else { return }
        guard RCManager.shared.isRCLoaded else { return }

        let topViewController = AdsManager.gettopViewController()
        AdsManager.shared.preloadAd(.appOpenAd, viewController: topViewController)
        AdsManager.shared.preloadAd(.interstitial, viewController: topViewController)

        if !RCManager.shared.onload_ad {
            try? await Task.sleep(for: .milliseconds(650))
        }
    }
}

private struct PhoneCleanLaunchPreparation: Sendable {
    let gdprConsentGranted: Bool

    static func fallback(existingConsent: Bool) -> Self {
        Self(gdprConsentGranted: existingConsent)
    }
}
