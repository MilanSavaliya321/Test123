import Foundation
import Photos
import SDWebImage
import UIKit

/// A custom SDImageLoader that handles "phasset://" URLs using PHImageManager
class PHAssetImageLoader: NSObject, SDImageLoader {
    static let shared = PHAssetImageLoader()
    
    func canRequestImage(for url: URL?) -> Bool {
        return url?.scheme == "phasset"
    }
    
    func requestImage(
        with url: URL?,
        options: SDWebImageOptions = [],
        context: [SDWebImageContextOption : Any]?,
        progress progressBlock: SDImageLoaderProgressBlock?,
        completed completedBlock: SDImageLoaderCompletedBlock? = nil
    ) -> SDWebImageOperation? {
        guard let url = url, url.scheme == "phasset" else {
            let error = NSError(domain: "PHAssetImageLoader", code: -1, userInfo: [NSLocalizedDescriptionKey: "Invalid URL or scheme"])
            completedBlock?(nil, nil, error, true)
            return nil
        }
        
        // The local identifier is everything after the "://"
        // URL components might split it strangely if it contains slashes or equals,
        // so we extract it directly from the absolute string.
        let prefix = "phasset://"
        let absoluteString = url.absoluteString
        guard absoluteString.hasPrefix(prefix) else {
            let error = NSError(domain: "PHAssetImageLoader", code: -2, userInfo: [NSLocalizedDescriptionKey: "Invalid URL format"])
            completedBlock?(nil, nil, error, true)
            return nil
        }
        
        let localIdentifier = String(absoluteString.dropFirst(prefix.count))
        
        let fetchResult = PHAsset.fetchAssets(withLocalIdentifiers: [localIdentifier], options: nil)
        guard let asset = fetchResult.firstObject else {
            let error = NSError(domain: "PHAssetImageLoader", code: -3, userInfo: [NSLocalizedDescriptionKey: "Asset not found"])
            completedBlock?(nil, nil, error, true)
            return nil
        }
        
        // Use thumbnail size from context if provided, else a generic 350x350
        let targetSize = context?[.imageThumbnailPixelSize] as? CGSize ?? CGSize(width: 150, height: 150)
        
        let requestOptions = PHImageRequestOptions()
        requestOptions.deliveryMode = .opportunistic
        requestOptions.resizeMode = .fast
        requestOptions.isNetworkAccessAllowed = true
        
        let requestID = PHImageManager.default().requestImage(
            for: asset,
            targetSize: targetSize,
            contentMode: .aspectFill,
            options: requestOptions
        ) { image, info in
            let hasError = info?[PHImageErrorKey] != nil
            let wasCancelled = (info?[PHImageCancelledKey] as? Bool) == true
            
            if wasCancelled {
                // If cancelled, do not call completed block with error as per SDWebImage convention
                return
            }
            
            let isDegraded = (info?[PHImageResultIsDegradedKey] as? Bool) == true
            let finished = !isDegraded
            
            if let image = image {
                completedBlock?(image, nil, nil, finished)
            } else {
                let error = (info?[PHImageErrorKey] as? Error) ?? NSError(domain: "PHAssetImageLoader", code: -4, userInfo: [NSLocalizedDescriptionKey: "Failed to load image"])
                completedBlock?(nil, nil, error, true)
            }
        }
        
        return PHAssetImageOperation(requestID: requestID)
    }
    
    func shouldBlockFailedURL(with url: URL, error: Error) -> Bool {
        return false
    }
}

class PHAssetImageOperation: NSObject, SDWebImageOperation {
    let requestID: PHImageRequestID
    var isCancelled: Bool = false
    
    init(requestID: PHImageRequestID) {
        self.requestID = requestID
    }
    
    func cancel() {
        if !isCancelled {
            PHImageManager.default().cancelImageRequest(requestID)
            isCancelled = true
        }
    }
}
