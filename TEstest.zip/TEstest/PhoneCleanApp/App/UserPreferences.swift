//
//  UserPreferences.swift
//  PhoneCleanApp
//
//  Created by MAC on 01/06/26.
//


import SwiftUI

@Observable
final class UserPreferences {
    var hasCompletedOnboarding: Bool = true

    static let shared = UserPreferences()
    private init() {}
}
