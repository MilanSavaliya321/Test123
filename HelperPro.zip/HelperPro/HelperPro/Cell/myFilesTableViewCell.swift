//
//  myFilesTableViewCell.swift
//  PdfScan
//
//  Created by iOS on 23/02/22.
//  Copyright © 2022 MacOs. All rights reserved.
//

import UIKit

class myFilesTableViewCell: UITableViewCell {

    @IBOutlet weak var imgSelect: UIImageView!
    @IBOutlet weak var imgThumb: UIImageView!
    @IBOutlet weak var lblFileName: UILabel!
    @IBOutlet weak var lblFileDetail: UILabel!
    @IBOutlet weak var viewOption: UIView!
    @IBOutlet weak var btnOption: UIButton!
    @IBOutlet weak var imgOption: UIImageView!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var imgLock: UIImageView!

    var index: Int?
    
    override func prepareForReuse() {
        super.prepareForReuse()
        imgThumb.image = UIImage(named: "ic_pdf_placeholder")
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        lblFileName.textColor = .black
        lblFileDetail.textColor = .black
        lblDate.textColor = .black
    }
    
}
