//
//  ViewController.swift
//  HelperPro
//
//  Created by IOS on 02/04/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var tblFiles: UITableView!
    @IBOutlet weak var viewOption: UIView!
    
    var selectedOptionIndex: Int?
    var arrFiles = [URL]()
    var isSelectMode = false
    var arrSelected = [URL]()
    
    var subFolderUrl: URL!
    var isSubFolder = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblFiles.register(.init(nibName: "myFilesTableViewCell", bundle: nil), forCellReuseIdentifier: "myFilesTableViewCell")
        tblFiles.dataSource = self
        tblFiles.delegate = self
        tblFiles.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fatchData()
    }
    
    func fatchData() {
        if isSubFolder {
            lblTitle.text = subFolderUrl.lastPathComponent
            getAndRefreshData(inDirectory: subFolderUrl)
        } else {
            getAndRefreshData()
        }
    }

    func getAndRefreshData(inDirectory: URL = mainDirUrl) {
        CustomFileManager.shared.retrieveFilesAndFolders(inDirectory: inDirectory) { result in
            switch result {
            case .success(let success):
                self.arrFiles = success
                self.tblFiles.reloadData()
            case .failure(let failure):
                print(failure.localizedDescription)
            }
        }
    }
    
    @objc func funOptionClicked(_ sender: UIButton) {
        viewOption.isHidden.toggle()
        print(sender.tag)
        selectedOptionIndex = sender.tag
    }
    
    @IBAction func onBtnSelectMode(_ sender: UIButton) {
        isSelectMode.toggle()
        arrSelected = []
        tblFiles.reloadData()
    }
    
    @IBAction func btnHideOptionView(_ sender: Any) {
        viewOption.isHidden.toggle()
    }
    @IBAction func onbtnCreateFolder(_ sender: Any) {
        showCreateFolderPopup()
    }
    
    @IBAction func onBtnOption(_ sender: UIButton) {
        viewOption.isHidden.toggle()
        selectedFolderURL = nil
        if sender.tag == 0 { // create folder
            showCreateFolderPopup()
        }
        
        if sender.tag == 1 { // rename
            showRenamePopup()
        }
        
        if sender.tag == 2 { // copy
            
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "FolderListViewController") as! FolderListViewController
            vc.selectedFileFolderUrl = arrFiles[selectedOptionIndex!]
            vc.fileOprationType = .copy
            // arrCopyUrls for multiple item copy
            vc.arrCopyUrls = self.arrSelected
            vc.compDone = {
                self.fatchData()
            }
            navigationController?.pushViewController(vc, animated: true)
        }
        
        if sender.tag == 3 { // move
            
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "FolderListViewController") as! FolderListViewController
            vc.selectedFileFolderUrl = arrFiles[selectedOptionIndex!]
            vc.fileOprationType = .move
            // arrCopyUrls for multiple item move
            vc.arrCopyUrls = self.arrSelected
            vc.compDone = {
                self.fatchData()
            }
            navigationController?.pushViewController(vc, animated: true)
        }
        
        if sender.tag == 4 { // delete
        
            if arrSelected.count > 1 {
                CustomFileManager.shared.deleteItems(at: arrSelected){ result in
                    switch result {
                    case .success(let success):
                        print(success)
                        self.fatchData()
                    case .failure(let failure):
                        print(failure.localizedDescription)
                    }
                }
            } else {
                CustomFileManager.shared.deleteItem(at: arrFiles[selectedOptionIndex!]){ result in
                    switch result {
                    case .success(let success):
                        print(success)
                        self.fatchData()
                    case .failure(let failure):
                        print(failure.localizedDescription)
                    }
                }
            }
        }
    }
    
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        arrFiles.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "myFilesTableViewCell") as? myFilesTableViewCell else { return .init() }
        
        let file = arrFiles[indexPath.row]
        
        if file.isDirectory() {
            cell.imgThumb.image = UIImage(named: "ic_folder")
        } else {
            cell.imgThumb.image = UIImage(named: "ic_file")
        }
        
        cell.lblFileName.text = file.fileName()
        cell.lblFileDetail.text = file.fileSize()?.toReadableFileSize()
        cell.lblDate.text = file.creationDate()?.formattedDateString()
        
        cell.index = indexPath.row
        cell.btnOption.tag = indexPath.row
        cell.btnOption.addTarget(self, action: #selector(funOptionClicked), for: .touchUpInside)
        
        if isSelectMode {
            cell.imgSelect.isHidden = false
        } else {
            cell.imgSelect.isHidden = true
        }
        
        if arrSelected.contains(arrFiles[indexPath.row]) {
            cell.imgSelect.isHighlighted = true
        } else {
            cell.imgSelect.isHighlighted = false
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if isSelectMode {
            let selectedURL = arrFiles[indexPath.row]
            if checkIsSelected(url: selectedURL) {
                if let index = arrSelected.firstIndex(of: selectedURL) {
                    arrSelected.remove(at: index)
                }
            } else {
                arrSelected.append(selectedURL)
            }
            tblFiles.reloadData()
        } else {
            if arrFiles[indexPath.row].isFile() { return }
            let folderUrl = arrFiles[indexPath.row]
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewController") as! ViewController
            vc.isSubFolder = true
            vc.subFolderUrl = folderUrl
            self.navigationController?.pushViewController(vc, animated: true)
            
//            CustomFileManager.shared.retrieveFilesAndFolders(inDirectory: folderUrl) { result in
//                switch result {
//                case .success(let success):
//                    let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewController") as! ViewController
//                    vc.arrFiles = success
//                    vc.isSubFolder = true
//                    vc.subFolderUrl = folderUrl
//                    self.navigationController?.pushViewController(vc, animated: true)
//                case .failure(let failure):
//                    print(failure.localizedDescription)
//                }
//            }
            

        }
    }
    
    func checkIsSelected(url: URL) -> Bool {
        for i in arrSelected {
            if i == url {
                return true
            }
        }
        return false
    }
}



extension ViewController {
    
    func showCreateFolderPopup() {
        let alertController = UIAlertController(title: "Create Folder", message: "Enter item name:", preferredStyle: .alert)
        alertController.addTextField { textField in
            textField.placeholder = "Item Name"
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { _ in
  
        }

        let createAction = UIAlertAction(title: "Create", style: .default) { _ in
            if let itemName = alertController.textFields?.first?.text {
                guard let createUrl = self.isSubFolder ? self.subFolderUrl : mainDirUrl else { return }
                CustomFileManager.shared.createFolder(at: createUrl, folderName: itemName) { result in
                    switch result {
                    case .success(let success):
                        self.fatchData()
                        print(success, " success")
                    case .failure(let failure):
                        print(failure.localizedDescription)
                    }
                }
                print("Item Name: \(itemName)")
            }
        }
        
        alertController.addAction(cancelAction)
        alertController.addAction(createAction)
    
        present(alertController, animated: true, completion: nil)
    }
    
    func showRenamePopup() {
        let alertController = UIAlertController(title: "Rename", message: "Enter item new name:", preferredStyle: .alert)
        alertController.addTextField { textField in
            textField.placeholder = "Item Name"
            textField.text = self.arrFiles[self.selectedOptionIndex!].fileName()
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .default) { _ in
  
        }

        let createAction = UIAlertAction(title: "Rename", style: .default) { _ in
            if let itemName = alertController.textFields?.first?.text {
                CustomFileManager.shared.renameItem(at: self.arrFiles[self.selectedOptionIndex!], newName: itemName) { result in
                    switch result {
                    case .success(let success):
                        self.fatchData()
                        print(success)
                    case .failure(let failure):
                        print(failure.localizedDescription)
                    }
                }
                print("Item Name: \(itemName)")
            }
        }
        
        alertController.addAction(cancelAction)
        alertController.addAction(createAction)
    
        present(alertController, animated: true, completion: nil)
    }
}
