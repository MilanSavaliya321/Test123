//
//  ExcelExportVC.swift
//  HelperPro
//
//  Created by IOS on 05/04/24.
//

import UIKit
import SwiftXLSX

class ExcelExportVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let book = XWorkBook()

        // Create a new sheet named "Expenses"
        let sheet = book.NewSheet("Expenses")
        var cell = sheet.AddCell(XCoords(row: 0, col: 0))
        // Add headers for the expense sheet
        cell = sheet.AddCell(XCoords(row: 1, col: 1))
        cell.Border = true
        cell.colorbackground = .green
        cell.value = .text("Date")
        
        cell = sheet.AddCell(XCoords(row: 1, col: 2))
        cell.Border = true
        cell.colorbackground = .green
        cell.value = .text("Category")
        
        cell = sheet.AddCell(XCoords(row: 1, col: 3))
        cell.Border = true
        cell.colorbackground = .green
        cell.value = .text("Amount")
        
        // Add daily expenses data (replace with your actual data)
        let dailyExpenses: [(date: String, category: String, amount: Double)] = [
            ("2024-04-01", "Food", 25.50),
            ("2024-04-01", "Transport", 10.00),
            ("2024-04-02", "Food", 20.00),
            // Add more expenses as needed
        ]
        
        // Add daily expenses to the sheet
        var currentRow = 2
        for expense in dailyExpenses {
            cell = sheet.AddCell(XCoords(row: currentRow, col: 1))
            cell.Border = true
            cell.value = .text(expense.date)
            
            cell = sheet.AddCell(XCoords(row: currentRow, col: 2))
            cell.Border = true
            cell.value = .text(expense.category)
            
            cell = sheet.AddCell(XCoords(row: currentRow, col: 3))
            cell.Border = true
            cell.value = .double(expense.amount)
            
            currentRow += 1
        }
        
        let rs = book.save("invoice_expenses.xlsx")
        print(rs)
    }
}
