//
//  FolderListViewController.swift
//  HelperPro
//
//  Created by IOS on 02/04/24.
//

import UIKit

class Folder {
    let name: String
    let url: URL
    var subfolders: [Folder] = []
    
    init(name: String, url: URL) {
        self.name = name
        self.url = url
    }
}

enum FileOprationType {
    case copy
    case move
}

var selectedFolderURL: URL?

class FolderListViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!

    
    var folders: [Folder] = []
    var isFromSubFolder = false
    var selectedFileFolderUrl: URL?
    var fileOprationType: FileOprationType = .copy
    var compDone: (()->())?
    var arrCopyUrls: [URL]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Set up table view
        tableView.register(.init(nibName: "FolderCell", bundle: nil), forCellReuseIdentifier: "FolderCell")
        tableView.dataSource = self
        tableView.delegate = self
        
        if !isFromSubFolder {
            do {
                let folders = try getAllFolders(from: mainDirUrl)
                print(folders)
                self.folders = folders
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    self.tableView.reloadData()
                }
                
            } catch {
                print("Error: \(error)")
            }
        } else {
            self.tableView.reloadData()
        }
    }
    
    
    func getAllFolders(from directoryURL: URL) throws -> [Folder] {
        var folders: [Folder] = []
        
        // Get contents of directory
        let contents = try FileManager.default.contentsOfDirectory(at: directoryURL, includingPropertiesForKeys: nil, options: [])
        
        for itemURL in contents {
            var isDirectory: ObjCBool = false
            // Check if item is a directory
            if FileManager.default.fileExists(atPath: itemURL.path, isDirectory: &isDirectory) && isDirectory.boolValue {
                let folder = Folder(name: itemURL.lastPathComponent, url: itemURL)
                folder.subfolders = try getAllFolders(from: itemURL) // Recursively get subfolders
                folders.append(folder)
            }
        }
        
        return folders
    }

    @IBAction func onBtnSelect(_ sender: UIButton) {
        
        if fileOprationType == .copy {
            
            if (arrCopyUrls?.count ?? 0) > 1 {
                guard let atPath = arrCopyUrls, let toPath = selectedFolderURL else { return }
                CustomFileManager.shared.copyItems(at: atPath, to: toPath) { result in
                    switch result {
                    case .success(let success):
                        print(success)
                        self.compDone?()
                        self.navigationController?.popToRootViewController(animated: true)
                    case .failure(let failure):
                        print(failure.localizedDescription)
                    }
                }
            } else {                
                guard let atPath = selectedFileFolderUrl, let toPath = selectedFolderURL else { return }
                CustomFileManager.shared.copyItem(at: atPath, to: toPath) { result in
                    switch result {
                    case .success(let success):
                        print(success)
                        self.compDone?()
                        self.navigationController?.popToRootViewController(animated: true)
                    case .failure(let failure):
                        print(failure.localizedDescription)
                    }
                }
            }
        }
        
        if fileOprationType == .move {
            if (arrCopyUrls?.count ?? 0) > 1 {
                
                guard let atPath = arrCopyUrls, let toPath = selectedFolderURL else { return }
                CustomFileManager.shared.moveItems(at: atPath, to: toPath) { result in
                    switch result {
                    case .success(let success):
                        print(success)
                        self.compDone?()
                        self.navigationController?.popToRootViewController(animated: true)
                    case .failure(let failure):
                        print(failure.localizedDescription)
                    }
                }
            } else {
                
                guard let atPath = selectedFileFolderUrl, let toPath = selectedFolderURL else { return }
                CustomFileManager.shared.moveItem(at: atPath, to: toPath) { result in
                    switch result {
                    case .success(let success):
                        print(success)
                        self.compDone?()
                        self.navigationController?.popToRootViewController(animated: true)
                    case .failure(let failure):
                        print(failure.localizedDescription)
                    }
                }
            }
        }
    }
    
}

extension FolderListViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return folders.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let folder = folders[indexPath.row]
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "FolderCell") as? FolderCell else { return .init() }
        cell.lblTitle.text = folder.name
        
//         Indent cell based on subfolder depth
//        cell.indentationLevel = folder.subfolders.isEmpty ? 0 : 1
//        cell.indentationWidth = 20
        
        return cell
    }

    // MARK: - UITableViewDelegate

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let folder = folders[indexPath.row]
        
        selectedFolderURL = folder.url
        
        if !folder.subfolders.isEmpty {
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "FolderListViewController") as! FolderListViewController
            vc.isFromSubFolder = true
            vc.selectedFileFolderUrl = self.selectedFileFolderUrl
            vc.folders = folder.subfolders
            vc.arrCopyUrls = self.arrCopyUrls
            vc.fileOprationType = self.fileOprationType
            vc.compDone = self.compDone
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        50
    }
}
