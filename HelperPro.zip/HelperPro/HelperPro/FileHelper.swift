//
//  FileHelper.swift
//  HelperPro
//
//  Created by IOS on 02/04/24.
//

import Foundation
import MobileCoreServices
import UIKit
import AVKit

// Custom error types
enum FileManagerError: Error {
    case fileSizeNotFound
    case modificationDateNotFound
    case creationDateNotFound
    case invalidBatchOperation
    case unableToReadFile
    case unableToWriteFile
}

var mainDirUrl = CustomFileManager.shared.appFolderUrl()

enum DirectoryType {
    case document
    case cache
    case library
    case temporary
    case applicationSupport
    case sharedContainer(appGroupIdentifier: String)
}

class CustomFileManager {
    static let shared = CustomFileManager()
    private let fileManager = FileManager.default
    private let appFolderName = "AllDocs"
    private init() {}
    
    func appFolderUrl(for type: DirectoryType = .document) -> URL {
        // use path for url and use absolute string whrn you are using string
        return (directoryURL(for: type)?.appendingPathComponent(appFolderName))!
    }
    
    // MARK: - Directory URL
    private func directoryURL(for type: DirectoryType) -> URL? {
        let fileManager = FileManager.default
        switch type {
        case .document:
            return fileManager.urls(for: .documentDirectory, in: .userDomainMask).first
        case .cache:
            return fileManager.urls(for: .cachesDirectory, in: .userDomainMask).first
        case .library:
            return fileManager.urls(for: .libraryDirectory, in: .userDomainMask).first
        case .temporary:
            return URL(fileURLWithPath: NSTemporaryDirectory())
        case .applicationSupport:
            return fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
        case .sharedContainer(let appGroupIdentifier):
            return fileManager.containerURL(forSecurityApplicationGroupIdentifier: appGroupIdentifier)
        }
    }

    func createAppDirectory() {
        let dataPath = mainDirUrl
        print(dataPath)
        if !FileManager.default.fileExists(atPath: dataPath.path) {
            do {
                try FileManager.default.createDirectory(atPath: dataPath.path, withIntermediateDirectories: true, attributes: nil)
            } catch {
                print(error.localizedDescription);
            }
        }
    }
    
    // MARK: - File Operations
    
    func createFolder(at url: URL, folderName: String? = nil, completion: @escaping (Result<Void, Error>) -> Void) {
        DispatchQueue.global().async {
            var folderPath = url.appendingPathComponent(folderName ?? "").path
            
            if self.fileManager.fileExists(atPath: folderPath) {
                folderPath = url.appendingPathComponent(self.generateNewName(forItemAtPath: folderPath)).path
            }
            
            do {
                try self.fileManager.createDirectory(atPath: folderPath, withIntermediateDirectories: true, attributes: nil)
                DispatchQueue.main.async {
                    completion(.success(()))
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    
    func retrieveFilesAndFolders(inDirectory directoryURL: URL, completion: @escaping (Result<[URL], Error>) -> Void) {
        DispatchQueue.global().async {
            do {
                let contents = try self.fileManager.contentsOfDirectory(at: directoryURL, includingPropertiesForKeys: nil, options: [])
                
                // Filter out only files and folders
                let filesAndFolders = contents.filter { url in
                    var isDirectory: ObjCBool = false
                    guard self.fileManager.fileExists(atPath: url.path, isDirectory: &isDirectory) else {
                        return false // Skip if file doesn't exist
                    }
                    return isDirectory.boolValue || !url.pathExtension.isEmpty
                }
                
                DispatchQueue.main.async {
                    completion(.success(filesAndFolders))
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    
    func moveItem(at srcURL: URL, to destURL: URL, completion: @escaping (Result<Void, Error>) -> Void) {
        DispatchQueue.global().async {
            var destinationURL = destURL
            
            // Check if the destination URL exists
            if self.fileManager.fileExists(atPath: destURL.path) {
                // Generate a new name for the item to avoid conflicts
                let newName = self.generateNewName(forItemAt: srcURL, inDestination: destURL)
                destinationURL = destURL.appendingPathComponent(newName)
            }
            
            do {
                try self.fileManager.moveItem(at: srcURL, to: destinationURL)
                DispatchQueue.main.async {
                    completion(.success(()))
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }

    func moveItems(at srcURLs: [URL], to destURL: URL, completion: @escaping (Result<Void, Error>) -> Void) {
        DispatchQueue.global().async {
            for srcURL in srcURLs {
                self.moveItem(at: srcURL, to: destURL, completion: completion)
            }
        }
    }
    
    func copyItem(at srcURL: URL, to destURL: URL, completion: @escaping (Result<Void, Error>) -> Void) {
        DispatchQueue.global().async {
            var destinationURL = destURL
            
            if srcURL.isDirectory() && destURL.isDirectory() {
                if self.fileManager.fileExists(atPath: destURL.appendingPathComponent(srcURL.lastPathComponent).path) {
                    let newName = self.generateNewName(forItemAt: srcURL, inDestination: destURL)
                    destinationURL = destURL.appendingPathComponent(newName)
                } else {
                    destinationURL = destURL.appendingPathComponent(srcURL.lastPathComponent)
                }
            } else {
                if self.fileManager.fileExists(atPath: destURL.path) {
                    // Generate a new name for the item to avoid conflicts
                    let newName = self.generateNewName(forItemAt: srcURL, inDestination: destURL)
                    destinationURL = destURL.appendingPathComponent(newName)
                } else {
                    destinationURL = destURL.appendingPathComponent(srcURL.lastPathComponent)
                }
            }

            do {
                try self.fileManager.copyItem(at: srcURL, to: destinationURL)
                DispatchQueue.main.async {
                    completion(.success(()))
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    
    func copyItems(at srcURLs: [URL], to destURL: URL, completion: @escaping (Result<Void, Error>) -> Void) {
        
        DispatchQueue.global().async {
            for srcURL in srcURLs {
                self.copyItem(at: srcURL, to: destURL, completion: completion)
            }
        }
    }
    func deleteItem(at url: URL, completion: @escaping (Result<Void, Error>) -> Void) {
        DispatchQueue.global().async {
            do {
                try self.fileManager.removeItem(at: url)
                DispatchQueue.main.async {
                    completion(.success(()))
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    
    func deleteItems(at urls: [URL], completion: @escaping (Result<Void, Error>) -> Void) {
        DispatchQueue.global().async {
            for srcURL in urls {
                self.deleteItem(at: srcURL, completion: completion)
            }
        }
    }
    
    func renameItem(at url: URL, newName: String, completion: @escaping (Result<Void, Error>) -> Void) {
        DispatchQueue.global().async {
            do {
                // Check if the new name is the same as the previous name
                if url.lastPathComponent == newName {
                    DispatchQueue.main.async {
                        completion(.success(()))
                    }
                    return
                }
                
                let finalNewURL = url.deletingLastPathComponent().appendingPathComponent(newName)
                try self.fileManager.moveItem(at: url, to: finalNewURL)
                DispatchQueue.main.async {
                    completion(.success(()))
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    
    // Helper method to generate a new name if a file or folder with the same name already exists
    private func generateNewName(forItemAtPath path: String) -> String {
        let url = URL(fileURLWithPath: path)
        let directoryPath = url.deletingLastPathComponent().path
        let baseName = url.deletingPathExtension().lastPathComponent
        let fileExtension = url.pathExtension
        
        let isFolder = fileExtension.isEmpty
        
        var newName = baseName + " (1)"
        var index = 2
        
        var newNameWithExtension = isFolder ? newName : newName + "." + fileExtension
        
        while fileManager.fileExists(atPath: directoryPath + "/" + newNameWithExtension) {
            newName = "\(baseName) (\(index))"
            newNameWithExtension = isFolder ? newName : newName + "." + fileExtension
            index += 1
        }
        
        return newNameWithExtension
    }
    
    private func generateNewName(forItemAt srcURL: URL, inDestination destURL: URL) -> String {
        let directoryPath = destURL.path
        let baseName = srcURL.deletingPathExtension().lastPathComponent
        let fileExtension = srcURL.pathExtension
        
        let isFolder = fileExtension.isEmpty
        
        var index = 1
        var newName = baseName
        
        var newNameWithExtension = isFolder ? newName : newName + "." + fileExtension
        
        // Collect all existing names in the directory
        let directoryContents = try? fileManager.contentsOfDirectory(atPath: directoryPath)
        let existingNames = directoryContents?.map { URL(fileURLWithPath: $0).lastPathComponent }
        
        // Find the highest index and increment it
        while existingNames?.contains(newNameWithExtension) == true {
            newName = "\(baseName) (\(index))"
            newNameWithExtension = isFolder ? newName : newName + "." + fileExtension
            index += 1
        }
        
        return newNameWithExtension
    }
}

extension CustomFileManager {
    
    func calculateTotalFileCount(forDirectoryAtPath path: String, completion: @escaping (Int) -> Void) {
        // Show loader here
        
        DispatchQueue.global().async {
            var totalCount = 0
            
            // Function to calculate count recursively
            func calculateCount(forItemAtPath itemPath: String) {
                do {
                    let itemURL = URL(fileURLWithPath: itemPath)
                    let resourceValues = try itemURL.resourceValues(forKeys: [.isDirectoryKey])
                    
                    // If it's a directory, recursively calculate count
                    if let isDirectory = resourceValues.isDirectory, isDirectory {
                        let directoryContents = try FileManager.default.contentsOfDirectory(atPath: itemPath)
                        for content in directoryContents {
                            calculateCount(forItemAtPath: (itemPath as NSString).appendingPathComponent(content))
                        }
                    } else {
                        // If it's a file, increment the count
                        totalCount += 1
                    }
                } catch {
                    print("Error: \(error.localizedDescription)")
                }
            }
            
            // Start calculating from the root directory
            calculateCount(forItemAtPath: path)
            
            // Hide loader here
            
            // Return the total count to the main thread
            DispatchQueue.main.async {
                completion(totalCount)
            }
        }
    }

    func calculateTotalSize(forDirectoryAtPath path: String, completion: @escaping (Int64) -> Void) {
        // Show loader here
        
        DispatchQueue.global().async {
            var totalSize: Int64 = 0
            
            // Function to calculate size recursively
            func calculateSize(forItemAtPath itemPath: String) {
                do {
                    let itemURL = URL(fileURLWithPath: itemPath)
                    let resourceValues = try itemURL.resourceValues(forKeys: [.isDirectoryKey, .fileSizeKey])
                    
                    // If it's a directory, recursively calculate size
                    if let isDirectory = resourceValues.isDirectory, isDirectory {
                        let directoryContents = try FileManager.default.contentsOfDirectory(atPath: itemPath)
                        for content in directoryContents {
                            calculateSize(forItemAtPath: (itemPath as NSString).appendingPathComponent(content))
                        }
                    } else {
                        // If it's a file, update the total size
                        if let fileSize = resourceValues.fileSize {
                            totalSize += Int64(fileSize)
                        }
                    }
                } catch {
                    print("Error: \(error.localizedDescription)")
                }
            }
            
            // Start calculating from the root directory
            calculateSize(forItemAtPath: path)
            
            // Hide loader here
            
            // Return the total size to the main thread
            DispatchQueue.main.async {
                completion(totalSize)
            }
        }
    }
}


extension CustomFileManager {
    
    func generateThumbnail(forFileAtPath path: String, completion: @escaping (UIImage?) -> Void) {
//        let url = URL(fileURLWithPath: path)
        
        // Check if the file is an image
        if let image = UIImage(contentsOfFile: path) {
            // If it's an image file, directly return the image
            completion(image)
        } else if let videoURL = URL(string: path), videoURL.pathExtension.lowercased() == "mp4" {
            // If it's a video file, generate a thumbnail using AVFoundation
            DispatchQueue.global().async {
                let asset = AVAsset(url: videoURL)
                let assetImageGenerator = AVAssetImageGenerator(asset: asset)
                assetImageGenerator.appliesPreferredTrackTransform = true
                
                let time = CMTimeMakeWithSeconds(1, preferredTimescale: 60)
                do {
                    let imageRef = try assetImageGenerator.copyCGImage(at: time, actualTime: nil)
                    let thumbnail = UIImage(cgImage: imageRef)
                    DispatchQueue.main.async {
                        completion(thumbnail)
                    }
                } catch {
                    print("Error generating thumbnail: \(error.localizedDescription)")
                    DispatchQueue.main.async {
                        completion(nil)
                    }
                }
            }
        } else {
            // If it's neither an image nor a supported video file, return nil
            completion(nil)
        }
    }
}

extension URL {
    
    func isDirectory() -> Bool {
        var isDirectory: ObjCBool = false
        FileManager.default.fileExists(atPath: self.path, isDirectory: &isDirectory)
        return isDirectory.boolValue
    }
    
    func isFile() -> Bool {
        return !self.isDirectory()
    }
    
    func isFileExists() -> Bool {
        var isDirectory: ObjCBool = false
        return FileManager.default.fileExists(atPath: self.path, isDirectory: &isDirectory)
    }
    
    func fileName() -> String {
        return self.lastPathComponent
    }
    
    func parentDirectory() -> URL? {
        return self.deletingLastPathComponent()
    }
    
    var fileExtension: String? {
        return self.pathExtension
    }
}

extension URL {
    func resourceExists() -> Bool {
        var isDirectory: ObjCBool = false
        return FileManager.default.fileExists(atPath: self.path, isDirectory: &isDirectory)
    }
    
    func fileExists(withName fileName: String) -> Bool {
        let filePath = self.appendingPathComponent(fileName).path
        return FileManager.default.fileExists(atPath: filePath)
    }
    
    func directoryExists(withName directoryName: String) -> Bool {
        let directoryPathWithFolder = self.appendingPathComponent(directoryName).path
        return FileManager.default.fileExists(atPath: directoryPathWithFolder)
    }
}

extension URL {
    
    func fileSize() -> Int64? {
        do {
            let attributes = try FileManager.default.attributesOfItem(atPath: self.path)
            if let size = attributes[.size] as? Int64 {
                return size
            }
        } catch {
            print("Error getting file size: \(error.localizedDescription)")
        }
        return nil
    }
    
    func lastModifiedDate() -> Date? {
        do {
            let attributes = try FileManager.default.attributesOfItem(atPath: self.path)
            return attributes[.modificationDate] as? Date
        } catch {
            print("Error getting last modified date: \(error.localizedDescription)")
            return nil
        }
    }
    
    func creationDate() -> Date? {
        do {
            let attributes = try FileManager.default.attributesOfItem(atPath: self.path)
            return attributes[.creationDate] as? Date
        } catch {
            print("Error getting creation date: \(error.localizedDescription)")
            return nil
        }
    }
}

extension URL {
    
    var fileType: FileType {
        let fileExtension = self.pathExtension.lowercased()
        
        switch fileExtension {
        case "mp3", "wav", "aac", "flac":
            return .audio
        case "mp4", "mov", "avi", "mkv":
            return .video
        case "jpg", "jpeg", "png", "gif", "bmp", "heic":
            return .image
        case "txt", "rtf", "", "html", "xml", "json":
            return .document
        case "pdf":
            return .pdf
        case "xls", "xlsx", "csv":
            return .excel
        case "ppt", "pptx":
            return .powerPoint
        case "doc", "docx":
            return .word
        default:
            return .other
        }
    }
    
    enum FileType {
        case audio
        case video
        case image
        case document
        case pdf
        case excel
        case powerPoint
        case word
        case other
    }
}

extension Int64 {
    func toReadableFileSize() -> String {
        let units = ["B", "KB", "MB", "GB", "TB"]
        var fileSize = Double(self)
        var index = 0
        
        while fileSize > 1024 && index < units.count - 1 {
            fileSize /= 1024
            index += 1
        }
        
        return String(format: "%.2f %@", fileSize, units[index])
    }
}

extension Date {
    func formattedDateString() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        formatter.timeZone = TimeZone.current
        return formatter.string(from: self)
    }
}
